// Browser test of the customer booking flow (pay in shop), with screenshots.
import { createRequire } from 'node:module';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const BASE = 'http://localhost:4321';
const out = process.argv[2] || '/tmp/shots';
const fail = m => { console.error('FAIL', m); process.exitCode = 1; };

const browser = await chromium.launch();
const errors = [];
for (const [name, viewport, scheme] of [['desktop', { width: 1280, height: 900 }, 'light'], ['phone', { width: 390, height: 844 }, 'dark']]) {
  const page = await browser.newPage({ viewport, colorScheme: scheme });
  page.on('pageerror', e => errors.push(`${name}: ${e.message}`));
  page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|fonts\.g|Failed to load resource/.test(m.text())) errors.push(`${name} console: ${m.text()}`); });
  await page.goto(`${BASE}/strop?lang=en`);
  await page.waitForSelector('#app:not([hidden])');
  await page.waitForSelector('.slot');
  await page.screenshot({ path: `${out}/book-${name}.png`, fullPage: name === 'desktop' });
  const wide = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
  if (wide) fail(`${name}: page scrolls sideways`);
  if (name === 'phone') {
    await page.click('[data-lang="ka"]');
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${out}/book-phone-ka.png` });
  }
  await page.close();
}

// Full booking
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
page.on('pageerror', e => errors.push(e.message));
await page.goto(`${BASE}/strop?lang=en`);
await page.waitForSelector('.slot:not([disabled])');
await page.click('.opt:nth-child(2)');                       // Skin fade
await page.click('.chip[data-addon]');                        // + wash
await page.click('.barber:nth-child(2)');                     // first barber
await page.waitForSelector('.slot:not([disabled])');
const time = await page.$eval('.slot:not([disabled])', b => b.dataset.time);
await page.click(`.slot[data-time="${time}"]`);
await page.click('#submit');                                  // empty form -> errors
const nameErr = await page.textContent('#e-name');
if (!nameErr) fail('no name validation');
await page.fill('#name', 'Giorgi Beridze');
await page.fill('#phone', '555 12 34 56');
await page.click('#submit');
await page.waitForURL(/\/b\//, { timeout: 8000 });
await page.waitForSelector('.code');
const code = await page.textContent('.code');
await page.screenshot({ path: `${out}/confirmed.png`, fullPage: true });
console.log('booked', time, code);

// same time, same barber again -> taken
await page.goto(`${BASE}/strop?lang=en`);
await page.waitForSelector('.slot');
await page.click('.opt:nth-child(2)'); await page.click('.chip[data-addon]'); await page.click('.barber:nth-child(2)');
await page.waitForTimeout(600);
const disabled = await page.$eval(`.slot[data-time="${time}"]`, b => b.disabled).catch(() => null);
if (disabled !== true) fail('booked slot still shows as free for the same barber');

const log = await (await fetch(`${BASE}/mock/log`)).json();
if (!log.sms.length) fail('no confirmation SMS'); else console.log('sms:', log.sms[log.sms.length - 1].content);
if (errors.length) fail(errors.join('\n'));
await browser.close();
console.log(process.exitCode ? 'E2E BOOK: FAILED' : 'E2E BOOK: PASSED');
