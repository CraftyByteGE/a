// Local test server: serves the site like Vercel does, runs the /api functions,
// and imitates Supabase (via psql), TBC, Bank of Georgia and SMSOffice.
// Usage: node test/devserver.mjs   (needs the local test Postgres running)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = +(process.env.PORT || 4321);
const BASE = `http://localhost:${PORT}`;
const PG = ['-h', '/tmp/pgdata', '-p', '54329', '-U', 'postgres', '-d', process.env.PGDB || 'chairbook', '-At', '-v', 'ON_ERROR_STOP=1', '-q'];
const SECRET = 'sb_secret_test', PUBLISHABLE = 'sb_publishable_test';

Object.assign(process.env, {
  SUPABASE_URL: `${BASE}/supabase`, SUPABASE_PUBLISHABLE_KEY: PUBLISHABLE, SUPABASE_SECRET_KEY: SECRET,
  APP_SECRET: 'test-secret-test-secret-test-secret-123', APP_URL: BASE, TBC_API_KEY: 'tbc-dev-key',
  TBC_API_BASE: `${BASE}/mock/tbc`, BOG_API_BASE: `${BASE}/mock/bog`, BOG_AUTH_URL: `${BASE}/mock/bog/token`,
  SMSOFFICE_API_KEY: 'sms-key', SMS_SENDER: 'Chairbook', SMS_API_URL: `${BASE}/mock/sms`, CRON_SECRET: 'cron-test',
});

export const log = { sms: [], bank: [] };
const passwords = new Map(); // user id -> password (test only)

function psql(sql) {
  return new Promise(res => execFile('psql', [...PG, '-c', sql], { maxBuffer: 1 << 24 }, (err, out, errOut) => res({ err: err ? (errOut || String(err)) : null, out })));
}
const lit = v => v === null || v === undefined ? 'NULL' : `'${String(typeof v === 'object' ? (Array.isArray(v) && v.every(x => typeof x === 'string') ? `{${v.join(',')}}` : JSON.stringify(v)) : v).replace(/'/g, "''")}'`;

let rettypes = null;
async function rettype(fn) {
  if (!rettypes) {
    const r = await psql(`select proname || '=' || prorettype::regtype from pg_proc p join pg_namespace n on n.oid=p.pronamespace where nspname='public'`);
    rettypes = Object.fromEntries(r.out.trim().split('\n').map(l => l.split('=')));
  }
  return rettypes[fn];
}

async function rpc(fn, args, headers) {
  const auth = (headers.authorization || '').replace('Bearer ', '');
  let role = 'anon', claims = '{}';
  if (headers.apikey === SECRET && (!auth || auth === SECRET)) role = 'service_role';
  else if (auth.startsWith('user:')) { role = 'authenticated'; claims = JSON.stringify({ sub: auth.slice(5), role: 'authenticated' }); }
  const type = await rettype(fn);
  if (!type) return [404, { code: 'PGRST202', message: `function ${fn} not found` }];
  const call = `public.${fn}(${Object.entries(args || {}).map(([k, v]) => `${k} := ${lit(v)}`).join(', ')})`;
  const sql = `begin; set local role ${role}; select set_config('request.jwt.claims', ${lit(claims)}, true) \\g /dev/null
  select ${type === 'void' ? `${call}::text` : type === 'jsonb' ? `coalesce(${call}::text, 'null')` : `to_jsonb(${call})::text`}; commit;`;
  const r = await new Promise(res => {
    const p = execFile('psql', PG, { maxBuffer: 1 << 24 }, (err, out, errOut) => res({ err: err ? (errOut || String(err)) : null, out }));
    p.stdin.end(sql);
  });
  if (r.err) {
    const m = /ERROR:\s+(.*)/.exec(r.err); const msg = m ? m[1].trim() : r.err;
    if (/permission denied/.test(msg)) return [role === 'anon' ? 401 : 403, { code: '42501', message: msg }];
    if (/duplicate key/.test(msg)) return [409, { code: '23505', message: msg }];
    if (/violates check constraint/.test(msg)) return [400, { code: '23514', message: msg }];
    if (msg === 'not_allowed') return [403, { code: '42501', message: msg }];
    return [400, { code: 'P0001', message: msg }];
  }
  const lines = r.out.trim().split('\n').filter(l => l && l !== 'BEGIN' && l !== 'COMMIT' && l !== 'SET');
  const last = lines[lines.length - 1];
  if (type === 'void') return [200, null];
  return [200, last === undefined || last === '' ? null : JSON.parse(last)];
}

async function authUsers(req, url, body) {
  if (url.pathname.endsWith('/token')) {
    const gt = url.searchParams.get('grant_type');
    let id;
    if (gt === 'password') {
      const r = await psql(`select id from auth.users where lower(email)=lower(${lit(body.email)})`);
      id = r.out.trim();
      if (!id || passwords.get(id) !== body.password) return [400, { error: 'invalid_grant', error_description: 'Invalid login credentials' }];
    } else id = String(body.refresh_token || '').slice(2);
    const e = (await psql(`select email from auth.users where id=${lit(id)}`)).out.trim();
    return [200, { access_token: `user:${id}`, refresh_token: `r:${id}`, expires_in: 3600, user: { id, email: e } }];
  }
  if (url.pathname.endsWith('/user')) {
    const tok = (req.headers.authorization || '').replace('Bearer ', '');
    if (!tok.startsWith('user:')) return [401, { msg: 'bad jwt' }];
    const id = tok.slice(5); const e = (await psql(`select email from auth.users where id=${lit(id)}`)).out.trim();
    return e ? [200, { id, email: e }] : [401, { msg: 'no user' }];
  }
  if (url.pathname.includes('/admin/users')) {
    if (req.headers.apikey !== SECRET) return [401, { msg: 'no' }];
    const idm = /admin\/users\/([0-9a-f-]{36})/.exec(url.pathname);
    if (req.method === 'POST') {
      const ex = (await psql(`select id from auth.users where lower(email)=lower(${lit(body.email)})`)).out.trim();
      if (ex) return [422, { msg: 'A user with this email address has already been registered' }];
      const id = (await psql(`insert into auth.users(email) values (${lit(body.email)}) returning id`)).out.trim().split('\n')[0];
      passwords.set(id, body.password); return [200, { id, email: body.email }];
    }
    if (req.method === 'PUT' && idm) { passwords.set(idm[1], body.password); return [200, { id: idm[1] }]; }
    if (req.method === 'GET') {
      const rows = (await psql(`select id||'|'||email from auth.users`)).out.trim().split('\n').filter(Boolean).map(l => { const [id, email] = l.split('|'); return { id, email }; });
      return [200, { users: rows }];
    }
  }
  return [404, {}];
}

// ---- fake banks ----
const orders = new Map(); // id -> {provider, amount, state, returnUrl, callbackUrl}
function bank(req, url, body) {
  const p = url.pathname.replace('/mock/', '');
  log.bank.push({ p, method: req.method, body });
  if (p === 'tbc/v1/tpay/access-token') {
    if (req.headers.apikey !== 'tbc-dev-key') return [401, { message: 'apikey' }];
    return body.client_secret === 'bad' ? [401, { error: 'invalid_client' }] : [200, { access_token: 'tbc-token', expires_in: 3600 }];
  }
  if (p === 'tbc/v1/tpay/payments' && req.method === 'POST') {
    const id = 'tbcpay' + Math.random().toString(36).slice(2, 10);
    orders.set(id, { provider: 'tbc', amount: body.amount.total, state: 'Created', returnUrl: body.returnurl, callbackUrl: body.callbackUrl });
    return [200, { payId: id, status: 'Created', links: [{ uri: `${BASE}/mock/checkout?id=${id}`, method: 'REDIRECT', rel: 'approval_url' }] }];
  }
  let m;
  if ((m = /^tbc\/v1\/tpay\/payments\/(.+)$/.exec(p))) {
    const o = orders.get(m[1]); if (!o) return [404, {}];
    return [200, { payId: m[1], status: o.state, amount: o.amount, confirmedAmount: o.state === 'Succeeded' ? o.amount : 0 }];
  }
  if (p === 'bog/token') {
    const auth = Buffer.from((req.headers.authorization || '').replace('Basic ', ''), 'base64').toString();
    return auth.endsWith(':bad') ? [401, { error: 'invalid_client' }] : [200, { access_token: 'bog-token', token_type: 'Bearer', expires_in: 600 }];
  }
  if (p === 'bog/payments/v1/ecommerce/orders') {
    const id = 'bogord' + Math.random().toString(36).slice(2, 10);
    orders.set(id, { provider: 'bog', amount: body.purchase_units.total_amount, state: 'created', returnUrl: body.redirect_urls.success, callbackUrl: body.callback_url });
    return [200, { id, _links: { redirect: { href: `${BASE}/mock/checkout?id=${id}` }, details: { href: '' } } }];
  }
  if ((m = /^bog\/payments\/v1\/receipt\/(.+)$/.exec(p))) {
    const o = orders.get(m[1]); if (!o) return [404, {}];
    return [200, { order_id: m[1], order_status: { key: o.state }, purchase_units: { request_amount: String(o.amount), transfer_amount: o.state === 'completed' ? String(o.amount) : '0' } }];
  }
  if (p === 'sms') { log.sms.push(body); return [200, { Success: true, Message: 'ok', ErrorCode: 0 }]; }
  return [404, {}];
}

async function checkout(req, url, res) {
  const id = url.searchParams.get('id'), o = orders.get(id), act = url.searchParams.get('act');
  if (!o) { res.writeHead(404); return res.end('no order'); }
  if (act) {
    const ok = act === 'pay';
    o.state = o.provider === 'tbc' ? (ok ? 'Succeeded' : 'Failed') : (ok ? 'completed' : 'rejected');
    if (url.searchParams.get('nocallback') !== '1') {
      const cb = o.provider === 'tbc' ? { PaymentId: id } : { event: 'order_payment', body: { order_id: id } };
      await fetch(o.callbackUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cb) });
    }
    res.writeHead(302, { Location: o.returnUrl }); return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(`<!doctype html><title>Test bank</title><body style="font:16px system-ui;padding:40px"><h1>${o.provider.toUpperCase()} test checkout</h1><p>Amount: ${o.amount} GEL</p>
    <a id="pay" href="?id=${id}&act=pay">Pay</a> · <a id="fail" href="?id=${id}&act=fail">Fail</a> · <a id="paynocb" href="?id=${id}&act=pay&nocallback=1">Pay (bank callback lost)</a></body>`);
}

// ---- static + rewrites like vercel.json ----
const vercel = JSON.parse(fs.readFileSync(path.join(ROOT, 'vercel.json'), 'utf8'));
function rewrite(p) {
  for (const r of vercel.rewrites || []) {
    const keys = [];
    const re = new RegExp('^' + r.source.replace(/:(\w+)(\([^)]*\))?/g, (_, k, pat) => { keys.push(k); return pat ? pat.replace(/^\(/, '(') : '([^/]+)'; }) + '$');
    if (re.test(p)) return r.destination;
  }
  return null;
}
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json', '.png': 'image/png', '.ico': 'image/x-icon' };
function serveStatic(p, res) {
  let f = path.join(ROOT, 'public', p);
  if (p.endsWith('/')) f = path.join(f, 'index.html');
  if (!f.startsWith(path.join(ROOT, 'public')) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) return false;
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res); return true;
}

async function readRaw(req) { const c = []; for await (const x of req) c.push(x); return Buffer.concat(c).toString(); }
function parse(raw, type) { if (!raw) return {}; if ((type || '').includes('urlencoded')) return Object.fromEntries(new URLSearchParams(raw)); try { return JSON.parse(raw); } catch { return {}; } }
const handlers = new Map();

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, BASE);
  const json = ([s, b]) => { res.writeHead(s, { 'Content-Type': 'application/json' }); res.end(b === undefined ? '' : JSON.stringify(b)); };
  try {
    if (url.pathname.startsWith('/supabase/rest/v1/rpc/')) return json(await rpc(url.pathname.split('/').pop(), parse(await readRaw(req)), req.headers));
    if (url.pathname.startsWith('/supabase/auth/v1/')) return json(await authUsers(req, url, parse(await readRaw(req), req.headers['content-type'])));
    if (url.pathname === '/mock/checkout') return checkout(req, url, res);
    if (url.pathname === '/mock/log') return json([200, log]);
    if (url.pathname.startsWith('/mock/')) return json(bank(req, url, parse(await readRaw(req), req.headers['content-type'])));
    if (url.pathname.startsWith('/api/')) {
      const file = path.join(ROOT, url.pathname + '.js');
      if (!fs.existsSync(file) || url.pathname.includes('/_lib/')) return json([404, { error: 'not_found' }]);
      if (!handlers.has(file)) handlers.set(file, (await import(pathToFileURL(file).href)).default);
      req.query = Object.fromEntries(url.searchParams);
      const raw = await readRaw(req); req.body = parse(raw, req.headers['content-type']);
      return handlers.get(file)(req, res);
    }
    if (serveStatic(url.pathname, res)) return;
    const dest = rewrite(url.pathname);
    if (dest && serveStatic(dest, res)) return;
    res.writeHead(404); res.end('Not found');
  } catch (e) { console.error(e); res.writeHead(500); res.end(String(e)); }
});

export function setPassword(id, pw) { passwords.set(id, pw); }
server.listen(PORT, () => console.log(`dev server on ${BASE}`));
export default server;
