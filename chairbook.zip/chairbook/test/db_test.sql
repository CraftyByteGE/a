-- Database behaviour tests. Run against a fresh DB with the stub + migration applied.
\set ON_ERROR_STOP 1
set client_min_messages = warning;

-- people
insert into auth.users (id, email) values
 ('00000000-0000-0000-0000-00000000000a', 'admin@platform.ge'),
 ('00000000-0000-0000-0000-0000000000a1', 'owner@shop1.ge'),
 ('00000000-0000-0000-0000-0000000000a2', 'barber@shop1.ge'),
 ('00000000-0000-0000-0000-0000000000b1', 'owner@shop2.ge');
insert into platform_admins values ('00000000-0000-0000-0000-00000000000a');

create temp table t_ctx (k text primary key, v text);
grant all on t_ctx to public;

do $$
declare s1 uuid; s2 uuid; b1 uuid;
begin
  s1 := admin_create_shop('{"slug":"strop","name":"Strop & Steel"}');
  s2 := admin_create_shop('{"slug":"other","name":"Other Shop"}');
  perform add_member(s1, '00000000-0000-0000-0000-0000000000a1', 'owner', null);
  select id into b1 from barbers where shop_id = s1 order by sort limit 1;
  perform add_member(s1, '00000000-0000-0000-0000-0000000000a2', 'staff', b1);
  perform add_member(s2, '00000000-0000-0000-0000-0000000000b1', 'owner', null);
  insert into t_ctx values ('s1', s1), ('s2', s2), ('b1', b1),
    ('b2', (select id::text from barbers where shop_id = s1 order by sort offset 1 limit 1)),
    ('svc', (select id::text from services where shop_id = s1 and not is_addon order by sort limit 1)),       -- 45 min
    ('addon', (select id::text from services where shop_id = s1 and is_addon limit 1)),                       -- 10 min
    ('svc2', (select id::text from services where shop_id = s2 and not is_addon order by sort limit 1)),
    -- a Tuesday 7..13 days ahead (Tue hours 10:00–20:00)
    ('day', (select to_char(d, 'YYYY-MM-DD') from generate_series(((now() at time zone 'Asia/Tbilisi')::date + 7)::timestamp, ((now() at time zone 'Asia/Tbilisi')::date + 13)::timestamp, interval '1 day') d where extract(dow from d) = 2 limit 1)),
    ('monday', (select to_char(d, 'YYYY-MM-DD') from generate_series(((now() at time zone 'Asia/Tbilisi')::date + 1)::timestamp, ((now() at time zone 'Asia/Tbilisi')::date + 7)::timestamp, interval '1 day') d where extract(dow from d) = 1 limit 1));
end $$;

create or replace function pg_temp.ctx(k text) returns text language sql as $$ select v from t_ctx where t_ctx.k = $1 $$;
create or replace function pg_temp.ok(cond boolean, msg text) returns void language plpgsql as $$
begin if cond is not true then raise exception 'FAIL: %', msg; end if; raise notice 'ok - %', msg; end $$;
create or replace function pg_temp.err(sqltext text, expect text, msg text) returns void language plpgsql as $$
begin
  execute sqltext;
  raise exception 'FAIL (no error): %', msg;
exception when others then
  if sqlerrm not like '%' || expect || '%' then raise exception 'FAIL: % (got "%")', msg, sqlerrm; end if;
  raise notice 'ok - %', msg;
end $$;
set client_min_messages = notice;

-- ===== public reads as anon =====
set role anon;
select pg_temp.ok((get_shop_public('strop')->>'name') = 'Strop & Steel', 'anon reads public shop');
select pg_temp.ok(jsonb_array_length(get_shop_public('strop')->'services') = 5, 'public shop lists 5 services');
select pg_temp.ok((get_shop_public('strop')->'online') = 'null'::jsonb, 'online pay hidden when no bank keys');
select pg_temp.ok(get_shop_public('nope') is null, 'unknown shop returns null');
select pg_temp.err($$select * from shops$$, 'permission denied', 'anon cannot read shops table');
select pg_temp.err($$select * from bookings$$, 'permission denied', 'anon cannot read bookings table');
select pg_temp.err($$select create_booking('{}')$$, 'permission denied', 'anon cannot call create_booking');
select pg_temp.err($$select my_shops()$$, 'permission denied', 'anon cannot call panel functions');
select pg_temp.ok((get_availability('strop', pg_temp.ctx('monday')::date, pg_temp.ctx('svc')::uuid)->>'closed')::boolean, 'Monday is closed');
select pg_temp.ok(jsonb_array_length(get_availability('strop', pg_temp.ctx('day')::date, pg_temp.ctx('svc')::uuid)->'slots') = 19,
  'Tuesday 10:00-20:00 with 45-min service gives 19 half-hour starts (10:00..19:00)');
select pg_temp.ok((get_availability('strop', pg_temp.ctx('day')::date, pg_temp.ctx('svc')::uuid, array[pg_temp.ctx('addon')::uuid])->>'minutes')::int = 55, 'add-on adds 10 minutes');
reset role;

-- ===== booking engine (service role) =====
set role service_role;
select pg_temp.ctx('day');
do $$
declare r jsonb; r2 jsonb; r3 jsonb; base jsonb;
begin
  base := jsonb_build_object('slug','strop','service_id',pg_temp.ctx('svc'),'date',pg_temp.ctx('day'),'time','10:00',
                             'name','Luka Beridze','phone','+995 555 12 34 56','lang','ka','pay_choice','shop');
  r := create_booking(base || jsonb_build_object('barber_id', pg_temp.ctx('b1')));
  perform pg_temp.ok(r->>'status' = 'booked' and r->>'time' = '10:00' and r->>'end' = '10:45', 'pay-in-shop booking is booked 10:00-10:45');
  perform pg_temp.ok(length(r->>'code') = 6, 'booking code has 6 characters');
  insert into t_ctx values ('k1', r->>'id');

  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('barber_id', pg_temp.ctx('b1'), 'time','10:30')),
                      'slot_taken', 'same barber overlapping 10:30 is refused');
  r2 := create_booking(base || jsonb_build_object('time','10:30'));
  perform pg_temp.ok(r2->>'barber_id' = pg_temp.ctx('b2'), 'any-barber booking goes to the free barber');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('time','10:30')),
                      'slot_taken', 'both barbers busy -> slot_taken');
  r3 := create_booking(base || jsonb_build_object('time','11:00'));
  perform pg_temp.ok(r3->>'barber_id' = pg_temp.ctx('b1'), 'after both are busy at 10:30, 11:00 goes to barber 1 (free after 10:45)');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('time','10:15')), 'outside_hours', 'off-grid time 10:15 refused');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('time','19:30')), 'outside_hours', '19:30 + 45 min runs past closing');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('date',pg_temp.ctx('monday'))), 'shop_closed', 'Monday booking refused');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('pay_choice','full')), 'online_pay_unavailable', 'online payment refused without bank keys');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('name','A')), 'bad_name', 'too-short name refused');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('phone','12')), 'bad_phone', 'bad phone refused');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('service_id',pg_temp.ctx('svc2'))), 'service_not_found', 'service from another shop refused');
  perform pg_temp.err(format('select create_booking(%L)', base || jsonb_build_object('date',to_char(now() at time zone 'Asia/Tbilisi','YYYY-MM-DD'),'time','00:00')),
                      '', 'past time refused');
end $$;

-- availability reflects bookings
select pg_temp.ok(
  (select (x->>'free')::boolean from jsonb_array_elements(get_availability('strop', pg_temp.ctx('day')::date, pg_temp.ctx('svc')::uuid)->'slots') x where x->>'t' = '10:30') = false,
  '10:30 shows as taken when both barbers are busy');
select pg_temp.ok(
  (select (x->>'free')::boolean from jsonb_array_elements(get_availability('strop', pg_temp.ctx('day')::date, pg_temp.ctx('svc')::uuid)->'slots') x where x->>'t' = '12:00') = true,
  '12:00 is free');

-- ===== online payment flow =====
select set_secret(pg_temp.ctx('s1')::uuid, 'tbc', 'encrypted-blob');
update shops set online_pay = 'tbc', online_mode = 'choice', deposit_percent = 20 where slug = 'strop';
select pg_temp.ok((get_shop_public('strop')->'online'->>'provider') = 'tbc', 'online pay shows once keys exist');
do $$
declare r jsonb; c jsonb; base jsonb;
begin
  base := jsonb_build_object('slug','strop','service_id',pg_temp.ctx('svc'),'date',pg_temp.ctx('day'),
                             'name','Nika K','phone','555123456','barber_id',pg_temp.ctx('b2'));
  r := create_booking(base || '{"time":"12:00","pay_choice":"deposit"}');
  perform pg_temp.ok(r->>'status' = 'pending' and (r->>'online_due')::numeric = 7.00, 'deposit booking is pending with 20% of 35 = 7.00 due');
  perform attach_payment((r->>'id')::uuid, 'tbc', 'TBC-ORDER-1', 7.00);
  perform pg_temp.ok((payment_lookup('tbc','TBC-ORDER-1')->>'secret') = 'encrypted-blob', 'payment lookup returns the shop key blob');
  perform pg_temp.err(format('select create_booking(%L)', base || '{"time":"12:00"}'), 'slot_taken', 'a pending payment holds the time');
  c := confirm_payment('tbc', 'TBC-ORDER-1', 7.00, '{"status":"Succeeded"}');
  perform pg_temp.ok((c->>'ok')::boolean and c->'booking'->>'status' = 'booked' and (c->'booking'->>'paid_online')::numeric = 7, 'confirmed payment books it');
  c := confirm_payment('tbc', 'TBC-ORDER-1', 7.00);
  perform pg_temp.ok((c->>'already')::boolean, 'second callback is ignored (idempotent)');

  -- failed payment releases the time
  r := create_booking(base || '{"time":"13:00","pay_choice":"full"}');
  perform pg_temp.ok((r->>'online_due')::numeric = 35, 'full payment due is full price');
  perform attach_payment((r->>'id')::uuid, 'tbc', 'TBC-ORDER-2', 35);
  perform fail_payment('tbc', 'TBC-ORDER-2');
  perform pg_temp.ok((select status from bookings where id = (r->>'id')::uuid) = 'expired', 'failed payment expires booking');
  r := create_booking(base || '{"time":"13:00","pay_choice":"shop"}');
  perform pg_temp.ok(r->>'status' = 'booked', 'time is bookable again after failed payment');

  -- expired hold: paid late, slot taken by someone else -> flagged for refund
  r := create_booking(base || '{"time":"14:00","pay_choice":"full"}');
  perform attach_payment((r->>'id')::uuid, 'bog', 'BOG-ORDER-3', 35);
  update bookings set hold_until = now() - interval '1 minute' where id = (r->>'id')::uuid;
  perform create_booking(base || '{"time":"14:00","pay_choice":"shop","name":"Someone Else"}');
  c := confirm_payment('bog', 'BOG-ORDER-3', 35);
  perform pg_temp.ok(not (c->>'ok')::boolean and c->'booking'->>'status' = 'cancelled' and c->'booking'->>'staff_note' like '%Refund needed%',
                     'late payment on a taken time is flagged for refund, not double-booked');
end $$;
reset role;

-- ===== panel permissions =====
set request.jwt.claims = '{"sub":"00000000-0000-0000-0000-0000000000a1"}';
set role authenticated;
select pg_temp.ok(jsonb_array_length(my_shops()->'shops') = 1 and not (my_shops()->>'admin')::boolean, 'owner sees exactly their shop');
select pg_temp.ok(jsonb_array_length(panel_day(pg_temp.ctx('s1')::uuid, pg_temp.ctx('day')::date)->'bookings') >= 6, 'owner sees the day sheet');
select pg_temp.ok(jsonb_array_length(panel_range(pg_temp.ctx('s1')::uuid, pg_temp.ctx('day')::date, pg_temp.ctx('day')::date)) >= 5, 'owner sees income rows');
select pg_temp.err(format('select panel_day(%L, %L)', pg_temp.ctx('s2'), pg_temp.ctx('day')), 'not_allowed', 'owner cannot read another shop');
select pg_temp.err(format('select save_shop(%L, %L)', pg_temp.ctx('s2'), '{"name":"hacked"}'), 'not_allowed', 'owner cannot edit another shop');
select pg_temp.ok((set_booking_status(pg_temp.ctx('k1')::uuid, 'done')->>'status') = 'done', 'owner marks booking done');
select pg_temp.ok((set_booking_status(pg_temp.ctx('k1')::uuid, 'cancelled')->>'status') = 'cancelled', 'owner cancels booking');
select pg_temp.ok((set_booking_status(pg_temp.ctx('k1')::uuid, 'booked')->>'status') = 'booked', 'owner restores booking (time still free)');
select pg_temp.err(format('select save_shop(%L, %L)', pg_temp.ctx('s1'), '{"hours":{"2":["20:00","10:00"]}}'), 'bad_hours', 'closing before opening refused');
select pg_temp.err(format('select save_shop(%L, %L)', pg_temp.ctx('s1'), '{"online_pay":"bog"}'), 'online_pay_unavailable', 'cannot switch to BOG without BOG keys');
select pg_temp.err(format('select save_shop(%L, %L)', pg_temp.ctx('s1'), '{"pay_in_shop":false,"online_pay":"off"}'), 'need_a_payment_option', 'at least one way to pay is required');
select save_shop(pg_temp.ctx('s1')::uuid, '{"name":"Strop and Steel","accent":"#225588"}');
select pg_temp.ok((get_settings(pg_temp.ctx('s1')::uuid)->'shop'->>'accent') = '#225588', 'settings saved');
select pg_temp.ok((get_settings(pg_temp.ctx('s1')::uuid)->'payments'->>'tbc')::boolean, 'settings show TBC connected');
select pg_temp.ok(jsonb_array_length(get_settings(pg_temp.ctx('s1')::uuid)->'staff') = 2, 'settings list both logins');
select pg_temp.ok(save_service(pg_temp.ctx('s1')::uuid, '{"name":{"ka":"ბავშვის შეჭრა","en":"Kids cut"},"price":20,"duration_min":30}') is not null, 'owner adds a service');
select pg_temp.ok(add_closure(pg_temp.ctx('s1')::uuid, jsonb_build_object('starts_on', pg_temp.ctx('day'), 'barber_id', pg_temp.ctx('b2'), 'note','Vacation')) is not null, 'owner adds barber day off');
select pg_temp.err($$select admin_shops()$$, 'not_allowed', 'owner is not platform admin');
select pg_temp.ok((panel_add_booking(pg_temp.ctx('s1')::uuid, jsonb_build_object('service_id',pg_temp.ctx('svc'),'date',pg_temp.ctx('day'),'time','16:10','barber_id',pg_temp.ctx('b1'),'name','Walk In','phone','555000111'))->>'source') = 'panel',
  'staff can add a phone/walk-in booking at any time');
reset role;

-- day off removes barber 2 from availability
set role anon;
select pg_temp.ok(
  (select (x->>'free')::boolean from jsonb_array_elements(get_availability('strop', pg_temp.ctx('day')::date, pg_temp.ctx('svc')::uuid, '{}', pg_temp.ctx('b2')::uuid)->'slots') x where x->>'t' = '17:00') = false,
  'barber on day off shows no free times');
reset role;

set request.jwt.claims = '{"sub":"00000000-0000-0000-0000-0000000000a2"}';
set role authenticated;
select pg_temp.ok((panel_day(pg_temp.ctx('s1')::uuid, pg_temp.ctx('day')::date)->>'role') = 'staff', 'staff sees the day sheet');
select pg_temp.err(format('select panel_range(%L, %L, %L)', pg_temp.ctx('s1'), pg_temp.ctx('day'), pg_temp.ctx('day')), 'not_allowed', 'staff cannot see income');
select pg_temp.err(format('select get_settings(%L)', pg_temp.ctx('s1')), 'not_allowed', 'staff cannot open settings');
reset role;

set request.jwt.claims = '{"sub":"00000000-0000-0000-0000-00000000000a"}';
set role authenticated;
select pg_temp.ok(jsonb_array_length(admin_shops()) = 2, 'platform admin lists all shops');
select admin_update_shop(pg_temp.ctx('s2')::uuid, '{"active":false}');
reset role;

set role anon;
select pg_temp.ok(not (get_shop_public('other')->>'open')::boolean, 'switched-off shop is closed to customers');
select pg_temp.ok((get_availability('other', pg_temp.ctx('day')::date, pg_temp.ctx('svc2')::uuid)->>'closed')::boolean, 'switched-off shop has no times');
select pg_temp.ok((get_booking_public(pg_temp.ctx('k1')::uuid)->>'first_name') = 'Luka', 'confirmation page reads booking by id');
select pg_temp.ok(get_booking_public(pg_temp.ctx('k1')::uuid) ? 'customer_phone' = false, 'confirmation page hides phone number');
reset role;

-- reminders: a booking tomorrow
set role service_role;
do $$
declare r jsonb; tom date := (now() at time zone 'Asia/Tbilisi')::date + 1; t text;
begin
  -- find an open day: if tomorrow is Monday, open it for this test
  update shops set hours = hours || jsonb_build_object(extract(dow from tom)::int::text, '["08:00","22:00"]'::jsonb) where slug = 'strop';
  r := create_booking(jsonb_build_object('slug','strop','service_id',pg_temp.ctx('svc'),'date',tom,'time','21:00',
                      'name','Tomorrow Guy','phone','599111222','pay_choice','shop','barber_id',pg_temp.ctx('b1')));
  perform pg_temp.ok(jsonb_array_length(due_reminders()) = 1, 'tomorrow''s booking is due a reminder');
  perform mark_sms(array[(r->>'id')::uuid], 'remind');
  perform pg_temp.ok(jsonb_array_length(due_reminders()) = 0, 'reminder not sent twice');
end $$;
reset role;

-- concurrency guard: raw insert overlapping a live booking must fail at the constraint level
do $$ begin
  perform pg_temp.err(format($q$insert into bookings (shop_id, code, barber_id, service_id, items, starts_at, ends_at, price, pay_choice, status, customer_name, customer_phone)
    select shop_id, 'ZZZZZZ', barber_id, service_id, items, starts_at + interval '5 minutes', ends_at, price, 'shop', 'booked', 'x', '555555555' from bookings where id = %L$q$, pg_temp.ctx('k1')),
    'no_double_booking', 'database constraint blocks double booking even outside the functions');
end $$;

\echo ALL DB TESTS PASSED
