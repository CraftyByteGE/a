#!/usr/bin/env bash
# Runs every test against a throwaway local Postgres. Needs: Postgres 16 (psql), Node 20+, Playwright.
set -euo pipefail
cd "$(dirname "$0")/.."
export PGHOST=${PGHOST:-/tmp/pgdata} PGPORT=${PGPORT:-54329} PGUSER=${PGUSER:-postgres}
SHOTS=${1:-/tmp/shots}; mkdir -p "$SHOTS"

fresh_db() {
  dropdb --if-exists chairbook && createdb chairbook
  psql -q -v ON_ERROR_STOP=1 -d chairbook -f test/supabase_stub.sql
  psql -q -v ON_ERROR_STOP=1 -d chairbook -f supabase/migrations/001_chairbook.sql
}

echo "== database tests"
fresh_db
OUT=$(psql -q -d chairbook -f test/db_test.sql 2>&1 || true)
echo "$OUT" | grep -E "FAIL|ERROR|PASSED" || true
echo "   checks passed: $(echo "$OUT" | grep -c "ok -" || true)"
echo "$OUT" | grep -q "ALL DB TESTS PASSED"

echo "== browser: booking page"
fresh_db
psql -qAt -d chairbook -c "select admin_create_shop('{\"slug\":\"strop\",\"name\":\"Strop & Steel\",\"address\":\"14 Abashidze St, Tbilisi\",\"phone\":\"+995 555 01 42 00\"}')" >/dev/null
node test/devserver.mjs > /tmp/dev.log 2>&1 & DEV=$!
trap 'kill $DEV 2>/dev/null || true' EXIT
sleep 1.5
node test/e2e_book.mjs "$SHOTS" | tail -3
kill $DEV; sleep 0.5

echo "== browser: whole system"
fresh_db
node test/devserver.mjs > /tmp/dev.log 2>&1 & DEV=$!
sleep 1.5
node test/e2e_full.mjs "$SHOTS"
