// End-to-end: platform admin → new shop → owner settings & bank → customer pays → panel → staff → reminders.
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const BASE = 'http://localhost:4321', OUT = process.argv[2] || '/tmp/shots';
const PG = ['-h', '/tmp/pgdata', '-p', '54329', '-U', 'postgres', '-d', 'chairbook', '-At', '-c'];
const sql = q => execFileSync('psql', [...PG, q]).toString().trim();
let failures = 0;
const ok = (c, m) => { if (c) console.log('ok -', m); else { failures++; console.error('FAIL -', m); } };
const errors = [];
const watch = p => { p.on('pageerror', e => errors.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|fonts\.g|Failed to load resource|Failed to fetch/.test(m.text())) errors.push(m.text()); }); };

// platform admin account
await fetch(`${BASE}/supabase/auth/v1/admin/users`, { method: 'POST', headers: { apikey: 'sb_secret_test', 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'me@platform.ge', password: 'admin-pass-1' }) });
sql(`insert into platform_admins select id from auth.users where email='me@platform.ge' on conflict do nothing`);

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const page = await ctx.newPage(); watch(page);

// --- admin creates a shop
await page.goto(`${BASE}/admin`);
await page.fill('#lemail', 'me@platform.ge'); await page.fill('#lpass', 'admin-pass-1'); await page.click('#loginForm button');
await page.waitForSelector('#appView:not([hidden])');
await page.fill('#nName', 'Kudi Barbers');
ok(await page.inputValue('#nSlug') === 'kudi-barbers', 'web address suggested from name');
await page.fill('#nAddr', '5 Rustaveli Ave, Tbilisi'); await page.fill('#nPhone', '+995 599 00 11 22');
await page.fill('#nEmail', 'owner@kudi.ge'); await page.fill('#nPass', 'owner-pass-1');
await page.click('#newShop button[type=submit]');
await page.waitForSelector('tr[data-id]');
await page.screenshot({ path: `${OUT}/admin.png`, fullPage: true });
ok((await page.textContent('#shops')).includes('Kudi Barbers'), 'admin sees new shop in list');
await page.fill('#nName', 'Dup'); await page.fill('#nSlug', 'kudi-barbers'); await page.fill('#nEmail', 'x@y.ge'); await page.fill('#nPass', 'xxxxxxxx1');
await page.click('#newShop button[type=submit]'); await page.waitForTimeout(500);
ok((await page.textContent('#newErr')).includes('already used'), 'duplicate web address refused');

// --- owner logs in, sets up shop
const owner = await ctx.newPage(); watch(owner);
await owner.goto(`${BASE}/panel`);
await owner.evaluate(() => localStorage.clear());
await owner.goto(`${BASE}/panel`);
await owner.click('[data-plang="en"]').catch(() => {});
await owner.fill('#lemail', 'owner@kudi.ge'); await owner.fill('#lpass', 'owner-pass-1'); await owner.click('#loginBtn');
await owner.waitForSelector('.kpis');
await owner.click('[data-plang="en"]'); await owner.waitForSelector('.kpis');
ok((await owner.textContent('#shopName')) === 'Kudi Barbers', 'owner lands in their shop');
await owner.goto(`${BASE}/panel#settings`); await owner.waitForSelector('.snav');
await owner.screenshot({ path: `${OUT}/settings-shop.png`, fullPage: true });
// rename barbers
await owner.click('[data-stab="barbers"]');
await owner.click('[data-edit-barber]:not([data-edit-barber=""])');
await owner.fill('#bName', 'Luka'); await owner.fill('#bTEn', 'Fades'); await owner.click('#barForm button[type=submit]');
await owner.waitForTimeout(400);
ok((await owner.textContent('#spanel')).includes('Luka'), 'barber renamed');
// open Monday too
await owner.click('[data-stab="hours"]');
await owner.check('#hOpen1'); await owner.fill('#hFrom1', '10:00'); await owner.fill('#hTo1', '19:00');
await owner.click('[data-save="hours"]'); await owner.waitForTimeout(500);
ok(sql(`select hours->>'1' from shops where slug='kudi-barbers'`) === '["10:00", "19:00"]', 'Monday hours saved');
// bad bank keys then good
await owner.click('[data-stab="payments"]');
await owner.fill('#tbcId', 'merchant-1'); await owner.fill('#tbcSecret', 'bad'); await owner.click('[data-connect="tbc"]');
await owner.waitForTimeout(600);
ok((await owner.textContent('#tbcErr')).includes('did not accept'), 'wrong TBC keys rejected with a clear message');
await owner.fill('#tbcId', 'merchant-1'); await owner.fill('#tbcSecret', 'good-secret'); await owner.click('[data-connect="tbc"]');
await owner.waitForSelector('input[name=pOnline][value=tbc]:not([disabled])');
await owner.fill('#bogId', 'bog-merchant'); await owner.fill('#bogSecret', 'bog-secret'); await owner.click('[data-connect="bog"]');
await owner.waitForSelector('input[name=pOnline][value=bog]:not([disabled])');
ok(!sql(`select tbc from shop_secrets s join shops x on x.id=s.shop_id where slug='kudi-barbers'`).includes('good-secret'), 'bank secret is stored encrypted');
await owner.check('input[name=pOnline][value=tbc]'); await owner.selectOption('#pMode', 'choice'); await owner.fill('#pDep', '20');
await owner.click('[data-save="payments"]'); await owner.waitForTimeout(500);
await owner.screenshot({ path: `${OUT}/settings-payments.png`, fullPage: true });
ok(sql(`select online_pay from shops where slug='kudi-barbers'`) === 'tbc', 'online payment switched to TBC');

// --- customer books with a TBC deposit
const cust = await browser.newPage({ viewport: { width: 390, height: 844 } }); watch(cust);
await cust.goto(`${BASE}/kudi-barbers?lang=en`);
await cust.waitForSelector('.slot:not([disabled])');
await cust.click('.slot:not([disabled])');
await cust.fill('#name', 'Dato Kapanadze'); await cust.fill('#phone', '599123456');
await cust.click('[data-pay="deposit"]');
ok((await cust.textContent('#summary')).includes('To pay now: 7'), 'deposit shown as 7 ₾ of 35 ₾');
await cust.screenshot({ path: `${OUT}/book-deposit-phone.png`, fullPage: true });
await cust.click('#submit');
await cust.waitForURL(/mock\/checkout/);
await cust.click('#pay');
await cust.waitForURL(/\/b\//); await cust.waitForSelector('.code');
const st1 = await cust.textContent('.done');
ok(/See you soon, Dato/.test(st1) && /Paid online\s*7/.test(st1), 'after paying, booking is confirmed with 7 ₾ paid');
await cust.screenshot({ path: `${OUT}/paid-confirmed.png`, fullPage: true });

// --- BOG: failed payment releases the time
sql(`update shops set online_pay='bog' where slug='kudi-barbers'`);
await cust.goto(`${BASE}/kudi-barbers?lang=en`); await cust.waitForSelector('.slot:not([disabled])');
const failTime = await cust.$eval('.slot:not([disabled])', b => b.dataset.time);
await cust.click(`.slot[data-time="${failTime}"]`);
await cust.fill('#name', 'Fail Test'); await cust.fill('#phone', '599000000'); await cust.click('[data-pay="full"]'); await cust.click('#submit');
await cust.waitForURL(/mock\/checkout/); await cust.click('#fail');
await cust.waitForURL(/\/b\//); await cust.waitForSelector('.stamp');
ok((await cust.textContent('.done')).includes('didn’t go through'), 'failed BOG payment shows a clear message');

// --- BOG: paid but the bank callback never arrives → page re-checks with the bank
await cust.goto(`${BASE}/kudi-barbers?lang=en`); await cust.waitForSelector('.slot:not([disabled])');
await cust.click('.slot:not([disabled])');
await cust.fill('#name', 'Lost Callback'); await cust.fill('#phone', '599000001'); await cust.click('[data-pay="full"]'); await cust.click('#submit');
await cust.waitForURL(/mock\/checkout/); await cust.click('#paynocb');
await cust.waitForURL(/\/b\//);
await cust.waitForFunction(() => document.querySelector('.done') && /See you soon/.test(document.querySelector('.done').textContent), null, { timeout: 15000 });
ok(true, 'payment confirmed even when the bank callback is lost');

// --- owner sees bookings, marks done
await owner.goto(`${BASE}/panel#day`); await owner.reload(); await owner.waitForSelector('.bk');
await owner.screenshot({ path: `${OUT}/panel-day.png`, fullPage: true });
const nBk = await owner.$$eval('.bk', x => x.length);
ok(nBk >= 2, `day sheet shows the paid bookings (${nBk})`);
await owner.click('.bk >> nth=0');
await owner.waitForSelector('#drawer:not([hidden])');
await owner.screenshot({ path: `${OUT}/panel-drawer.png` });
await owner.click('[data-status="done"]'); await owner.waitForTimeout(600);
ok(Number(sql(`select count(*) from bookings k join shops s on s.id=k.shop_id where slug='kudi-barbers' and k.status='done'`)) === 1, 'owner marked a booking done');
// walk-in
await owner.click('[data-act="add"]'); await owner.waitForSelector('#addForm');
await owner.fill('#aTime', '18:10'); await owner.fill('#aName', 'Walk In'); await owner.fill('#aPhone', '555111222');
await owner.click('#addForm button[type=submit]'); await owner.waitForTimeout(700);
ok((await owner.textContent('#sched')).includes('Walk In'), 'walk-in booking added from panel');
await owner.goto(`${BASE}/panel#income`); await owner.waitForSelector('.chart svg');
await owner.screenshot({ path: `${OUT}/panel-income.png`, fullPage: true });
ok((await owner.textContent('.kpis')).includes('35'), 'income shows the completed 35 ₾ booking');
await owner.goto(`${BASE}/panel#upcoming`); await owner.waitForSelector('#upTbl');
await owner.click('[data-plang="ka"]'); await owner.waitForTimeout(500);
await owner.screenshot({ path: `${OUT}/panel-upcoming-ka.png`, fullPage: true });
await owner.click('[data-plang="en"]');

// --- staff login
await owner.goto(`${BASE}/panel#settings`); await owner.waitForSelector('.snav'); await owner.click('[data-stab="logins"]');
await owner.fill('#uEmail', 'luka@kudi.ge'); await owner.fill('#uPass', 'luka-pass-1'); await owner.click('[data-save="login"]');
await owner.waitForTimeout(700);
ok((await owner.textContent('#spanel')).includes('luka@kudi.ge'), 'owner added a staff login');
const staffCtx = await browser.newContext(); const staff = await staffCtx.newPage(); watch(staff);
await staff.goto(`${BASE}/panel`); await staff.fill('#lemail', 'luka@kudi.ge'); await staff.fill('#lpass', 'luka-pass-1'); await staff.click('#loginBtn');
await staff.waitForSelector('.kpis');
const tabs = await staff.textContent('#tabs');
ok(!/Income|შემოსავალი/.test(tabs) && !/Settings|პარამეტრები/.test(tabs), 'staff has no income or settings tabs');
const r = await staff.evaluate(async () => { const m = await import('/assets/core.js'); try { await m.rpc('panel_range', { p_shop: (await m.rpc('my_shops', {}, { withUser: true })).shops[0].id, p_from: '2026-01-01', p_to: '2026-12-31' }, { withUser: true }); return 'allowed'; } catch (e) { return e.code; } });
ok(r === 'not_allowed', 'staff blocked from income data at the database too');
const r2 = await staff.evaluate(async () => { const m = await import('/assets/core.js'); try { await m.api('/api/shop/secrets', { shop_id: (await m.rpc('my_shops', {}, { withUser: true })).shops[0].id, provider: 'tbc', remove: true }, { withUser: true }); return 'allowed'; } catch (e) { return e.code; } });
ok(r2 === 'not_allowed', 'staff cannot change bank keys');

// --- reminders cron
const tomorrow = sql(`select to_char((now() at time zone 'Asia/Tbilisi')::date + 1, 'YYYY-MM-DD')`);
sql(`update shops set hours = hours || jsonb_build_object(extract(dow from date '${tomorrow}')::int::text, '["08:00","22:00"]'::jsonb) where slug='kudi-barbers'`);
const svc = sql(`select v.id from services v join shops s on s.id=v.shop_id where slug='kudi-barbers' and not is_addon order by sort limit 1`);
const resB = await fetch(`${BASE}/api/book`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slug: 'kudi-barbers', service_id: svc, date: tomorrow, time: '12:00', name: 'Remind Me', phone: '599777888', lang: 'ka', pay_choice: 'shop' }) });
ok(resB.ok, 'API booking for tomorrow');
const noAuth = await fetch(`${BASE}/api/cron/reminders`);
ok(noAuth.status === 401, 'reminder job refuses calls without the secret');
const cron = await (await fetch(`${BASE}/api/cron/reminders`, { headers: { Authorization: 'Bearer cron-test' } })).json();
ok(cron.sent >= 1, `reminders sent: ${JSON.stringify(cron)}`);
const log = await (await fetch(`${BASE}/mock/log`)).json();
const lastSms = log.sms[log.sms.length - 1];
ok(lastSms.destination === '995599777888' && /შეხსენება/.test(lastSms.content), 'Georgian reminder SMS to +995 number: ' + lastSms.content);

// --- shop switched off by admin
sql(`update shops set paid_until = (now() at time zone 'Asia/Tbilisi')::date - 1 where slug='kudi-barbers'`);
await cust.goto(`${BASE}/kudi-barbers?lang=en`); await cust.waitForSelector('#unavailable:not([hidden])');
ok(true, 'expired subscription shows “call us” instead of booking');
await cust.screenshot({ path: `${OUT}/book-unavailable.png` });

ok(errors.length === 0, 'no page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
await browser.close();
console.log(failures ? `E2E FULL: ${failures} FAILED` : 'E2E FULL: ALL PASSED');
process.exit(failures ? 1 : 0);
