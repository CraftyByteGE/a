import { rpc, api, login, logout, session, $, $$, esc, addDays, dow, fmtDate, mins, hhmm, money, money0, tr, toast, applyAccent, ApiError } from './core.js';

// ---------- language (panel: Georgian / English) ----------
const KA = {
  'Shop panel': 'სალონის პანელი', 'Email': 'ელფოსტა', 'Password': 'პაროლი', 'Log in': 'შესვლა', 'Log out': 'გასვლა',
  'Forgot your password? Ask the shop owner or your platform contact to set a new one.': 'დაგავიწყდათ პაროლი? სთხოვეთ სალონის მფლობელს ან პლატფორმის ადმინისტრატორს ახლის დაყენება.',
  'Booking page ↗': 'ჯავშნის გვერდი ↗', 'Platform admin': 'ადმინისტრირება',
  'Day': 'დღე', 'Income': 'შემოსავალი', 'Upcoming': 'მომავალი', 'Settings': 'პარამეტრები', 'Today': 'დღეს',
  'Day sheet': 'დღის განრიგი', 'Add booking': 'ჯავშნის დამატება', 'Bookings': 'ჯავშნები', 'done': 'შესრულებული', 'still to come': 'მოსალოდნელი',
  'Taken this day': 'დღის შემოსავალი', 'due in shop': 'ადგილზე გადასახდელი', 'prepaid online': 'წინასწარ გადახდილი', 'Nothing outstanding': 'დავალიანება არ არის',
  'Chair time booked': 'სავარძლის დატვირთვა', 'chair-hours': 'სავარძელ-საათი', 'of': '/', 'Closed': 'დაკეტილია', 'Next up': 'შემდეგი',
  'Nothing booked': 'ჯავშანი არ არის', 'Booked': 'დაჯავშნილი', 'Done': 'შესრულდა', 'No-show': 'არ მოვიდა', 'Cancelled': 'გაუქმდა', 'Awaiting payment': 'ელოდება გადახდას',
  'The shop is closed this day.': 'ამ დღეს სალონი დაკეტილია.', 'day off': 'დასვენება',
  'Mark done': 'შესრულებულად მონიშვნა', 'paid in shop': 'გადახდილი ადგილზე', 'Cancel booking': 'ჯავშნის გაუქმება', 'Set back to booked': 'დაბრუნება დაჯავშნილზე',
  'Copy': 'კოპირება', 'Copied': 'დაკოპირდა', 'Code': 'კოდი', 'When': 'როდის', 'Barber': 'ბარბერი', 'Service': 'მომსახურება', 'Add-ons': 'დამატებით',
  'Price': 'ფასი', 'Paid online': 'ონლაინ გადახდილი', 'Due in shop': 'ადგილზე გადასახდელი', 'Customer note': 'კლიენტის კომენტარი', 'Staff note': 'შენიშვნა (მხოლოდ თანამშრომლებისთვის)',
  'Booked online': 'ონლაინ ჯავშანი', 'Added in panel': 'დამატებულია პანელიდან', 'Close': 'დახურვა',
  'Name': 'სახელი', 'Phone': 'ტელეფონი', 'Date': 'თარიღი', 'Time': 'დრო', 'Note': 'შენიშვნა', 'Save booking': 'ჯავშნის შენახვა',
  'Phone or walk-in booking. Any time is allowed; the barber must be free.': 'სატელეფონო ან ადგილზე ჯავშანი. ნებისმიერი დრო შეიძლება, ოღონდ ბარბერი თავისუფალი უნდა იყოს.',
  'Last': 'ბოლო', 'days': 'დღე', 'vs previous': 'წინა პერიოდთან', 'No earlier period to compare': 'შესადარებელი პერიოდი არ არის',
  'Cuts done': 'შესრულებული', 'Average ticket': 'საშუალო ჩეკი', 'No-shows': 'არ მოსულა', 'Paid online': 'ონლაინ', 'Paid in shop': 'ადგილზე',
  'Average per open day': 'საშუალოდ სამუშაო დღეში', 'By barber': 'ბარბერების მიხედვით', 'Services': 'მომსახურებები', 'Payments': 'გადახდები',
  'Done': 'შესრულდა', 'Share': 'წილი', 'Chosen at booking': 'არჩეული გადახდა', 'Pay in shop': 'ადგილზე', 'Full online': 'სრულად ონლაინ', 'Deposit online': 'ავანსი ონლაინ',
  'Search name, phone or code': 'ძებნა: სახელი, ტელეფონი, კოდი', 'No upcoming bookings yet.': 'მომავალი ჯავშნები ჯერ არ არის.', 'No bookings match that search.': 'ძებნის შედეგი არ არის.',
  'Customer': 'კლიენტი', 'Payment': 'გადახდა',
  'Shop': 'სალონი', 'Hours': 'სამუშაო საათები', 'Barbers': 'ბარბერები', 'Days off': 'დასვენების დღეები', 'Logins': 'მომხმარებლები', 'SMS': 'SMS',
  'Save': 'შენახვა', 'Saved': 'შენახულია', 'Shop name': 'სალონის სახელი', 'Address': 'მისამართი', 'Accent colour': 'ძირითადი ფერი',
  'Short line under the title': 'მოკლე ტექსტი სათაურის ქვეშ', 'Default language for customers': 'კლიენტების ენა ნაგულისხმევად',
  'Your booking page': 'თქვენი ჯავშნის გვერდი', 'Open': 'ღიაა', 'from': 'დან', 'to': 'მდე',
  'Time grid': 'დროის ბიჯი', 'minutes': 'წუთი', 'Earliest online booking': 'ონლაინ ჯავშანი უადრეს', 'minutes ahead': 'წუთით ადრე', 'How far ahead customers can book': 'რამდენი დღით ადრე შეიძლება ჯავშანი',
  'Add service': 'მომსახურების დამატება', 'Add-on': 'დამატებითი', 'Active': 'აქტიური', 'Hidden': 'დამალული', 'Edit': 'რედაქტირება',
  'Name (Georgian)': 'სახელი (ქართ.)', 'Name (English)': 'სახელი (ინგლ.)', 'Name (Russian)': 'სახელი (რუს.)',
  'Description (Georgian)': 'აღწერა (ქართ.)', 'Description (English)': 'აღწერა (ინგლ.)', 'Description (Russian)': 'აღწერა (რუს.)',
  'Price (₾)': 'ფასი (₾)', 'Length (minutes)': 'ხანგრძლივობა (წუთი)', 'Order': 'რიგი', 'Show on booking page': 'გამოჩნდეს ჯავშნის გვერდზე',
  'Is an add-on (extra to a main service)': 'დამატებითი მომსახურებაა', 'Add barber': 'ბარბერის დამატება', 'Title / speciality': 'სპეციალობა',
  'Add day off': 'დასვენების დამატება', 'Whole shop': 'მთელი სალონი', 'First day': 'პირველი დღე', 'Last day': 'ბოლო დღე', 'Reason (optional)': 'მიზეზი (არასავალდებულო)',
  'Remove': 'წაშლა', 'No days off planned.': 'დასვენების დღეები არ არის.',
  'How customers pay': 'როგორ იხდიან კლიენტები', 'Allow paying in the shop': 'ადგილზე გადახდის დაშვება', 'Online payment': 'ონლაინ გადახდა',
  'Off': 'გამორთული', 'Connected': 'დაკავშირებულია', 'Not connected': 'არ არის დაკავშირებული',
  'Customers choose full or deposit': 'კლიენტი ირჩევს: სრულად ან ავანსი', 'Always full price': 'ყოველთვის სრული ფასი', 'Always a deposit': 'ყოველთვის ავანსი', 'Deposit %': 'ავანსი %',
  'Connect': 'დაკავშირება', 'Disconnect': 'გათიშვა', 'Client ID': 'Client ID', 'Client secret': 'Client Secret',
  'Send SMS confirmations and day-before reminders': 'SMS დადასტურება და შეხსენება ვიზიტის წინა დღეს',
  'Add login': 'მომხმარებლის დამატება', 'Owner': 'მფლობელი', 'Staff': 'თანამშრომელი', 'Role': 'როლი', 'Linked barber': 'მიბმული ბარბერი', 'None': 'არცერთი',
  'New password': 'ახალი პაროლი', 'Set password': 'პაროლის დაყენება', 'you': 'თქვენ', 'Password updated': 'პაროლი განახლდა', 'Login added': 'მომხმარებელი დაემატა',
  'Staff can see the day sheet and upcoming bookings and mark bookings done. Only owners see income and settings.': 'თანამშრომელი ხედავს განრიგს და მომავალ ჯავშნებს, შეუძლია მონიშნოს შესრულებულად. შემოსავალს და პარამეტრებს მხოლოდ მფლობელი ხედავს.',
  'Something went wrong. Please try again.': 'რაღაც შეცდომა მოხდა. სცადეთ თავიდან.',
  'That barber is busy at that time.': 'ბარბერი ამ დროს დაკავებულია.',
  'Closing time must be after opening time.': 'დახურვის დრო გახსნის შემდეგ უნდა იყოს.',
  'Keep at least one way to pay switched on.': 'ჩართული უნდა იყოს გადახდის ერთი გზა მაინც.',
  'Connect the bank first.': 'ჯერ ბანკი დააკავშირეთ.',
  'You don’t have a shop yet. Ask your platform contact to add you.': 'სალონი ჯერ არ გაქვთ. სთხოვეთ პლატფორმის ადმინისტრატორს დაგამატოთ.',
  'Online booking is switched off for this shop. Customers see a “call us” message. Contact your platform provider.': 'ამ სალონისთვის ონლაინ ჯავშანი გამორთულია. კლიენტები ხედავენ შეტყობინებას „დაგვირეკეთ“. დაუკავშირდით პლატფორმას.',
  'Pick a barber.': 'აირჩიეთ ბარბერი.', 'Enter the customer’s name.': 'შეიყვანეთ კლიენტის სახელი.', 'Enter a phone number.': 'შეიყვანეთ ტელეფონი.',
};
let lang = (() => { try { return localStorage.getItem('chairbook.plang') || 'ka'; } catch { return 'ka'; } })();
const t = s => (lang === 'ka' && KA[s]) || s;
const STATUS = { booked: 'Booked', done: 'Done', noshow: 'No-show', cancelled: 'Cancelled', pending: 'Awaiting payment' };
const ERR = { slot_taken: 'That barber is busy at that time.', bad_hours: 'Closing time must be after opening time.', need_a_payment_option: 'Keep at least one way to pay switched on.', online_pay_unavailable: 'Connect the bank first.', pick_barber: 'Pick a barber.', bad_name: 'Enter the customer’s name.', bad_phone: 'Enter a phone number.' };
function errText(e) {
  if (e instanceof ApiError && ERR[e.code]) return t(ERR[e.code]);
  if (e instanceof ApiError && e.status && e.status < 500 && e.message && !/^[a-z_]+$/.test(e.message)) return e.message;
  return t('Something went wrong. Please try again.');
}

const tbilisiToday = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tbilisi' }).format(new Date());
const P = { seq: 0, shops: [], admin: false, shop: null, tab: 'day', date: tbilisiToday(), day: null, period: 14, q: '', settings: null, stab: 'shop' };
const isOwner = () => P.shop && P.shop.role === 'owner';
const cur = () => (P.day && P.day.shop.currency) || 'GEL';

// ---------- boot / login ----------
async function boot() {
  applyLang();
  if (!session()) return showLogin();
  try {
    const me = await rpc('my_shops', {}, { withUser: true });
    P.shops = me.shops; P.admin = me.admin;
  } catch (e) { return showLogin(); }
  if (!P.shops.length) {
    if (P.admin) { location.href = '/admin'; return; }
    $('#appView').hidden = false; $('#loginView').hidden = true;
    $('#view').innerHTML = `<p class="notice" style="margin-top:24px">${esc(t('You don’t have a shop yet. Ask your platform contact to add you.'))}</p>`;
    return;
  }
  let saved; try { saved = localStorage.getItem('chairbook.shop'); } catch {}
  P.shop = P.shops.find(s => s.id === saved) || P.shops[0];
  $('#loginView').hidden = true; $('#appView').hidden = false;
  P.tab = (location.hash.slice(1) || 'day');
  await openShop();
}

function showLogin() { $('#appView').hidden = true; $('#loginView').hidden = false; $('#lemail').focus(); }

$('#loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  $('#loginErr').textContent = '';
  $('#loginBtn').disabled = true;
  try { await login($('#lemail').value.trim(), $('#lpass').value); await boot(); }
  catch (err) { $('#loginErr').textContent = err.status === 400 ? (lang === 'ka' ? 'ელფოსტა ან პაროლი არასწორია.' : 'Wrong email or password.') : t('Something went wrong. Please try again.'); }
  $('#loginBtn').disabled = false;
});
$('#logout').addEventListener('click', () => { logout(); location.reload(); });

function applyLang() {
  document.documentElement.lang = lang;
  $$('[data-t]').forEach(el => { el.dataset.en ||= el.textContent; el.textContent = t(el.dataset.en); });
  $$('#langSeg button').forEach(b => b.setAttribute('aria-pressed', b.dataset.plang === lang));
}

async function openShop() {
  try { localStorage.setItem('chairbook.shop', P.shop.id); } catch {}
  P.settings = null; P.day = null;
  $('#shopName').textContent = P.shop.name;
  const pick = $('#shopPick');
  pick.hidden = P.shops.length < 2;
  pick.innerHTML = P.shops.map(s => `<option value="${s.id}" ${s.id === P.shop.id ? 'selected' : ''}>${esc(s.name)}</option>`).join('');
  $('#publicLink').href = `/${P.shop.slug}`;
  $('#adminLink').hidden = !P.admin;
  $('#shopOff').hidden = P.shop.active;
  $('#shopOff').textContent = t('Online booking is switched off for this shop. Customers see a “call us” message. Contact your platform provider.');
  if (!isOwner() && ['income', 'settings'].includes(P.tab)) P.tab = 'day';
  renderTabs();
  await show();
}
$('#shopPick').addEventListener('change', e => { P.shop = P.shops.find(s => s.id === e.target.value); openShop(); });

function renderTabs() {
  const tabs = [['day', 'Day'], ...(isOwner() ? [['income', 'Income']] : []), ['upcoming', 'Upcoming'], ...(isOwner() ? [['settings', 'Settings']] : [])];
  $('#tabs').innerHTML = tabs.map(([k, l]) => `<a href="#${k}" aria-current="${P.tab === k ? 'page' : 'false'}">${esc(t(l))}</a>`).join('');
}
window.addEventListener('hashchange', () => { P.tab = location.hash.slice(1) || 'day'; renderTabs(); show(); });

async function show() {
  closeDrawer();
  const my = ++P.seq;
  const v = $('#view');
  v.innerHTML = `<p class="empty"><span class="spinner"></span></p>`;
  try {
    if (P.tab === 'income' && isOwner()) await showIncome();
    else if (P.tab === 'upcoming') await showUpcoming();
    else if (P.tab === 'settings' && isOwner()) await showSettings();
    else await showDay();
  } catch (e) {
    if (my !== P.seq) return;
    if (e.code === 'login_required') return showLogin();
    console.error(e);
    v.innerHTML = `<p class="notice" style="margin-top:24px">${esc(errText(e))}</p>`;
  }
}

// ---------- DAY ----------
async function loadDay() {
  P.day = await rpc('panel_day', { p_shop: P.shop.id, p_date: P.date }, { withUser: true });
  applyAccent(P.day.shop.accent);
}

async function showDay() {
  const my = P.seq;
  await loadDay();
  if (my !== P.seq) return;
  const d = P.day, c = cur();
  const live = d.bookings.filter(b => !['cancelled', 'expired'].includes(b.status));
  const doneN = d.bookings.filter(b => b.status === 'done').length, upN = d.bookings.filter(b => b.status === 'booked' || b.status === 'pending').length;
  const taken = d.bookings.reduce((a, b) => a + income(b), 0);
  const dueShop = d.bookings.filter(b => b.status === 'booked').reduce((a, b) => a + (Number(b.price) - Number(b.paid_online)), 0);
  const prepaid = d.bookings.filter(b => b.status === 'booked').reduce((a, b) => a + Number(b.paid_online), 0);
  const h = d.hours, chairs = d.barbers.filter(b => b.active && !b.off).length;
  const cap = h ? (mins(h[1]) - mins(h[0])) * chairs : 0;
  const used = live.reduce((a, b) => a + b.minutes, 0);
  const nowM = mins(d.now);
  const nextUp = P.date === d.today ? live.filter(b => b.status === 'booked' && mins(b.time) >= nowM).sort((a, b) => a.time.localeCompare(b.time))[0] : null;
  const isToday = P.date === d.today;
  const label = (isToday ? t('Today') + ' · ' : '') + fmtDate(P.date, lang, { weekday: 'long', day: 'numeric', month: 'long' });

  $('#view').innerHTML = `
    <div class="pbar">
      <h1>${esc(t('Day sheet'))}</h1>
      <div class="datenav">
        <button class="icon-btn" data-act="prev" aria-label="Previous day">‹</button>
        <div class="lbl">${esc(label)}</div>
        <button class="icon-btn" data-act="next" aria-label="Next day">›</button>
        <button class="btn ghost small" data-act="today">${esc(t('Today'))}</button>
        <input type="date" id="jump" value="${P.date}" aria-label="Date" style="width:auto;padding:6px 8px">
        <button class="btn small" data-act="add">+ ${esc(t('Add booking'))}</button>
      </div>
    </div>
    <div class="kpis">
      <div class="kpi"><span class="k">${esc(t('Bookings'))}</span><span class="v">${live.length}</span><span class="s">${doneN} ${esc(t('done'))} · ${upN} ${esc(t('still to come'))}</span></div>
      ${isOwner() ? `<div class="kpi"><span class="k">${esc(t('Taken this day'))}</span><span class="v">${money0(taken, c)}</span><span class="s">${dueShop || prepaid ? `+ ${money0(dueShop, c)} ${esc(t('due in shop'))}${prepaid ? ` · ${money0(prepaid, c)} ${esc(t('prepaid online'))}` : ''}` : esc(t('Nothing outstanding'))}</span></div>`
      : `<div class="kpi"><span class="k">${esc(t('Next up'))}</span><span class="v">${nextUp ? nextUp.time : '—'}</span><span class="s">${nextUp ? esc(nextUp.customer_name) : esc(t('Nothing booked'))}</span></div>`}
      <div class="kpi"><span class="k">${esc(t('Chair time booked'))}</span><span class="v">${cap ? Math.round(used / cap * 100) + '%' : '—'}</span><span class="s">${cap ? `${Math.round(used / 6) / 10} ${esc(t('of'))} ${Math.round(cap / 6) / 10} ${esc(t('chair-hours'))}` : esc(t('Closed'))}</span></div>
      <div class="kpi"><span class="k">${esc(t('Next up'))}</span><span class="v">${nextUp ? nextUp.time : '—'}</span><span class="s">${nextUp ? esc(nextUp.customer_name + ' · ' + barberName(nextUp.barber_id)) : esc(isToday ? t('Nothing booked') : '—')}</span></div>
    </div>
    <section class="psec">
      <div class="psec-h"><h2>${esc(fmtDate(P.date, lang, { weekday: 'long', day: 'numeric', month: 'long' }))}</h2>
        <div class="legend">${['booked', 'done', 'noshow', 'cancelled'].map(s => `<span class="st-${s}"><i class="sw"></i>${esc(t(STATUS[s]))}</span>`).join('')}</div></div>
      <div class="sched-wrap"><div class="sched" id="sched"></div></div>
    </section>`;
  if (!isOwner()) $$('.kpi')[3].remove();
  $('#jump').addEventListener('change', e => { if (e.target.value) { P.date = e.target.value; showDay(); } });
  renderSched();
}

function income(b) {
  if (b.status === 'done') return Number(b.price);
  if (b.status === 'noshow') return Number(b.paid_online);
  return 0;
}
function barberName(id) {
  const lists = [P.day && P.day.barbers, P.settings && P.settings.barbers].filter(Boolean).flat();
  return (lists.find(b => b.id === id) || {}).name || '—';
}
function itemsText(b) { return b.items.map(i => tr(i.name, lang)).join(' + '); }

function renderSched() {
  const d = P.day, el = $('#sched');
  const list = d.bookings;
  let open = d.hours ? mins(d.hours[0]) : null, close = d.hours ? mins(d.hours[1]) : null;
  for (const b of list) { const s = mins(b.time), e = s + b.minutes; open = open === null ? s : Math.min(open, s); close = close === null ? e : Math.max(close, e); }
  if (open === null) { el.style.gridTemplateColumns = '1fr'; el.innerHTML = `<div class="empty">${esc(t('The shop is closed this day.'))}</div>`; return; }
  open = Math.floor(open / 30) * 30; close = Math.ceil(close / 30) * 30;
  const cols = d.barbers;
  if (!cols.length) { el.innerHTML = `<div class="empty">—</div>`; return; }
  el.style.gridTemplateColumns = `58px repeat(${cols.length}, minmax(140px, 1fr))`;
  el.style.minWidth = `${58 + 140 * cols.length}px`;
  el.style.gridAutoRows = '20px';
  const rows = (close - open) / 15;
  let html = `<div style="grid-row:1/span 2"></div>` + cols.map((c, i) => {
    const n = list.filter(b => b.barber_id === c.id && !['cancelled'].includes(b.status)).length;
    return `<div class="sh${c.off ? ' off' : ''}" style="grid-row:1/span 2;grid-column:${i + 2}"><span class="av">${esc(c.name.charAt(0).toUpperCase())}</span>${esc(c.name)}${c.off ? ` · ${esc(t('day off'))}` : ''}<span class="cnt">${n}</span></div>`;
  }).join('');
  for (let r = 0; r < rows; r += 2) {
    const m = open + r * 15, half = m % 60 !== 0, row = r + 3;
    html += `<div class="tl${half ? ' half' : ''}" style="grid-row:${row}/span 2;grid-column:1">${hhmm(m)}</div>`;
    cols.forEach((c, i) => { html += `<div class="cell${half ? ' half' : ''}${c.off ? ' off' : ''}" style="grid-row:${row}/span 2;grid-column:${i + 2}"></div>`; });
  }
  const sorted = [...list].sort((a, b) => (a.status === 'cancelled') - (b.status === 'cancelled'));
  for (const b of sorted) {
    const ci = cols.findIndex(c => c.id === b.barber_id); if (ci < 0) continue;
    const start = Math.floor((mins(b.time) - open) / 15), span = Math.max(2, Math.ceil(b.minutes / 15));
    html += `<button class="bk st-${b.status} ${b.status}" data-booking="${b.id}" style="grid-row:${start + 3}/span ${span};grid-column:${ci + 2}">
      <span class="bt"><span>${b.time}–${b.end}</span><span>${money0(b.price, cur())}</span></span>
      <span class="bn">${esc(b.customer_name)}</span>${span > 2 ? `<span class="bs">${esc(itemsText(b))}${b.status !== 'booked' ? ' · ' + esc(t(STATUS[b.status])) : ''}</span>` : ''}</button>`;
  }
  if (P.date === d.today) {
    const nm = mins(d.now);
    if (nm >= open && nm <= close) html += `<div class="now" style="left:58px;top:${40 + (nm - open) / 15 * 20}px"><span>${d.now}</span></div>`;
  }
  el.innerHTML = html;
}

// ---------- drawer ----------
function openDrawer(html) { const d = $('#drawer'); d.innerHTML = html; d.hidden = false; $('#scrim').hidden = false; const f = d.querySelector('input,select,button'); if (f) f.focus(); }
function closeDrawer() { $('#drawer').hidden = true; $('#scrim').hidden = true; P.openBooking = null; }
$('#scrim').addEventListener('click', closeDrawer);
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#drawer').hidden) closeDrawer(); });

function bookingDrawer(b) {
  P.openBooking = b;
  const c = cur(), due = Number(b.price) - Number(b.paid_online);
  const acts = b.status === 'booked'
    ? `<button class="btn good wide" data-status="done">${esc(t('Mark done'))}${due > 0 ? ` · ${money(due, c)} ${esc(t('paid in shop'))}` : ''}</button>
       <button class="btn ghost" data-status="noshow">${esc(t('No-show'))}</button><button class="btn danger" data-status="cancelled">${esc(t('Cancel booking'))}</button>`
    : b.status === 'pending' ? '' : `<button class="btn ghost wide" data-status="booked">${esc(t('Set back to booked'))}</button>`;
  const addons = b.items.slice(1).map(i => tr(i.name, lang)).join(', ');
  openDrawer(`
    <div class="dr-h"><div><span class="pill st-${b.status}">${esc(t(STATUS[b.status] || b.status))}</span><h3 style="margin-top:8px">${esc(b.customer_name)}</h3></div>
      <button class="icon-btn" data-act="close" aria-label="${esc(t('Close'))}">×</button></div>
    <div class="copyline"><span>${esc(b.customer_phone)}</span><button class="linkbtn" data-copy="${esc(b.customer_phone)}">${esc(t('Copy'))}</button></div>
    ${b.customer_email ? `<div class="copyline"><span>${esc(b.customer_email)}</span><button class="linkbtn" data-copy="${esc(b.customer_email)}">${esc(t('Copy'))}</button></div>` : ''}
    <div class="ticket"><div class="ticket-b">
      <div class="row"><span class="k">${esc(t('Code'))}</span><span class="v mono">${esc(b.code)}</span></div>
      <div class="row"><span class="k">${esc(t('When'))}</span><span class="v mono">${esc(fmtDate(b.date, lang, { weekday: 'short', day: 'numeric', month: 'short' }))} · ${b.time}–${b.end}</span></div>
      <div class="row"><span class="k">${esc(t('Barber'))}</span><span class="v">${esc(barberName(b.barber_id))}</span></div>
      <div class="row"><span class="k">${esc(t('Service'))}</span><span class="v">${esc(tr(b.items[0].name, lang))}</span></div>
      ${addons ? `<div class="row"><span class="k">${esc(t('Add-ons'))}</span><span class="v">${esc(addons)}</span></div>` : ''}
      <div class="perf"></div>
      <div class="row"><span class="k">${esc(t('Price'))}</span><span class="v mono">${money(b.price, c)}</span></div>
      <div class="row"><span class="k">${esc(t('Paid online'))}</span><span class="v mono">${money(b.paid_online, c)}${b.provider ? ' · ' + b.provider.toUpperCase() : ''}</span></div>
      <div class="row"><span class="k">${esc(t('Due in shop'))}</span><span class="v mono">${money(due, c)}</span></div>
      <div class="row"><span class="k"></span><span class="v dim">${esc(t(b.source === 'panel' ? 'Added in panel' : 'Booked online'))}</span></div>
    </div></div>
    ${b.note ? `<div><div class="lbl">${esc(t('Customer note'))}</div><p style="margin:4px 0 0">${esc(b.note)}</p></div>` : ''}
    <div class="f"><label for="staffNote">${esc(t('Staff note'))}</label><textarea id="staffNote" maxlength="300">${esc(b.staff_note)}</textarea></div>
    <div class="actions">${acts}</div>
    <p class="err" id="drErr" role="alert"></p>`);
}

async function setStatus(status) {
  const b = P.openBooking; if (!b) return;
  try {
    await rpc('set_booking_status', { p_booking: b.id, p_status: status, p_staff_note: $('#staffNote').value }, { withUser: true });
    toast(t(STATUS[status]));
    closeDrawer();
    if (P.tab === 'upcoming') showUpcoming(); else showDay();
  } catch (e) { $('#drErr').textContent = errText(e); }
}

function addDrawer() {
  const d = P.day;
  const mains = d.services.filter(s => !s.is_addon), adds = d.services.filter(s => s.is_addon);
  const step = d.shop.slot_step || 30;
  openDrawer(`
    <div class="dr-h"><h3>${esc(t('Add booking'))}</h3><button class="icon-btn" data-act="close" aria-label="${esc(t('Close'))}">×</button></div>
    <p class="hint">${esc(t('Phone or walk-in booking. Any time is allowed; the barber must be free.'))}</p>
    <form id="addForm" class="fields" novalidate>
      <div class="f full"><label for="aSvc">${esc(t('Service'))}</label><select id="aSvc">${mains.map(s => `<option value="${s.id}">${esc(tr(s.name, lang))} · ${s.duration_min}′ · ${money(s.price, cur())}</option>`).join('')}</select></div>
      ${adds.length ? `<div class="f full"><span class="lbl">${esc(t('Add-ons'))}</span>${adds.map(a => `<label class="check"><input type="checkbox" name="aAdd" value="${a.id}"> ${esc(tr(a.name, lang))} · ${money(a.price, cur())}</label>`).join('')}</div>` : ''}
      <div class="f full"><label for="aBarber">${esc(t('Barber'))}</label><select id="aBarber">${d.barbers.filter(b => b.active).map(b => `<option value="${b.id}">${esc(b.name)}${b.off ? ' (' + esc(t('day off')) + ')' : ''}</option>`).join('')}</select></div>
      <div class="f"><label for="aDate">${esc(t('Date'))}</label><input id="aDate" type="date" value="${P.date}" required></div>
      <div class="f"><label for="aTime">${esc(t('Time'))}</label><input id="aTime" type="time" step="${step * 60}" value="${suggestTime()}" required></div>
      <div class="f"><label for="aName">${esc(t('Name'))}</label><input id="aName" type="text" maxlength="80" required></div>
      <div class="f"><label for="aPhone">${esc(t('Phone'))}</label><input id="aPhone" type="tel" maxlength="30" required></div>
      <div class="f full"><label for="aNote">${esc(t('Note'))}</label><input id="aNote" type="text" maxlength="300"></div>
      <p class="err full" id="drErr" role="alert"></p>
      <button class="btn full" type="submit">${esc(t('Save booking'))}</button>
    </form>`);
  $('#addForm').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await rpc('panel_add_booking', { p_shop: P.shop.id, p: {
        service_id: $('#aSvc').value, addon_ids: $$('input[name=aAdd]:checked').map(x => x.value), barber_id: $('#aBarber').value,
        date: $('#aDate').value, time: $('#aTime').value, name: $('#aName').value.trim(), phone: $('#aPhone').value.trim(), note: $('#aNote').value.trim(),
        lang: P.day.shop.default_lang } }, { withUser: true });
      toast(t('Saved')); P.date = $('#aDate').value; closeDrawer(); showDay();
    } catch (err) { $('#drErr').textContent = errText(err); }
  });
}
function suggestTime() {
  const d = P.day; const step = d.shop.slot_step || 30;
  let m = d.hours ? mins(d.hours[0]) : 600;
  if (P.date === d.today) m = Math.max(m, Math.ceil(mins(d.now) / step) * step);
  return hhmm(Math.min(m, 23 * 60));
}

// ---------- INCOME ----------
async function ensureSettings() { if (!P.settings) P.settings = await rpc('get_settings', { p_shop: P.shop.id }, { withUser: true }); }

async function showIncome() {
  const my = P.seq;
  await ensureSettings();
  if (my !== P.seq) return;
  applyAccent(P.settings.shop.accent);
  const per = P.period, today = P.settings.today, c = P.settings.shop.currency;
  const from = addDays(today, -(2 * per - 1)), pStart = addDays(today, -(per - 1));
  const rows = await rpc('panel_range', { p_shop: P.shop.id, p_from: from, p_to: today }, { withUser: true });
  if (my !== P.seq) return;
  const inP = rows.filter(r => r.date >= pStart), prev = rows.filter(r => r.date < pStart);
  const inc = r => r.status === 'done' ? { o: Number(r.paid_online), s: Number(r.price) - Number(r.paid_online) } : r.status === 'noshow' ? { o: Number(r.paid_online), s: 0 } : { o: 0, s: 0 };
  const sum = list => list.reduce((a, r) => { const x = inc(r); return a + x.o + x.s; }, 0);
  const total = sum(inP), before = sum(prev);
  const delta = before ? Math.round((total - before) / before * 100) : null;
  const done = inP.filter(r => r.status === 'done');
  const noshow = inP.filter(r => r.status === 'noshow').length;

  const days = []; for (let i = per - 1; i >= 0; i--) days.push(addDays(today, -i));
  const vals = days.map(d => inP.filter(r => r.date === d).reduce((a, r) => { const x = inc(r); a.o += x.o; a.s += x.s; return a; }, { o: 0, s: 0 }));

  const names = { svc: Object.fromEntries(P.settings.services.map(s => [s.id, tr(s.name, lang)])), bar: Object.fromEntries(P.settings.barbers.map(b => [b.id, b.name])) };
  const byBarber = P.settings.barbers.map(b => { const l = inP.filter(r => r.barber_id === b.id); const dn = l.filter(r => r.status === 'done'); const i = sum(l); return { name: b.name, done: dn.length, ns: l.filter(r => r.status === 'noshow').length, inc: i, avg: dn.length ? i / dn.length : 0 }; }).filter(r => r.done || r.inc || r.ns).sort((a, b) => b.inc - a.inc);
  const svcIds = [...new Set(inP.map(r => r.service_id))];
  const bySvc = svcIds.map(id => { const l = inP.filter(r => r.service_id === id); return { name: names.svc[id] || '—', n: l.filter(r => r.status === 'done').length, inc: sum(l) }; }).sort((a, b) => b.inc - a.inc);
  const pays = [['shop', 'Pay in shop'], ['full', 'Full online'], ['deposit', 'Deposit online']].map(([k, l]) => { const lst = inP.filter(r => r.pay_choice === k && r.status !== 'cancelled'); return { l, n: lst.length, o: lst.reduce((a, r) => a + inc(r).o, 0), s: lst.reduce((a, r) => a + inc(r).s, 0) }; });

  $('#view').innerHTML = `
    <div class="pbar"><h1>${esc(t('Income'))}</h1>
      <div class="seg" role="group" aria-label="Period">${[7, 14, 30, 90].map(p => `<button type="button" data-period="${p}" aria-pressed="${p === per}">${p} ${esc(t('days'))}</button>`).join('')}</div></div>
    <div class="kpis">
      <div class="kpi"><span class="k">${esc(t('Last'))} ${per} ${esc(t('days'))}</span><span class="v">${money0(total, c)}</span><span class="s">${delta === null ? esc(t('No earlier period to compare')) : `<span class="${delta >= 0 ? 'up' : 'down'}">${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta)}%</span> ${esc(t('vs previous'))}`}</span></div>
      <div class="kpi"><span class="k">${esc(t('Cuts done'))}</span><span class="v">${done.length}</span><span class="s">${noshow} ${esc(t('No-shows').toLowerCase())}</span></div>
      <div class="kpi"><span class="k">${esc(t('Average ticket'))}</span><span class="v">${money0(done.length ? done.reduce((a, r) => a + Number(r.price), 0) / done.length : 0, c)}</span><span class="s">&nbsp;</span></div>
      <div class="kpi"><span class="k">${esc(t('Paid online'))}</span><span class="v">${money0(vals.reduce((a, v) => a + v.o, 0), c)}</span><span class="s">${esc(t('Paid in shop'))}: ${money0(vals.reduce((a, v) => a + v.s, 0), c)}</span></div>
    </div>
    <div class="pgrid">
      <section class="psec"><div class="psec-h"><h2>${esc(t('Income'))}</h2>
        <div class="legend"><span style="--c:var(--accent)"><i class="sw"></i>${esc(t('Paid online'))}</span><span style="--c:var(--steel)"><i class="sw"></i>${esc(t('Paid in shop'))}</span></div></div>
        <div class="chart">${chart(days, vals, c, today)}</div>
        <div class="chart-foot"><span>${esc(t('Average per open day'))} <b>${money0(total / Math.max(1, days.filter(d => Array.isArray(P.settings.shop.hours[String(dow(d))])).length), c)}</b></span></div>
      </section>
      <section class="psec"><div class="psec-h"><h2>${esc(t('By barber'))}</h2></div>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>${esc(t('Barber'))}</th><th class="num">${esc(t('Done'))}</th><th class="num">${esc(t('No-shows'))}</th><th class="num">${esc(t('Average ticket'))}</th><th class="num">${esc(t('Income'))}</th></tr></thead>
        <tbody>${byBarber.map(r => `<tr><td><span class="who"><span class="av">${esc(r.name.charAt(0))}</span>${esc(r.name)}</span></td><td class="num">${r.done}</td><td class="num">${r.ns}</td><td class="num">${money0(r.avg, c)}</td><td class="num">${money0(r.inc, c)}</td></tr>`).join('') || `<tr><td colspan="5" class="dim">—</td></tr>`}</tbody></table></div>
      </section>
    </div>
    <div class="pgrid">
      <section class="psec"><div class="psec-h"><h2>${esc(t('Services'))}</h2></div>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>${esc(t('Service'))}</th><th class="num">${esc(t('Done'))}</th><th class="num">${esc(t('Income'))}</th><th style="width:30%">${esc(t('Share'))}</th></tr></thead>
        <tbody>${bySvc.map(r => `<tr><td>${esc(r.name)}</td><td class="num">${r.n}</td><td class="num">${money0(r.inc, c)}</td><td><div class="share"><i style="width:${total ? Math.round(r.inc / total * 100) : 0}%"></i></div></td></tr>`).join('') || `<tr><td colspan="4" class="dim">—</td></tr>`}</tbody></table></div>
      </section>
      <section class="psec"><div class="psec-h"><h2>${esc(t('Payments'))}</h2></div>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>${esc(t('Chosen at booking'))}</th><th class="num">${esc(t('Bookings'))}</th><th class="num">${esc(t('Paid online'))}</th><th class="num">${esc(t('Paid in shop'))}</th></tr></thead>
        <tbody>${pays.map(r => `<tr><td>${esc(t(r.l))}</td><td class="num">${r.n}</td><td class="num">${money0(r.o, c)}</td><td class="num">${money0(r.s, c)}</td></tr>`).join('')}</tbody></table></div>
      </section>
    </div>`;
}

function niceStep(v) { if (v <= 0) return 50; const p = 10 ** Math.floor(Math.log10(v)); const f = v / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; }
function chart(days, vals, c, today) {
  const per = days.length, maxV = Math.max(0, ...vals.map(v => v.o + v.s));
  const step = niceStep(maxV / 4 || 50), top = Math.max(step, Math.ceil(maxV / step) * step);
  const W = 640, H = 230, L = 52, R = 8, Tp = 10, B = 28, pw = W - L - R, ph = H - Tp - B;
  const y = v => Tp + ph - (v / top) * ph, bw = pw / per, w = Math.max(2, bw * 0.66);
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Daily income">`;
  for (let v = 0; v <= top + 1e-9; v += step) {
    s += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)" ${v ? 'stroke-dasharray="2 3"' : ''}/><text x="${L - 8}" y="${y(v) + 3.5}" text-anchor="end">${money0(v, c)}</text>`;
  }
  const every = per <= 7 ? 1 : per <= 14 ? 2 : per <= 30 ? 5 : 15;
  vals.forEach((v, i) => {
    const x = L + i * bw + (bw - w) / 2;
    if (v.o > 0) s += `<rect x="${x}" y="${y(v.o)}" width="${w}" height="${y(0) - y(v.o)}" fill="var(--accent)"><title>${days[i]}: ${money(v.o, c)}</title></rect>`;
    if (v.s > 0) s += `<rect x="${x}" y="${y(v.o + v.s)}" width="${w}" height="${y(v.o) - y(v.o + v.s)}" fill="var(--steel)"><title>${days[i]}: ${money(v.s, c)}</title></rect>`;
    if ((per - 1 - i) % every === 0) s += `<text x="${x + w / 2}" y="${H - 8}" text-anchor="middle" ${days[i] === today ? 'style="fill:var(--ink)"' : ''}>${days[i] === today ? esc(t('Today')) : +days[i].slice(8) + ' ' + esc(fmtDate(days[i], lang, { month: 'short' }))}</text>`;
  });
  return s + '</svg>';
}

// ---------- UPCOMING ----------
async function showUpcoming() {
  const my = P.seq;
  if (!$('#q')) {
    $('#view').innerHTML = `<div class="pbar"><h1>${esc(t('Upcoming'))}</h1>
      <div class="toolbar"><input id="q" type="search" placeholder="${esc(t('Search name, phone or code'))}" aria-label="${esc(t('Search name, phone or code'))}" value="${esc(P.q)}"></div></div>
      <div class="tbl-wrap"><table class="tbl" id="upTbl"></table></div>`;
    let h; $('#q').addEventListener('input', e => { P.q = e.target.value; clearTimeout(h); h = setTimeout(showUpcoming, 250); });
  }
  if (!P.day) await loadDay();
  if (my !== P.seq) return;
  const list = await rpc('panel_upcoming', { p_shop: P.shop.id, p_q: P.q, p_limit: 100 }, { withUser: true });
  if (my !== P.seq || !$('#upTbl')) return;
  P.upcoming = list;
  const c = cur();
  $('#upTbl').innerHTML = list.length ? `<thead><tr><th>${esc(t('When'))}</th><th>${esc(t('Customer'))}</th><th>${esc(t('Service'))}</th><th>${esc(t('Barber'))}</th><th>${esc(t('Payment'))}</th><th class="num">${esc(t('Due in shop'))}</th></tr></thead><tbody>` +
    list.map(b => `<tr class="click" data-booking="${b.id}" tabindex="0"><td class="mono">${esc(fmtDate(b.date, lang, { weekday: 'short', day: 'numeric', month: 'short' }))} · ${b.time}</td>
      <td><div>${esc(b.customer_name)}</div><div class="dim">${esc(b.customer_phone)}</div></td><td>${esc(itemsText(b))}</td><td>${esc(barberName(b.barber_id))}</td>
      <td>${b.status === 'pending' ? `<span class="pill st-pending">${esc(t('Awaiting payment'))}</span>` : Number(b.paid_online) > 0 ? `${esc(t('Paid online'))} ${money(b.paid_online, c)}` : esc(t('Pay in shop'))}</td>
      <td class="num">${money(Number(b.price) - Number(b.paid_online), c)}</td></tr>`).join('') + '</tbody>'
    : `<tbody><tr><td class="empty">${esc(t(P.q ? 'No bookings match that search.' : 'No upcoming bookings yet.'))}</td></tr></tbody>`;
}

// ---------- SETTINGS ----------
const STABS = [['shop', 'Shop'], ['hours', 'Hours'], ['services', 'Services'], ['barbers', 'Barbers'], ['closures', 'Days off'], ['payments', 'Payments'], ['logins', 'Logins']];
async function showSettings(reload = true) {
  const my = P.seq;
  if (reload || !P.settings) P.settings = await rpc('get_settings', { p_shop: P.shop.id }, { withUser: true });
  if (my !== P.seq) return;
  applyAccent(P.settings.shop.accent);
  $('#view').innerHTML = `<div class="settings"><nav class="snav" aria-label="${esc(t('Settings'))}">${STABS.map(([k, l]) => `<button type="button" data-stab="${k}" aria-current="${P.stab === k}">${esc(t(l))}</button>`).join('')}</nav><div class="spanel" id="spanel"></div></div>`;
  renderSettingsTab();
}
function renderSettingsTab() {
  const fn = { shop: sShop, hours: sHours, services: sServices, barbers: sBarbers, closures: sClosures, payments: sPayments, logins: sLogins }[P.stab] || sShop;
  $('#spanel').innerHTML = fn();
  $$('.snav button').forEach(b => b.setAttribute('aria-current', b.dataset.stab === P.stab));
}
async function saveShop(patch, btn) {
  try { if (btn) btn.disabled = true; await rpc('save_shop', { p_shop: P.shop.id, p: patch }, { withUser: true }); toast(t('Saved')); await showSettings(); }
  catch (e) { toast(errText(e)); } finally { if (btn) btn.disabled = false; }
}
const val = id => $('#' + id).value;
const chk = id => $('#' + id).checked;

function sShop() {
  const s = P.settings.shop, url = `${location.origin}/${s.slug}`;
  return `<h2>${esc(t('Shop'))}</h2>
  <div class="card box">
    <div class="f"><span class="lbl">${esc(t('Your booking page'))}</span><div class="copyline"><code class="url">${esc(url)}</code><button class="linkbtn" data-copy="${esc(url)}">${esc(t('Copy'))}</button></div></div>
    <div class="fields">
      <div class="f"><label for="sName">${esc(t('Shop name'))}</label><input id="sName" type="text" maxlength="80" value="${esc(s.name)}"></div>
      <div class="f"><label for="sPhone">${esc(t('Phone'))}</label><input id="sPhone" type="tel" value="${esc(s.phone)}"></div>
      <div class="f full"><label for="sAddr">${esc(t('Address'))}</label><input id="sAddr" type="text" value="${esc(s.address)}"></div>
    </div>
    <div class="f"><span class="lbl">${esc(t('Short line under the title'))}</span>
      <div class="three"><input id="sTagKa" type="text" placeholder="ქართ." value="${esc(s.tagline.ka || '')}"><input id="sTagEn" type="text" placeholder="English" value="${esc(s.tagline.en || '')}"><input id="sTagRu" type="text" placeholder="Рус." value="${esc(s.tagline.ru || '')}"></div></div>
    <div class="fields">
      <div class="f"><label for="sAccent">${esc(t('Accent colour'))}</label><input id="sAccent" type="color" value="${esc(s.accent)}"></div>
      <div class="f"><label for="sLang">${esc(t('Default language for customers'))}</label><select id="sLang">${[['ka', 'ქართული'], ['en', 'English'], ['ru', 'Русский']].map(([k, l]) => `<option value="${k}" ${s.default_lang === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    </div>
    <div class="savebar"><button class="btn" data-save="shop">${esc(t('Save'))}</button></div>
  </div>
  <h2>${esc(t('SMS'))}</h2>
  <div class="card box"><label class="check"><input type="checkbox" id="sSms" ${s.sms_enabled ? 'checked' : ''}> ${esc(t('Send SMS confirmations and day-before reminders'))}</label>
    <div class="savebar"><button class="btn" data-save="sms">${esc(t('Save'))}</button></div></div>`;
}

function sHours() {
  const s = P.settings.shop, base = '2024-01-01';
  const rows = [1, 2, 3, 4, 5, 6, 0].map((d, i) => {
    const h = s.hours[String(d)], open = Array.isArray(h);
    return `<span>${esc(fmtDate(addDays(base, i), lang, { weekday: 'long' }))}</span>
      <label class="check"><input type="checkbox" id="hOpen${d}" ${open ? 'checked' : ''}> ${esc(t('Open'))}</label>
      <input type="time" id="hFrom${d}" value="${open ? h[0] : '10:00'}" aria-label="${esc(t('from'))}">
      <input type="time" id="hTo${d}" value="${open ? h[1] : '20:00'}" aria-label="${esc(t('to'))}">`;
  }).join('');
  return `<h2>${esc(t('Hours'))}</h2>
  <div class="card box"><div class="hours-grid">${rows}</div></div>
  <div class="card box"><div class="three">
    <div class="f"><label for="hStep">${esc(t('Time grid'))}</label><select id="hStep">${[15, 20, 30, 60].map(m => `<option value="${m}" ${s.slot_step === m ? 'selected' : ''}>${m} ${esc(t('minutes'))}</option>`).join('')}</select></div>
    <div class="f"><label for="hLead">${esc(t('Earliest online booking'))}</label><select id="hLead">${[0, 15, 30, 60, 120, 240, 1440].map(m => `<option value="${m}" ${s.lead_minutes === m ? 'selected' : ''}>${m} ${esc(t('minutes ahead'))}</option>`).join('')}</select></div>
    <div class="f"><label for="hDays">${esc(t('How far ahead customers can book'))}</label><select id="hDays">${[7, 14, 21, 30, 60, 90].map(m => `<option value="${m}" ${s.booking_days === m ? 'selected' : ''}>${m} ${esc(t('days'))}</option>`).join('')}</select></div>
  </div><div class="savebar"><button class="btn" data-save="hours">${esc(t('Save'))}</button></div></div>`;
}

function sServices() {
  const c = P.settings.shop.currency;
  return `<h2>${esc(t('Services'))}</h2>
  <div class="card"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>${esc(t('Service'))}</th><th class="num">${esc(t('Price'))}</th><th class="num">min</th><th></th><th></th></tr></thead><tbody>
  ${P.settings.services.map(v => `<tr><td>${esc(tr(v.name, lang))}${v.is_addon ? ` <span class="pill" style="--c:var(--brass)">${esc(t('Add-on'))}</span>` : ''}</td><td class="num">${money(v.price, c)}</td><td class="num">${v.duration_min}</td>
    <td>${v.active ? '' : `<span class="pill st-cancelled">${esc(t('Hidden'))}</span>`}</td><td style="text-align:right"><button class="btn ghost small" data-edit-svc="${v.id}">${esc(t('Edit'))}</button></td></tr>`).join('')}
  </tbody></table></div></div>
  <div><button class="btn" data-edit-svc="">+ ${esc(t('Add service'))}</button></div>`;
}
function serviceDrawer(id) {
  const v = P.settings.services.find(x => x.id === id) || { name: {}, description: {}, price: '', duration_min: 30, is_addon: false, active: true, sort: P.settings.services.length + 1 };
  openDrawer(`<div class="dr-h"><h3>${esc(id ? t('Edit') : t('Add service'))}</h3><button class="icon-btn" data-act="close" aria-label="${esc(t('Close'))}">×</button></div>
    <form id="svcForm" class="fields" novalidate>
      <div class="f full"><label for="vKa">${esc(t('Name (Georgian)'))}</label><input id="vKa" type="text" value="${esc(v.name.ka || '')}" required></div>
      <div class="f"><label for="vEn">${esc(t('Name (English)'))}</label><input id="vEn" type="text" value="${esc(v.name.en || '')}"></div>
      <div class="f"><label for="vRu">${esc(t('Name (Russian)'))}</label><input id="vRu" type="text" value="${esc(v.name.ru || '')}"></div>
      <div class="f full"><label for="vDKa">${esc(t('Description (Georgian)'))}</label><input id="vDKa" type="text" value="${esc(v.description.ka || '')}"></div>
      <div class="f"><label for="vDEn">${esc(t('Description (English)'))}</label><input id="vDEn" type="text" value="${esc(v.description.en || '')}"></div>
      <div class="f"><label for="vDRu">${esc(t('Description (Russian)'))}</label><input id="vDRu" type="text" value="${esc(v.description.ru || '')}"></div>
      <div class="f"><label for="vPrice">${esc(t('Price (₾)'))}</label><input id="vPrice" type="number" min="0" step="0.5" value="${esc(v.price)}" required></div>
      <div class="f"><label for="vMin">${esc(t('Length (minutes)'))}</label><input id="vMin" type="number" min="5" max="480" step="5" value="${esc(v.duration_min)}" required></div>
      <div class="f"><label for="vSort">${esc(t('Order'))}</label><input id="vSort" type="number" value="${esc(v.sort)}"></div>
      <div class="f full"><label class="check"><input type="checkbox" id="vAddon" ${v.is_addon ? 'checked' : ''}> ${esc(t('Is an add-on (extra to a main service)'))}</label>
        <label class="check"><input type="checkbox" id="vActive" ${v.active ? 'checked' : ''}> ${esc(t('Show on booking page'))}</label></div>
      <p class="err full" id="drErr" role="alert"></p>
      <button class="btn full" type="submit">${esc(t('Save'))}</button>
    </form>`);
  $('#svcForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (!val('vKa').trim() && !val('vEn').trim()) { $('#drErr').textContent = t('Name (Georgian)'); return; }
    if (!(Number(val('vPrice')) >= 0) || val('vPrice') === '' || !(Number(val('vMin')) >= 5)) { $('#drErr').textContent = t('Price (₾)') + ' / ' + t('Length (minutes)'); return; }
    try {
      await rpc('save_service', { p_shop: P.shop.id, p: { id: id || null, name: { ka: val('vKa').trim(), en: val('vEn').trim(), ru: val('vRu').trim() },
        description: { ka: val('vDKa').trim(), en: val('vDEn').trim(), ru: val('vDRu').trim() }, price: Number(val('vPrice')), duration_min: Math.round(Number(val('vMin'))),
        sort: Number(val('vSort')) || 0, is_addon: chk('vAddon'), active: chk('vActive') } }, { withUser: true });
      toast(t('Saved')); closeDrawer(); await showSettings();
    } catch (err) { $('#drErr').textContent = errText(err); }
  });
}

function sBarbers() {
  return `<h2>${esc(t('Barbers'))}</h2>
  <div class="card"><div class="tbl-wrap"><table class="tbl"><tbody>
  ${P.settings.barbers.map(b => `<tr><td><span class="who"><span class="av">${esc(b.name.charAt(0))}</span>${esc(b.name)}</span></td><td class="dim">${esc(tr(b.title, lang))}</td>
    <td>${b.active ? '' : `<span class="pill st-cancelled">${esc(t('Hidden'))}</span>`}</td><td style="text-align:right"><button class="btn ghost small" data-edit-barber="${b.id}">${esc(t('Edit'))}</button></td></tr>`).join('')}
  </tbody></table></div></div>
  <div><button class="btn" data-edit-barber="">+ ${esc(t('Add barber'))}</button></div>`;
}
function barberDrawer(id) {
  const b = P.settings.barbers.find(x => x.id === id) || { name: '', title: {}, active: true, sort: P.settings.barbers.length + 1 };
  openDrawer(`<div class="dr-h"><h3>${esc(id ? b.name : t('Add barber'))}</h3><button class="icon-btn" data-act="close" aria-label="${esc(t('Close'))}">×</button></div>
    <form id="barForm" class="fields" novalidate>
      <div class="f full"><label for="bName">${esc(t('Name'))}</label><input id="bName" type="text" maxlength="60" value="${esc(b.name)}" required></div>
      <div class="f full"><span class="lbl">${esc(t('Title / speciality'))}</span><div class="three"><input id="bTKa" placeholder="ქართ." value="${esc(b.title.ka || '')}"><input id="bTEn" placeholder="English" value="${esc(b.title.en || '')}"><input id="bTRu" placeholder="Рус." value="${esc(b.title.ru || '')}"></div></div>
      <div class="f"><label for="bSort">${esc(t('Order'))}</label><input id="bSort" type="number" value="${esc(b.sort)}"></div>
      <div class="f" style="align-self:end"><label class="check"><input type="checkbox" id="bActive" ${b.active ? 'checked' : ''}> ${esc(t('Show on booking page'))}</label></div>
      <p class="err full" id="drErr" role="alert"></p>
      <button class="btn full" type="submit">${esc(t('Save'))}</button>
    </form>`);
  $('#barForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (!val('bName').trim()) { $('#drErr').textContent = t('Name'); return; }
    try {
      await rpc('save_barber', { p_shop: P.shop.id, p: { id: id || null, name: val('bName').trim(), title: { ka: val('bTKa').trim(), en: val('bTEn').trim(), ru: val('bTRu').trim() }, sort: Number(val('bSort')) || 0, active: chk('bActive') } }, { withUser: true });
      toast(t('Saved')); closeDrawer(); await showSettings();
    } catch (err) { $('#drErr').textContent = errText(err); }
  });
}

function sClosures() {
  const s = P.settings;
  return `<h2>${esc(t('Days off'))}</h2>
  <div class="card"><div class="tbl-wrap"><table class="tbl"><tbody>
  ${s.closures.map(c => `<tr><td class="mono">${esc(fmtDate(c.starts_on, lang, { day: 'numeric', month: 'short' }))}${c.ends_on !== c.starts_on ? ' – ' + esc(fmtDate(c.ends_on, lang, { day: 'numeric', month: 'short' })) : ''}</td>
    <td>${esc(c.barber_id ? barberName(c.barber_id) : t('Whole shop'))}</td><td class="dim">${esc(c.note)}</td><td style="text-align:right"><button class="btn danger small" data-del-closure="${c.id}">${esc(t('Remove'))}</button></td></tr>`).join('') || `<tr><td class="empty">${esc(t('No days off planned.'))}</td></tr>`}
  </tbody></table></div></div>
  <div class="card box"><h3>${esc(t('Add day off'))}</h3>
    <div class="fields">
      <div class="f full"><label for="cWho">${esc(t('Barber'))}</label><select id="cWho"><option value="">${esc(t('Whole shop'))}</option>${s.barbers.filter(b => b.active).map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('')}</select></div>
      <div class="f"><label for="cFrom">${esc(t('First day'))}</label><input id="cFrom" type="date" min="${s.today}" value="${s.today}"></div>
      <div class="f"><label for="cTo">${esc(t('Last day'))}</label><input id="cTo" type="date" min="${s.today}" value="${s.today}"></div>
      <div class="f full"><label for="cNote">${esc(t('Reason (optional)'))}</label><input id="cNote" type="text" maxlength="120"></div>
    </div>
    <div class="savebar"><button class="btn" data-save="closure">${esc(t('Add day off'))}</button></div></div>`;
}

function sPayments() {
  const s = P.settings.shop, p = P.settings.payments, cb = `${location.origin}/api/pay/callback?provider=`;
  const bankBox = (k, title, extra) => `<div class="card box">
    <div class="savebar" style="justify-content:space-between"><h3>${title}</h3><span class="pill ${p[k] ? 'st-done' : 'st-cancelled'}">${esc(t(p[k] ? 'Connected' : 'Not connected'))}</span></div>
    ${extra}
    <div class="fields">
      <div class="f"><label for="${k}Id">${esc(t('Client ID'))}</label><input id="${k}Id" type="text" autocomplete="off" placeholder="${p[k] ? '••••••' : ''}"></div>
      <div class="f"><label for="${k}Secret">${esc(t('Client secret'))}</label><input id="${k}Secret" type="password" autocomplete="new-password" placeholder="${p[k] ? '••••••' : ''}"></div>
      ${k === 'tbc' ? `<div class="f full"><label for="tbcKey">API key <span class="hint">(${lang === 'ka' ? 'არასავალდებულო' : 'optional'})</span></label><input id="tbcKey" type="password" autocomplete="off"></div>` : ''}
    </div>
    <div class="savebar"><button class="btn" data-connect="${k}">${esc(t('Connect'))}</button>${p[k] ? `<button class="btn danger" data-disconnect="${k}">${esc(t('Disconnect'))}</button>` : ''}<span class="err" id="${k}Err"></span></div>
  </div>`;
  const help = lang === 'ka'
    ? { tbc: `Client ID და Secret იხილეთ <b>ecom.tbcpayments.ge</b> → Website Management → Details. იქვე, Callback ველში ჩასვით: <code class="url">${esc(cb)}tbc</code>`,
        bog: `Client ID და Secret-ს გასცემს საქართველოს ბანკი ონლაინ გადახდების ხელშეკრულებისას (Business Manager). ცალკე callback-ის მითითება საჭირო არ არის.` }
    : { tbc: `Find the Client ID and Secret at <b>ecom.tbcpayments.ge</b> → Website Management → Details. In the same place, paste this into the Callback field: <code class="url">${esc(cb)}tbc</code>`,
        bog: `Bank of Georgia gives you the Client ID and Secret when you sign up for online payments (Business Manager). No callback setup is needed.` };
  return `<h2>${esc(t('How customers pay'))}</h2>
  <div class="card box">
    <label class="check"><input type="checkbox" id="pShop" ${s.pay_in_shop ? 'checked' : ''}> ${esc(t('Allow paying in the shop'))}</label>
    <div class="f"><span class="lbl">${esc(t('Online payment'))}</span>
      <div class="radio-cards">
        <label class="rc"><input type="radio" name="pOnline" value="off" ${s.online_pay === 'off' ? 'checked' : ''}><span>${esc(t('Off'))}</span></label>
        <label class="rc"><input type="radio" name="pOnline" value="tbc" ${s.online_pay === 'tbc' ? 'checked' : ''} ${p.tbc ? '' : 'disabled'}><span>TBC<small>${esc(t(p.tbc ? 'Connected' : 'Not connected'))}</small></span></label>
        <label class="rc"><input type="radio" name="pOnline" value="bog" ${s.online_pay === 'bog' ? 'checked' : ''} ${p.bog ? '' : 'disabled'}><span>Bank of Georgia<small>${esc(t(p.bog ? 'Connected' : 'Not connected'))}</small></span></label>
      </div></div>
    <div class="fields">
      <div class="f"><label for="pMode">${esc(t('Payment'))}</label><select id="pMode">${[['choice', 'Customers choose full or deposit'], ['full', 'Always full price'], ['deposit', 'Always a deposit']].map(([k, l]) => `<option value="${k}" ${s.online_mode === k ? 'selected' : ''}>${esc(t(l))}</option>`).join('')}</select></div>
      <div class="f"><label for="pDep">${esc(t('Deposit %'))}</label><input id="pDep" type="number" min="5" max="100" step="5" value="${s.deposit_percent}"></div>
    </div>
    <div class="savebar"><button class="btn" data-save="payments">${esc(t('Save'))}</button></div>
  </div>
  ${bankBox('tbc', 'TBC Bank', `<p class="hint">${help.tbc}</p>`)}
  ${bankBox('bog', 'Bank of Georgia', `<p class="hint">${help.bog}</p>`)}`;
}

function sLogins() {
  const s = P.settings;
  return `<h2>${esc(t('Logins'))}</h2>
  <p class="hint">${esc(t('Staff can see the day sheet and upcoming bookings and mark bookings done. Only owners see income and settings.'))}</p>
  <div class="card"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>${esc(t('Email'))}</th><th>${esc(t('Role'))}</th><th>${esc(t('Linked barber'))}</th><th></th></tr></thead><tbody>
  ${s.staff.map(m => `<tr><td>${esc(m.email)}${m.me ? ` <span class="dim">(${esc(t('you'))})</span>` : ''}</td><td>${esc(t(m.role === 'owner' ? 'Owner' : 'Staff'))}</td><td>${esc(m.barber_id ? barberName(m.barber_id) : '—')}</td>
    <td style="text-align:right;white-space:nowrap">${m.me ? '' : `${m.role === 'staff' ? `<button class="btn ghost small" data-pw="${m.user_id}">${esc(t('Set password'))}</button> ` : ''}<button class="btn danger small" data-remove-user="${m.user_id}">${esc(t('Remove'))}</button>`}</td></tr>`).join('')}
  </tbody></table></div></div>
  <div class="card box"><h3>${esc(t('Add login'))}</h3>
    <div class="fields">
      <div class="f"><label for="uEmail">${esc(t('Email'))}</label><input id="uEmail" type="email" autocomplete="off"></div>
      <div class="f"><label for="uPass">${esc(t('Password'))}</label><input id="uPass" type="text" autocomplete="off" minlength="8" placeholder="8+"></div>
      <div class="f"><label for="uRole">${esc(t('Role'))}</label><select id="uRole"><option value="staff">${esc(t('Staff'))}</option><option value="owner">${esc(t('Owner'))}</option></select></div>
      <div class="f"><label for="uBarber">${esc(t('Linked barber'))}</label><select id="uBarber"><option value="">${esc(t('None'))}</option>${s.barbers.map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('')}</select></div>
    </div>
    <div class="savebar"><button class="btn" data-save="login">${esc(t('Add login'))}</button><span class="err" id="uErr"></span></div></div>`;
}

// ---------- clicks ----------
document.addEventListener('click', async e => {
  const b = e.target.closest('button, [data-plang]'); if (!b) return;
  const d = b.dataset;
  if (d.plang) { lang = d.plang; try { localStorage.setItem('chairbook.plang', lang); } catch {} applyLang(); renderTabs(); if (P.shop) show(); return; }
  if (d.act === 'close') return closeDrawer();
  if (d.act === 'prev') { P.date = addDays(P.date, -1); return showDay(); }
  if (d.act === 'next') { P.date = addDays(P.date, 1); return showDay(); }
  if (d.act === 'today') { P.date = P.day ? P.day.today : tbilisiToday(); return showDay(); }
  if (d.act === 'add') return addDrawer();
  if (d.booking) { const list = P.tab === 'upcoming' ? P.upcoming : P.day.bookings; const bk = list.find(x => x.id === d.booking); if (bk) bookingDrawer(bk); return; }
  if (d.status) return setStatus(d.status);
  if (d.period) { P.period = +d.period; return showIncome(); }
  if (d.stab) { P.stab = d.stab; return renderSettingsTab(); }
  if (d.copy !== undefined) { try { await navigator.clipboard.writeText(d.copy); toast(t('Copied')); } catch { toast(d.copy); } return; }
  if (d.editSvc !== undefined) return serviceDrawer(d.editSvc);
  if (d.editBarber !== undefined) return barberDrawer(d.editBarber);
  if (d.save === 'shop') return saveShop({ name: val('sName'), phone: val('sPhone'), address: val('sAddr'), accent: val('sAccent'), default_lang: val('sLang'),
    tagline: { ka: val('sTagKa').trim(), en: val('sTagEn').trim(), ru: val('sTagRu').trim() } }, b);
  if (d.save === 'sms') return saveShop({ sms_enabled: chk('sSms') }, b);
  if (d.save === 'hours') {
    const hours = {};
    for (const n of [0, 1, 2, 3, 4, 5, 6]) hours[n] = chk('hOpen' + n) ? [val('hFrom' + n), val('hTo' + n)] : null;
    return saveShop({ hours, slot_step: +val('hStep'), lead_minutes: +val('hLead'), booking_days: +val('hDays') }, b);
  }
  if (d.save === 'payments') return saveShop({ pay_in_shop: chk('pShop'), online_pay: ($('input[name=pOnline]:checked') || {}).value || 'off', online_mode: val('pMode'), deposit_percent: Math.min(100, Math.max(5, +val('pDep') || 20)) }, b);
  if (d.save === 'closure') {
    try { await rpc('add_closure', { p_shop: P.shop.id, p: { barber_id: val('cWho') || null, starts_on: val('cFrom'), ends_on: val('cTo') < val('cFrom') ? val('cFrom') : val('cTo'), note: val('cNote') } }, { withUser: true }); toast(t('Saved')); await showSettings(); }
    catch (err) { toast(errText(err)); } return;
  }
  if (d.delClosure) { try { await rpc('delete_closure', { p_shop: P.shop.id, p_id: d.delClosure }, { withUser: true }); await showSettings(); } catch (err) { toast(errText(err)); } return; }
  if (d.connect) {
    const k = d.connect; $('#' + k + 'Err').textContent = ''; b.disabled = true;
    try { await api('/api/shop/secrets', { shop_id: P.shop.id, provider: k, client_id: val(k + 'Id'), client_secret: val(k + 'Secret'), apikey: k === 'tbc' ? val('tbcKey') : undefined }, { withUser: true }); toast(t('Connected')); await showSettings(); }
    catch (err) { $('#' + k + 'Err').textContent = errText(err); b.disabled = false; } return;
  }
  if (d.disconnect) { try { await api('/api/shop/secrets', { shop_id: P.shop.id, provider: d.disconnect, remove: true }, { withUser: true }); toast(t('Saved')); await showSettings(); } catch (err) { toast(errText(err)); } return; }
  if (d.save === 'login') {
    $('#uErr').textContent = '';
    try { await api('/api/shop/staff', { shop_id: P.shop.id, email: val('uEmail'), password: val('uPass'), role: val('uRole'), barber_id: val('uBarber') || null }, { withUser: true }); toast(t('Login added')); await showSettings(); }
    catch (err) { $('#uErr').textContent = errText(err); } return;
  }
  if (d.pw) {
    openDrawer(`<div class="dr-h"><h3>${esc(t('Set password'))}</h3><button class="icon-btn" data-act="close" aria-label="${esc(t('Close'))}">×</button></div>
      <form id="pwForm" style="display:grid;gap:12px"><div class="f"><label for="npw">${esc(t('New password'))}</label><input id="npw" type="text" minlength="8" autocomplete="off"></div>
      <p class="err" id="drErr"></p><button class="btn" type="submit">${esc(t('Save'))}</button></form>`);
    $('#pwForm').addEventListener('submit', async ev => {
      ev.preventDefault();
      try { await api('/api/shop/staff', { shop_id: P.shop.id, action: 'password', user_id: d.pw, password: val('npw') }, { withUser: true }); toast(t('Password updated')); closeDrawer(); }
      catch (err) { $('#drErr').textContent = errText(err); }
    });
    return;
  }
  if (d.removeUser) { try { await rpc('remove_member', { p_shop: P.shop.id, p_user: d.removeUser }, { withUser: true }); await showSettings(); } catch (err) { toast(errText(err)); } return; }
});
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('tr.click')) e.target.click(); });
// rows are <tr data-booking>: route their clicks too
document.addEventListener('click', e => { const row = e.target.closest('tr.click'); if (row && P.upcoming) { const bk = P.upcoming.find(x => x.id === row.dataset.booking); if (bk) bookingDrawer(bk); } });

boot();
setInterval(() => { if (P.tab === 'day' && P.day && P.date === P.day.today && $('#drawer').hidden && !document.hidden) showDay(); }, 60_000);
