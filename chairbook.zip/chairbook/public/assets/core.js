// Shared browser helpers: config, Supabase calls, login session, formatting.
let cfgPromise;
export function config() {
  cfgPromise ||= fetch('/api/config').then(r => { if (!r.ok) throw new Error('config'); return r.json(); });
  return cfgPromise;
}

export class ApiError extends Error { constructor(code, msg, status) { super(msg || code); this.code = code; this.status = status; } }

const SESSION = 'chairbook.session';
function readSession() { try { return JSON.parse(localStorage.getItem(SESSION) || 'null'); } catch { return null; } }
function writeSession(s) { try { s ? localStorage.setItem(SESSION, JSON.stringify(s)) : localStorage.removeItem(SESSION); } catch {} }
let memSession = null;
export function session() { return memSession || readSession(); }

async function authFetch(path, body) {
  const c = await config();
  const r = await fetch(`${c.supabaseUrl}/auth/v1/${path}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', apikey: c.supabaseKey }, body: JSON.stringify(body),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new ApiError(d.error_code || d.error || 'login_failed', d.msg || d.error_description || d.message || 'Login failed', r.status);
  return d;
}

function keep(d) {
  const s = { access_token: d.access_token, refresh_token: d.refresh_token, expires_at: Date.now() + (d.expires_in || 3600) * 1000, email: d.user && d.user.email };
  memSession = s; writeSession(s); return s;
}

export async function login(email, password) { return keep(await authFetch('token?grant_type=password', { email, password })); }
export function logout() { memSession = null; writeSession(null); }

async function freshToken() {
  let s = session();
  if (!s) return null;
  if (s.expires_at - Date.now() < 60_000) {
    try { s = keep(await authFetch('token?grant_type=refresh_token', { refresh_token: s.refresh_token })); }
    catch { logout(); return null; }
  }
  return s.access_token;
}

// Call a database function. withUser=true sends the logged-in user's token.
export async function rpc(fn, args = {}, { withUser = false } = {}) {
  const c = await config();
  const headers = { 'Content-Type': 'application/json', apikey: c.supabaseKey };
  if (withUser) {
    const t = await freshToken();
    if (!t) throw new ApiError('login_required', 'Please log in', 401);
    headers.Authorization = `Bearer ${t}`;
  } else headers.Authorization = `Bearer ${c.supabaseKey}`;
  const r = await fetch(`${c.supabaseUrl}/rest/v1/rpc/${fn}`, { method: 'POST', headers, body: JSON.stringify(args) });
  const text = await r.text();
  let d = null; try { d = text ? JSON.parse(text) : null; } catch { d = text; }
  if (!r.ok) {
    if (r.status === 401 || (d && d.code === 'PGRST301')) { if (withUser) logout(); throw new ApiError('login_required', 'Please log in again', 401); }
    throw new ApiError((d && d.message) || 'error', (d && d.message) || 'Request failed', r.status);
  }
  return d;
}

// Call one of our own server routes.
export async function api(path, body, { withUser = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (withUser) {
    const t = await freshToken();
    if (!t) throw new ApiError('login_required', 'Please log in', 401);
    headers.Authorization = `Bearer ${t}`;
  }
  const r = await fetch(path, { method: 'POST', headers, body: JSON.stringify(body || {}) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new ApiError(d.error || 'error', d.message || 'Request failed', r.status);
  return d;
}

// ---- formatting ----
export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const pad = n => String(n).padStart(2, '0');
export const isoDate = d => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
export const fromIso = s => new Date(s + 'T12:00:00Z');          // noon UTC: safe date arithmetic
export const addDays = (s, n) => { const d = fromIso(s); d.setUTCDate(d.getUTCDate() + n); return isoDate(d); };
export const dow = s => fromIso(s).getUTCDay();
export const mins = t => +t.slice(0, 2) * 60 + +t.slice(3, 5);
export const hhmm = m => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
export const LOCALES = { ka: 'ka-GE', en: 'en-GB', ru: 'ru-RU' };
export function fmtDate(s, lang, opts) { return fromIso(s).toLocaleDateString(LOCALES[lang] || 'en-GB', { timeZone: 'UTC', ...opts }); }
export function money(n, cur = 'GEL') {
  const v = Number(n || 0);
  const s = Number.isInteger(v) ? String(v) : v.toFixed(2);
  return cur === 'GEL' ? `${s} ₾` : `${s} ${cur}`;
}
export function money0(n, cur = 'GEL') { return money(Math.round(Number(n || 0)), cur); }
export function tr(j, lang) { if (!j) return ''; if (typeof j === 'string') return j; return j[lang] || j.en || j.ka || j.ru || ''; }

export function toast(msg) {
  let t = $('#toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; t.setAttribute('role', 'status'); document.body.append(t); }
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast.h); toast.h = setTimeout(() => (t.hidden = true), 3200);
}

// Apply a shop's accent colour, keeping readable contrast for button text.
export function applyAccent(hex) {
  if (!/^#[0-9a-f]{6}$/i.test(hex || '')) return;
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
  const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  document.documentElement.style.setProperty('--accent', hex);
  document.documentElement.style.setProperty('--accent-ink', lum > 0.6 ? '#1b2130' : '#ffffff');
}
