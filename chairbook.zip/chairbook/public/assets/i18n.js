// Customer-facing text in Georgian, English and Russian.
export const LANGS = { ka: 'ქარ', en: 'ENG', ru: 'РУС' };

export const T = {
  ka: {
    book_title: 'დაჯავშნე ვიზიტი', hero_sub: 'აირჩიე მომსახურება, ბარბერი და დრო. დადასტურება SMS-ით მოგივა.',
    step: 'ნაბიჯი', s_service: 'მომსახურება', s_barber: 'ბარბერი', s_time: 'თარიღი და დრო', s_details: 'თქვენი მონაცემები',
    addons: 'დამატებით', any_barber: 'ნებისმიერი თავისუფალი', any_barber_sub: 'ყველაზე სწრაფი', min: 'წთ',
    closed: 'დაკეტილია', free_times: 'თავისუფალი დრო', no_times: 'ამ დღეს თავისუფალი დრო აღარ არის. სცადეთ სხვა დღე.',
    closed_day: 'ამ დღეს დაკეტილია.', loading: 'იტვირთება…',
    name: 'სახელი და გვარი', phone: 'ტელეფონი', email: 'ელფოსტა (არასავალდებულო)', note: 'კომენტარი (არასავალდებულო)',
    pay: 'გადახდა', pay_shop: 'ადგილზე', pay_shop_sub: 'ნაღდი ან ბარათი', pay_full: 'სრულად ონლაინ', pay_deposit: 'ავანსი ონლაინ',
    pay_card_sub: 'ბარათი, Apple Pay, Google Pay', pay_rest_shop: 'დანარჩენი ადგილზე',
    your_booking: 'თქვენი ჯავშანი', service: 'მომსახურება', barber: 'ბარბერი', when: 'როდის', length: 'ხანგრძლივობა',
    total: 'ჯამი', due_now: 'ახლა გადასახდელი', due_shop: 'ადგილზე გადასახდელი',
    book_btn: 'დაჯავშნა', pay_btn: 'გადახდა და დაჯავშნა', pick_time: 'გასაგრძელებლად აირჩიეთ დრო.', sending: 'იგზავნება…',
    redirect_bank: 'გადაგიყვანთ ბანკის გადახდის გვერდზე…',
    unavailable: 'ონლაინ ჯავშანი ახლა მიუწვდომელია. დაგვირეკეთ.', not_found: 'ეს გვერდი ვერ მოიძებნა.',
    e_name: 'შეიყვანეთ სახელი.', e_phone: 'შეიყვანეთ სწორი ტელეფონის ნომერი.', e_email: 'ელფოსტა არასრულია.',
    slot_taken: 'ეს დრო ახლახან დაიკავეს. აირჩიეთ სხვა.', too_soon: 'ეს დრო ძალიან ახლოსაა. აირჩიეთ უფრო გვიანი.',
    shop_closed: 'ამ დღეს დაკეტილია.', outside_hours: 'ეს დრო სამუშაო საათებს სცდება.',
    online_pay_unavailable: 'ონლაინ გადახდა ახლა მიუწვდომელია.', pay_online_required: 'ამ სალონში ჯავშნისთვის საჭიროა ონლაინ გადახდა.',
    payment_start_failed: 'ბანკის გვერდი ვერ გაიხსნა. სცადეთ თავიდან ან აირჩიეთ ადგილზე გადახდა.',
    generic: 'რაღაც შეცდომა მოხდა. სცადეთ თავიდან.',
    // confirmation page
    booked: 'დაჯავშნილია', see_you: 'გელოდებით', pending: 'ველოდებით ბანკის დადასტურებას…', pending_sub: 'ჩვეულებრივ რამდენიმე წამი სჭირდება.',
    failed: 'გადახდა არ შედგა', failed_sub: 'დრო გათავისუფლდა. შეგიძლიათ თავიდან დაჯავშნოთ.', cancelled: 'ჯავშანი გაუქმებულია',
    code: 'ჯავშნის კოდი', paid_online: 'გადახდილი ონლაინ', book_again: 'ახალი ჯავშანი', sms_note: 'დადასტურებას SMS-ით მიიღებთ.',
    refund_note: 'ეს დრო სხვამ დაიკავა სანამ გადახდა დასრულდებოდა. სალონი დაგიბრუნებთ თანხას. დაუკავშირდით მათ.',
  },
  en: {
    book_title: 'Book a visit', hero_sub: 'Pick a service, a barber and a time. We text you a confirmation.',
    step: 'Step', s_service: 'Service', s_barber: 'Barber', s_time: 'Date & time', s_details: 'Your details',
    addons: 'Add-ons', any_barber: 'First available', any_barber_sub: 'Fastest booking', min: 'min',
    closed: 'closed', free_times: 'Free times', no_times: 'No free times left this day. Try another day.',
    closed_day: 'The shop is closed this day.', loading: 'Loading…',
    name: 'Full name', phone: 'Phone', email: 'Email (optional)', note: 'Note (optional)',
    pay: 'Payment', pay_shop: 'In the shop', pay_shop_sub: 'Cash or card', pay_full: 'Pay in full online', pay_deposit: 'Deposit online',
    pay_card_sub: 'Card, Apple Pay, Google Pay', pay_rest_shop: 'rest in the shop',
    your_booking: 'Your booking', service: 'Service', barber: 'Barber', when: 'When', length: 'Length',
    total: 'Total', due_now: 'To pay now', due_shop: 'To pay in the shop',
    book_btn: 'Book now', pay_btn: 'Pay and book', pick_time: 'Pick a time to continue.', sending: 'Booking…',
    redirect_bank: 'Taking you to the bank’s payment page…',
    unavailable: 'Online booking is not available right now. Please call the shop.', not_found: 'This booking page doesn’t exist.',
    e_name: 'Enter your name.', e_phone: 'Enter a valid phone number.', e_email: 'This email looks incomplete.',
    slot_taken: 'That time was just taken. Pick another one.', too_soon: 'That time is too soon. Pick a later one.',
    shop_closed: 'The shop is closed that day.', outside_hours: 'That time is outside opening hours.',
    online_pay_unavailable: 'Online payment is not available right now.', pay_online_required: 'This shop asks you to pay online to book.',
    payment_start_failed: 'The bank’s payment page didn’t open. Try again or choose to pay in the shop.',
    generic: 'Something went wrong. Please try again.',
    booked: 'Booked', see_you: 'See you soon', pending: 'Waiting for the bank to confirm…', pending_sub: 'This usually takes a few seconds.',
    failed: 'Payment didn’t go through', failed_sub: 'The time was released. You can book again.', cancelled: 'This booking was cancelled',
    code: 'Booking code', paid_online: 'Paid online', book_again: 'Book again', sms_note: 'We’ll text you a confirmation.',
    refund_note: 'Someone else took this time before your payment finished. The shop will refund you; please contact them.',
  },
  ru: {
    book_title: 'Записаться', hero_sub: 'Выберите услугу, мастера и время. Подтверждение придёт по SMS.',
    step: 'Шаг', s_service: 'Услуга', s_barber: 'Мастер', s_time: 'Дата и время', s_details: 'Ваши данные',
    addons: 'Дополнительно', any_barber: 'Любой свободный', any_barber_sub: 'Быстрее всего', min: 'мин',
    closed: 'выходной', free_times: 'Свободное время', no_times: 'На этот день свободного времени нет. Выберите другой день.',
    closed_day: 'В этот день закрыто.', loading: 'Загрузка…',
    name: 'Имя и фамилия', phone: 'Телефон', email: 'Эл. почта (необязательно)', note: 'Комментарий (необязательно)',
    pay: 'Оплата', pay_shop: 'На месте', pay_shop_sub: 'Наличными или картой', pay_full: 'Полностью онлайн', pay_deposit: 'Предоплата онлайн',
    pay_card_sub: 'Карта, Apple Pay, Google Pay', pay_rest_shop: 'остальное на месте',
    your_booking: 'Ваша запись', service: 'Услуга', barber: 'Мастер', when: 'Когда', length: 'Длительность',
    total: 'Итого', due_now: 'К оплате сейчас', due_shop: 'Оплата на месте',
    book_btn: 'Записаться', pay_btn: 'Оплатить и записаться', pick_time: 'Выберите время, чтобы продолжить.', sending: 'Отправка…',
    redirect_bank: 'Переходим на страницу оплаты банка…',
    unavailable: 'Онлайн-запись сейчас недоступна. Позвоните нам.', not_found: 'Страница не найдена.',
    e_name: 'Введите имя.', e_phone: 'Введите правильный номер телефона.', e_email: 'Адрес почты неполный.',
    slot_taken: 'Это время только что заняли. Выберите другое.', too_soon: 'Это время слишком близко. Выберите позже.',
    shop_closed: 'В этот день закрыто.', outside_hours: 'Это время вне часов работы.',
    online_pay_unavailable: 'Онлайн-оплата сейчас недоступна.', pay_online_required: 'Для записи нужна онлайн-оплата.',
    payment_start_failed: 'Страница банка не открылась. Попробуйте снова или выберите оплату на месте.',
    generic: 'Что-то пошло не так. Попробуйте снова.',
    booked: 'Вы записаны', see_you: 'Ждём вас', pending: 'Ждём подтверждения банка…', pending_sub: 'Обычно это занимает несколько секунд.',
    failed: 'Оплата не прошла', failed_sub: 'Время освобождено. Можно записаться снова.', cancelled: 'Запись отменена',
    code: 'Код записи', paid_online: 'Оплачено онлайн', book_again: 'Записаться снова', sms_note: 'Подтверждение придёт по SMS.',
    refund_note: 'Это время заняли до завершения оплаты. Салон вернёт деньги, свяжитесь с ним.',
  },
};

export function pickLang(fallback = 'ka') {
  const q = new URLSearchParams(location.search).get('lang');
  if (q && T[q]) return q;
  try { const s = localStorage.getItem('chairbook.lang'); if (s && T[s]) return s; } catch {}
  return T[fallback] ? fallback : 'ka';
}
export function saveLang(l) { try { localStorage.setItem('chairbook.lang', l); } catch {} }
