import { rpc, api, $, $$, esc, addDays, dow, fmtDate, money, tr, applyAccent, ApiError } from './core.js';
import { T, LANGS, pickLang, saveLang } from './i18n.js';

const slug = (new URLSearchParams(location.search).get('shop') || location.pathname.split('/').filter(Boolean)[0] || '').toLowerCase();
const S = { shop: null, lang: 'ka', svc: null, addons: new Set(), barber: null, date: null, time: null, pay: 'shop', avail: null, minutes: 0, busy: false, seq: 0 };
const t = k => (T[S.lang] && T[S.lang][k]) || T.en[k] || k;

async function start() {
  try {
    S.shop = await rpc('get_shop_public', { p_slug: slug });
  } catch (e) { S.shop = null; }
  $('#loading').hidden = true;
  S.lang = pickLang(S.shop ? S.shop.default_lang : 'ka');
  if (!S.shop) { $('#missing').hidden = false; $('#missingText').textContent = t('not_found'); return; }
  applyAccent(S.shop.accent);
  const mains = S.shop.services.filter(s => !s.is_addon);
  S.svc = mains[0] ? mains[0].id : null;
  S.pay = defaultPay();
  S.date = firstOpenDay();
  $('#app').hidden = false;
  renderAll();
  loadSlots();
}

function defaultPay() {
  const o = S.shop.online;
  if (S.shop.pay_in_shop) return 'shop';
  if (!o) return 'shop';
  return o.mode === 'deposit' ? 'deposit' : 'full';
}

function isClosed(d) {
  const h = S.shop.hours[String(dow(d))];
  return !Array.isArray(h) || S.shop.closed_dates.includes(d);
}
function firstOpenDay() {
  for (let i = 0; i <= S.shop.booking_days; i++) { const d = addDays(S.shop.today, i); if (!isClosed(d)) return d; }
  return S.shop.today;
}

function svcObj(id) { return S.shop.services.find(s => s.id === id); }
function totals() {
  const main = svcObj(S.svc);
  const adds = [...S.addons].map(svcObj).filter(Boolean);
  const price = (main ? Number(main.price) : 0) + adds.reduce((a, s) => a + Number(s.price), 0);
  const minutes = (main ? main.duration_min : 0) + adds.reduce((a, s) => a + s.duration_min, 0);
  const o = S.shop.online;
  let due = 0;
  if (o && S.pay === 'full') due = price;
  if (o && S.pay === 'deposit') due = Math.min(price, Math.max(1, Math.round(price * o.deposit_percent) / 100));
  return { main, adds, price, minutes, due };
}

function renderAll() {
  document.documentElement.lang = S.lang;
  document.title = `${S.shop.name} · ${t('book_title')}`;
  $$('[data-t]').forEach(el => (el.textContent = t(el.dataset.t)));
  $('#brand').textContent = S.shop.name; $('#brand').href = `/${S.shop.slug}`;
  $('#shopShort').textContent = S.shop.name;
  $('#meta').innerHTML = [S.shop.address, S.shop.phone].filter(Boolean).map(x => `<span>${esc(x)}</span>`).join('');
  $('#langs').innerHTML = Object.entries(LANGS).map(([k, v]) => `<button type="button" data-lang="${k}" aria-pressed="${k === S.lang}" lang="${k}">${v}</button>`).join('');
  $('#title').textContent = t('book_title');
  $('#sub').textContent = tr(S.shop.tagline, S.lang) || t('hero_sub');
  renderHours();
  const off = !S.shop.open;
  $('#unavailable').hidden = !off; $('#unavailable').textContent = t('unavailable') + (S.shop.phone ? ` ${S.shop.phone}` : '');
  $('#main').hidden = off;
  if (off) return;
  renderServices(); renderBarbers(); renderDays(); renderSlots(); renderPay(); renderSummary();
}

function renderHours() {
  const order = [1, 2, 3, 4, 5, 6, 0];
  const base = '2024-01-01'; // a Monday
  $('#hours').innerHTML = order.map((d, i) => {
    const h = S.shop.hours[String(d)];
    const name = fmtDate(addDays(base, i), S.lang, { weekday: 'short' });
    return `<span>${esc(name)}</span><b>${Array.isArray(h) ? `${h[0]} – ${h[1]}` : esc(t('closed'))}</b>`;
  }).join('');
}

function renderServices() {
  const mains = S.shop.services.filter(s => !s.is_addon), adds = S.shop.services.filter(s => s.is_addon);
  $('#services').innerHTML = mains.map(s => `<button type="button" class="opt" data-svc="${s.id}" aria-pressed="${S.svc === s.id}">
      <span class="t">${esc(tr(s.name, S.lang))}</span><span class="p">${money(s.price, S.shop.currency)}</span>
      ${tr(s.description, S.lang) ? `<span class="d">${esc(tr(s.description, S.lang))}</span>` : ''}
      <span class="m">${s.duration_min} ${esc(t('min'))}</span></button>`).join('');
  $('#addons').innerHTML = adds.length ? `<span class="lbl">${esc(t('addons'))}</span>` + adds.map(a =>
    `<button type="button" class="chip" data-addon="${a.id}" aria-pressed="${S.addons.has(a.id)}">+ ${esc(tr(a.name, S.lang))} · ${money(a.price, S.shop.currency)}</button>`).join('') : '';
}

function renderBarbers() {
  const list = [{ id: null, name: t('any_barber'), sub: t('any_barber_sub'), any: true }, ...S.shop.barbers.map(b => ({ id: b.id, name: b.name, sub: tr(b.title, S.lang) }))];
  $('#barbers').innerHTML = list.map(b => `<button type="button" class="barber" data-barber="${b.id || ''}" aria-pressed="${S.barber === b.id}">
      <span class="av${b.any ? ' any' : ''}">${b.any ? '★' : esc(b.name.trim().charAt(0).toUpperCase())}</span>
      <span class="t">${esc(b.name)}</span>${b.sub ? `<span class="s">${esc(b.sub)}</span>` : ''}</button>`).join('');
}

function renderDays() {
  const out = [];
  for (let i = 0; i <= S.shop.booking_days; i++) {
    const d = addDays(S.shop.today, i), closed = isClosed(d);
    out.push(`<button type="button" class="day" data-day="${d}" aria-pressed="${S.date === d}" ${closed ? 'disabled' : ''} aria-label="${esc(fmtDate(d, S.lang, { weekday: 'long', day: 'numeric', month: 'long' }))}${closed ? ', ' + esc(t('closed')) : ''}">
      <div class="w">${esc(fmtDate(d, S.lang, { weekday: 'short' }))}</div><div class="n">${+d.slice(8)}</div>
      <div class="mo">${closed ? esc(t('closed')) : esc(fmtDate(d, S.lang, { month: 'short' }))}</div></button>`);
  }
  $('#days').innerHTML = out.join('');
  const sel = $('#days [aria-pressed="true"]');
  if (sel) sel.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

async function loadSlots() {
  if (!S.svc || !S.date) return;
  const seq = ++S.seq;
  S.avail = null; renderSlots();
  try {
    const r = await rpc('get_availability', { p_slug: slug, p_date: S.date, p_service: S.svc, p_addons: [...S.addons], p_barber: S.barber });
    if (seq !== S.seq) return;
    S.avail = r;
    if (S.time && !(r.slots || []).some(s => s.t === S.time && s.free)) S.time = null;
  } catch (e) {
    if (seq !== S.seq) return;
    S.avail = { error: true, slots: [] };
  }
  renderSlots(); renderSummary();
}

function renderSlots() {
  $('#slotsH').textContent = `${t('free_times')} · ${fmtDate(S.date, S.lang, { weekday: 'long', day: 'numeric', month: 'long' })}`;
  const el = $('#slots');
  if (!S.avail) { el.innerHTML = `<div class="empty"><span class="spinner"></span> ${esc(t('loading'))}</div>`; return; }
  if (S.avail.error) { el.innerHTML = `<div class="empty">${esc(t('generic'))}</div>`; return; }
  if (S.avail.closed) { el.innerHTML = `<div class="empty">${esc(t('closed_day'))}</div>`; return; }
  const any = S.avail.slots.some(s => s.free);
  el.innerHTML = any ? S.avail.slots.map(s => `<button type="button" class="slot" data-time="${s.t}" aria-pressed="${S.time === s.t}" ${s.free ? '' : 'disabled'}>${s.t}</button>`).join('')
    : `<div class="empty">${esc(t('no_times'))}</div>`;
}

function renderPay() {
  const o = S.shop.online, { price } = totals(), cur = S.shop.currency;
  const opts = [];
  if (S.shop.pay_in_shop) opts.push({ k: 'shop', t: t('pay_shop'), s: t('pay_shop_sub'), amt: null });
  if (o && o.mode !== 'deposit') opts.push({ k: 'full', t: t('pay_full'), s: t('pay_card_sub'), amt: price });
  if (o && o.mode !== 'full') opts.push({ k: 'deposit', t: t('pay_deposit'), s: `${o.deposit_percent}% · ${t('pay_rest_shop')}`, amt: Math.max(1, Math.round(price * o.deposit_percent) / 100) });
  if (!opts.some(x => x.k === S.pay)) S.pay = opts[0] ? opts[0].k : 'shop';
  $('#payWrap').hidden = opts.length < 2;
  $('#pay').setAttribute('aria-label', t('pay'));
  $('#pay').innerHTML = opts.map(x => `<button type="button" class="pm" data-pay="${x.k}" aria-pressed="${S.pay === x.k}">
     ${esc(x.t)}<small>${esc(x.s)}</small>${x.amt != null ? `<span class="amt">${money(x.amt, cur)}</span>` : ''}</button>`).join('');
}

function renderSummary() {
  const { main, adds, price, minutes, due } = totals(), cur = S.shop.currency;
  const barber = S.barber ? (S.shop.barbers.find(b => b.id === S.barber) || {}).name : t('any_barber');
  const ready = !!S.time && !S.busy;
  const rows = [
    [t('service'), esc(main ? tr(main.name, S.lang) : '—') + (adds.length ? `<br><span class="muted">+ ${adds.map(a => esc(tr(a.name, S.lang))).join(', ')}</span>` : '')],
    [t('barber'), esc(barber)],
    [t('when'), `<span class="mono">${esc(fmtDate(S.date, S.lang, { weekday: 'short', day: 'numeric', month: 'short' }))} · ${S.time || '--:--'}</span>`],
    [t('length'), `<span class="mono">${minutes} ${esc(t('min'))}</span>`],
  ];
  $('#summary').innerHTML = rows.map(([k, v]) => `<div class="row"><span class="k">${esc(k)}</span><span class="v">${v}</span></div>`).join('') +
    `<div class="perf"></div>
     <div class="tot"><span class="k">${esc(t('total'))}</span><span class="v">${money(price, cur)}</span></div>
     <div class="due">${due > 0 ? `${esc(t('due_now'))}: ${money(due, cur)}${due < price ? ` · ${esc(t('due_shop'))}: ${money(price - due, cur)}` : ''}` : `${esc(t('due_shop'))}: ${money(price, cur)}`}</div>
     <button type="button" class="btn cta" id="submit" aria-disabled="${!ready}">${S.busy ? `<span class="spinner"></span> ${esc(t('sending'))}` : esc(due > 0 ? t('pay_btn') : t('book_btn'))}</button>
     ${S.time ? '' : `<div class="missing">${esc(t('pick_time'))}</div>`}`;
}

function setErr(id, msg) { const i = $('#' + id), e = $('#e-' + id); i.classList.toggle('bad', !!msg); e.textContent = msg || ''; return !msg; }
function validate() {
  let ok = setErr('name', $('#name').value.trim().length < 2 ? t('e_name') : '');
  ok = setErr('phone', $('#phone').value.replace(/\D/g, '').length < 7 ? t('e_phone') : '') && ok;
  const em = $('#email').value.trim();
  ok = setErr('email', em && !/^\S+@\S+\.\S+$/.test(em) ? t('e_email') : '') && ok;
  return ok;
}

async function submit() {
  $('#formErr').textContent = '';
  if (!S.time) { $('#h3s').scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
  if (!validate()) { $('#h4s').scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
  S.busy = true; renderSummary();
  try {
    const r = await api('/api/book', {
      slug, service_id: S.svc, addon_ids: [...S.addons], barber_id: S.barber, date: S.date, time: S.time,
      name: $('#name').value.trim(), phone: $('#phone').value.trim(), email: $('#email').value.trim(), note: $('#note').value.trim(),
      website: $('#website').value, lang: S.lang, pay_choice: S.pay,
    });
    if (r.redirect) { $('#formErr').textContent = t('redirect_bank'); location.href = r.redirect; return; }
    location.href = `/b/${r.id}?lang=${S.lang}`;
  } catch (e) {
    S.busy = false;
    const code = e instanceof ApiError ? e.code : 'generic';
    $('#formErr').textContent = T[S.lang][code] || t('generic');
    if (code === 'slot_taken' || code === 'too_soon') { S.time = null; loadSlots(); }
    renderSummary();
  }
}

document.addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.lang) { S.lang = b.dataset.lang; saveLang(S.lang); renderAll(); return; }
  if (b.dataset.svc) { S.svc = b.dataset.svc; renderServices(); renderPay(); renderSummary(); loadSlots(); return; }
  if (b.dataset.addon) { const id = b.dataset.addon; S.addons.has(id) ? S.addons.delete(id) : S.addons.add(id); renderServices(); renderPay(); renderSummary(); loadSlots(); return; }
  if (b.dataset.barber !== undefined && b.classList.contains('barber')) { S.barber = b.dataset.barber || null; renderBarbers(); renderSummary(); loadSlots(); return; }
  if (b.dataset.day) { S.date = b.dataset.day; S.time = null; renderDays(); renderSummary(); loadSlots(); return; }
  if (b.dataset.time) { S.time = b.dataset.time; renderSlots(); renderSummary(); return; }
  if (b.dataset.pay) { S.pay = b.dataset.pay; renderPay(); renderSummary(); return; }
  if (b.id === 'submit') { if (!S.busy) submit(); }
});
$('#form').addEventListener('submit', e => { e.preventDefault(); submit(); });

start();
