// Bank of Georgia and TBC online payments, using each shop's own merchant keys.
// Docs: https://api.bog.ge/docs/en/payments/introduction
//       https://developers.tbcbank.ge/docs/checkout-overview
import crypto from 'node:crypto';
import { env } from './env.js';
import { HttpError } from './http.js';

const tokens = new Map(); // cache: provider:clientId -> { token, until }

async function cached(k, fetcher) {
  const hit = tokens.get(k);
  if (hit && hit.until > Date.now() + 30_000) return hit.token;
  const { token, ttl } = await fetcher();
  tokens.set(k, { token, until: Date.now() + Math.min(ttl || 300, 3600) * 1000 });
  return token;
}

async function jsonOrText(r) {
  const t = await r.text();
  try { return JSON.parse(t); } catch { return { _raw: t }; }
}

const ascii = (s, n) => String(s || '').normalize('NFKD').replace(/[^\x20-\x7E]/g, '').slice(0, n);

// ---------------- TBC ----------------
const tbc = {
  async token(c) {
    const apikey = c.apikey || env.tbcApiKey;
    if (!apikey) throw new HttpError(500, 'not_configured', 'TBC API key is missing');
    return cached(`tbc:${c.client_id}`, async () => {
      const r = await fetch(`${env.tbcBase}/v1/tpay/access-token`, {
        method: 'POST',
        headers: { apikey, 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ client_id: c.client_id, client_secret: c.client_secret }),
      });
      const d = await jsonOrText(r);
      if (!r.ok || !d.access_token) throw new PayError('tbc', 'auth', r.status, d);
      return { token: d.access_token, ttl: d.expires_in };
    });
  },
  async create(c, o) {
    const token = await this.token(c);
    const r = await fetch(`${env.tbcBase}/v1/tpay/payments`, {
      method: 'POST',
      headers: { apikey: c.apikey || env.tbcApiKey, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount: { currency: 'GEL', total: o.amount, subTotal: 0, tax: 0, shipping: 0 },
        returnurl: o.returnUrl,
        callbackUrl: o.callbackUrl,
        extra: ascii(o.code, 25),
        expirationMinutes: 12,
        language: o.lang === 'ka' ? 'KA' : 'EN',
        merchantPaymentId: o.bookingId,
        description: ascii(o.description, 30),
      }),
    });
    const d = await jsonOrText(r);
    const link = (d.links || []).find(l => l.rel === 'approval_url');
    if (!r.ok || !d.payId || !link) throw new PayError('tbc', 'create', r.status, d);
    return { orderId: d.payId, redirect: link.uri };
  },
  async status(c, orderId) {
    const token = await this.token(c);
    const r = await fetch(`${env.tbcBase}/v1/tpay/payments/${encodeURIComponent(orderId)}`, {
      headers: { apikey: c.apikey || env.tbcApiKey, Authorization: `Bearer ${token}` },
    });
    const d = await jsonOrText(r);
    if (!r.ok) throw new PayError('tbc', 'status', r.status, d);
    const s = d.status;
    return {
      state: s === 'Succeeded' ? 'paid' : ['Failed', 'Expired'].includes(s) ? 'failed' : 'pending',
      amount: Number(d.confirmedAmount || d.amount || 0),
      raw: { status: s, payId: d.payId, resultCode: d.resultCode, transactionId: d.transactionId },
    };
  },
  orderIdFromCallback(body) {
    return body.PaymentId || body.paymentId || body.payId || null;
  },
};

// ---------------- Bank of Georgia ----------------
const bog = {
  async token(c) {
    return cached(`bog:${c.client_id}`, async () => {
      const r = await fetch(env.bogAuthUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: 'Basic ' + Buffer.from(`${c.client_id}:${c.client_secret}`).toString('base64'),
        },
        body: new URLSearchParams({ grant_type: 'client_credentials' }),
      });
      const d = await jsonOrText(r);
      if (!r.ok || !d.access_token) throw new PayError('bog', 'auth', r.status, d);
      // expires_in is seconds; guard against odd values in examples
      const ttl = Number(d.expires_in) > 0 && Number(d.expires_in) < 86400 ? Number(d.expires_in) : 300;
      return { token: d.access_token, ttl };
    });
  },
  async create(c, o) {
    const token = await this.token(c);
    const r = await fetch(`${env.bogBase}/payments/v1/ecommerce/orders`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`, 'Content-Type': 'application/json',
        'Accept-Language': o.lang === 'ka' ? 'ka' : 'en', 'Idempotency-Key': crypto.randomUUID(),
      },
      body: JSON.stringify({
        callback_url: o.callbackUrl,
        external_order_id: o.code,
        purchase_units: {
          currency: 'GEL', total_amount: o.amount,
          basket: [{ product_id: o.bookingId, quantity: 1, unit_price: o.amount, description: o.description }],
        },
        redirect_urls: { success: o.returnUrl, fail: o.returnUrl },
        ttl: 15,
      }),
    });
    const d = await jsonOrText(r);
    const href = d && d._links && d._links.redirect && d._links.redirect.href;
    if (!r.ok || !d.id || !href) throw new PayError('bog', 'create', r.status, d);
    return { orderId: d.id, redirect: href };
  },
  async status(c, orderId) {
    const token = await this.token(c);
    const r = await fetch(`${env.bogBase}/payments/v1/receipt/${encodeURIComponent(orderId)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const d = await jsonOrText(r);
    if (!r.ok) throw new PayError('bog', 'status', r.status, d);
    const key = d.order_status && d.order_status.key;
    const pu = d.purchase_units || {};
    return {
      state: key === 'completed' ? 'paid' : key === 'rejected' ? 'failed' : 'pending',
      amount: Number(pu.transfer_amount || pu.request_amount || 0),
      raw: { order_status: key, order_id: d.order_id, external_order_id: d.external_order_id },
    };
  },
  orderIdFromCallback(body) {
    return (body.body && body.body.order_id) || body.order_id || null;
  },
};

export const providers = { tbc, bog };

export class PayError extends Error {
  constructor(provider, step, status, detail) {
    super(`${provider} ${step} failed (${status}): ${JSON.stringify(detail).slice(0, 400)}`);
    this.provider = provider; this.step = step; this.httpStatus = status;
  }
}

// Check a shop's keys work by asking the bank for a token.
export async function testKeys(provider, creds) {
  await providers[provider].token(creds);
}
