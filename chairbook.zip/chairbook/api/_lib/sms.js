// SMS through SMSOffice.ge (https://smsoffice.ge). Sends nothing if not configured.
import { env } from './env.js';

export function normalizePhone(p) {
  let d = String(p || '').replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (d.length === 9 && d.startsWith('5')) d = '995' + d;         // Georgian mobile without country code
  return d.length >= 11 && d.length <= 15 ? d : null;
}

const T = {
  confirm: {
    ka: b => `${b.shop.name}: ჯავშანი დადასტურებულია ${fmtDate(b.date, 'ka')}, ${b.time}. კოდი ${b.code}.${b.shop.address ? ' ' + b.shop.address : ''}`,
    en: b => `${b.shop.name}: booking confirmed for ${fmtDate(b.date, 'en')} at ${b.time}. Code ${b.code}.${b.shop.address ? ' ' + b.shop.address : ''}`,
    ru: b => `${b.shop.name}: запись подтверждена на ${fmtDate(b.date, 'ru')}, ${b.time}. Код ${b.code}.${b.shop.address ? ' ' + b.shop.address : ''}`,
  },
  remind: {
    ka: b => `${b.shop.name}: შეხსენება, ხვალ ${b.time}-ზე გელოდებით. კოდი ${b.code}.`,
    en: b => `${b.shop.name}: reminder, see you tomorrow at ${b.time}. Code ${b.code}.`,
    ru: b => `${b.shop.name}: напоминаем, ждём вас завтра в ${b.time}. Код ${b.code}.`,
  },
};

function fmtDate(iso, lang) {
  const loc = { ka: 'ka-GE', en: 'en-GB', ru: 'ru-RU' }[lang] || 'en-GB';
  try { return new Date(iso + 'T12:00:00Z').toLocaleDateString(loc, { day: 'numeric', month: 'long', timeZone: 'UTC' }); }
  catch { return iso; }
}

export function smsText(kind, booking) {
  const lang = ['ka', 'en', 'ru'].includes(booking.lang) ? booking.lang : 'ka';
  return T[kind][lang](booking);
}

export async function sendSms(phone, text) {
  if (!env.smsKey || !env.smsSender) return { sent: false, reason: 'not_configured' };
  const to = normalizePhone(phone);
  if (!to) return { sent: false, reason: 'bad_number' };
  const r = await fetch(env.smsUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ key: env.smsKey, destination: to, sender: env.smsSender, content: text }),
  });
  const d = await r.json().catch(() => ({}));
  return { sent: !!d.Success, reason: d.Message, code: d.ErrorCode };
}
