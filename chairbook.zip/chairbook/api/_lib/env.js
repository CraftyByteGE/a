// Settings come from Vercel → Project → Settings → Environment Variables.
export const env = {
  supabaseUrl: (process.env.SUPABASE_URL || '').replace(/\/$/, ''),
  publicKey: process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '',
  secretKey: process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || '',
  appSecret: process.env.APP_SECRET || '',
  appUrl: (process.env.APP_URL || '').replace(/\/$/, ''),
  platformName: process.env.PLATFORM_NAME || 'Chairbook',
  tbcApiKey: process.env.TBC_API_KEY || '',
  tbcBase: (process.env.TBC_API_BASE || 'https://api.tbcbank.ge').replace(/\/$/, ''),
  bogAuthUrl: process.env.BOG_AUTH_URL || 'https://oauth2.bog.ge/auth/realms/bog/protocol/openid-connect/token',
  bogBase: (process.env.BOG_API_BASE || 'https://api.bog.ge').replace(/\/$/, ''),
  smsKey: process.env.SMSOFFICE_API_KEY || '',
  smsUrl: process.env.SMS_API_URL || 'https://smsoffice.ge/api/v2/send/',
  smsSender: process.env.SMS_SENDER || '',
  cronSecret: process.env.CRON_SECRET || '',
};

export function baseUrl(req) {
  if (env.appUrl) return env.appUrl;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const proto = req.headers['x-forwarded-proto'] || 'https';
  return `${proto}://${host}`;
}
