// Ask the bank what happened to a payment and update the booking. Used by the
// bank callback and by the confirmation page (in case a callback is missed).
import { rpc } from './supa.js';
import { open } from './crypto.js';
import { providers } from './pay.js';
import { sendSms, smsText } from './sms.js';

export async function settle(lookup) {
  if (!lookup || lookup.status !== 'created') return { state: lookup ? lookup.status : 'none' };
  const creds = open(lookup.secret);
  if (!creds) return { state: 'pending' };
  const st = await providers[lookup.provider].status(creds, lookup.order_id);
  if (st.state === 'paid') {
    const c = await rpc('confirm_payment', {
      p_provider: lookup.provider, p_order: lookup.order_id,
      p_amount: st.amount > 0 ? st.amount : Number(lookup.amount), p_raw: st.raw,
    });
    if (c && c.sms && !c.already) await confirmSms(c.booking.id);
    return { state: 'paid' };
  }
  if (st.state === 'failed') {
    await rpc('fail_payment', { p_provider: lookup.provider, p_order: lookup.order_id, p_raw: st.raw });
    return { state: 'failed' };
  }
  return { state: 'pending' };
}

export async function confirmSms(bookingId) {
  try {
    const b = await rpc('sms_info', { p_booking: bookingId });
    if (!b || !b.sms_enabled || b.confirmed_sms_at || b.status !== 'booked') return;
    const r = await sendSms(b.customer_phone, smsText('confirm', b));
    if (r.sent) await rpc('mark_sms', { p_ids: [bookingId], p_kind: 'confirm' });
  } catch (e) {
    console.error('confirmation sms failed', e); // never block a booking on SMS
  }
}
