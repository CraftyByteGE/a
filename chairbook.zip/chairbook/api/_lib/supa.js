// Tiny Supabase client over its REST API (no packages needed).
import { env } from './env.js';
import { HttpError } from './http.js';

// Same headers the official supabase-js client sends (works with old JWT keys and new sb_ keys).
function headers(key, token) {
  return { 'Content-Type': 'application/json', apikey: key, Authorization: `Bearer ${token || key}` };
}

// Known business errors raised by the database become 4xx with a code the pages translate.
const BUSINESS = new Set(['slot_taken','shop_closed','outside_hours','too_soon','too_far','bad_name','bad_phone',
  'service_not_found','online_pay_unavailable','pay_online_required','bad_payment','shop_not_found','not_allowed',
  'not_found','bad_status','pick_barber','bad_hours','need_a_payment_option','cannot_remove_self','bad_provider']);

export async function rpc(fn, args = {}, { token } = {}) {
  if (!env.supabaseUrl || !env.secretKey) throw new HttpError(500, 'not_configured', 'Supabase settings are missing');
  const r = await fetch(`${env.supabaseUrl}/rest/v1/rpc/${fn}`, {
    method: 'POST',
    headers: token ? headers(env.publicKey, token) : headers(env.secretKey),
    body: JSON.stringify(args),
  });
  const text = await r.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) {
    const msg = (data && (data.message || data.error)) || `rpc ${fn} failed`;
    if (BUSINESS.has(msg)) throw new HttpError(msg === 'not_allowed' ? 403 : 409, msg, msg);
    if (data && data.code === '23514') throw new HttpError(400, 'invalid', msg);
    if (data && data.code === '23505') throw new HttpError(409, 'duplicate', msg);
    throw new Error(`Supabase rpc ${fn}: ${r.status} ${msg}`);
  }
  return data;
}

// Who is calling? Verifies the user's access token with Supabase Auth.
export async function getUser(token) {
  if (!token) throw new HttpError(401, 'login_required', 'Please log in');
  const r = await fetch(`${env.supabaseUrl}/auth/v1/user`, { headers: headers(env.publicKey || env.secretKey, token) });
  if (!r.ok) throw new HttpError(401, 'login_required', 'Your session ended. Please log in again.');
  return r.json();
}

export async function adminCreateUser(email, password) {
  const r = await fetch(`${env.supabaseUrl}/auth/v1/admin/users`, {
    method: 'POST', headers: headers(env.secretKey),
    body: JSON.stringify({ email, password, email_confirm: true }),
  });
  const data = await r.json().catch(() => ({}));
  if (r.ok) return data;
  const msg = data.msg || data.message || data.error_description || '';
  if (/already|exists|registered/i.test(msg)) {
    const existing = await adminFindUser(email);
    if (existing) return { ...existing, existed: true };
  }
  if (/password/i.test(msg)) throw new HttpError(400, 'weak_password', 'Password is too weak. Use at least 8 characters.');
  throw new Error(`Create user failed: ${r.status} ${msg}`);
}

export async function adminFindUser(email) {
  const want = email.toLowerCase();
  for (let page = 1; page <= 20; page++) {
    const r = await fetch(`${env.supabaseUrl}/auth/v1/admin/users?page=${page}&per_page=200`, { headers: headers(env.secretKey) });
    if (!r.ok) return null;
    const data = await r.json();
    const list = data.users || [];
    const hit = list.find(u => (u.email || '').toLowerCase() === want);
    if (hit) return hit;
    if (list.length < 200) return null;
  }
  return null;
}

export async function adminSetPassword(userId, password) {
  const r = await fetch(`${env.supabaseUrl}/auth/v1/admin/users/${userId}`, {
    method: 'PUT', headers: headers(env.secretKey), body: JSON.stringify({ password }),
  });
  if (!r.ok) {
    const data = await r.json().catch(() => ({}));
    const msg = data.msg || data.message || '';
    if (/password/i.test(msg)) throw new HttpError(400, 'weak_password', 'Password is too weak. Use at least 8 characters.');
    throw new Error(`Set password failed: ${r.status} ${msg}`);
  }
}
