// Bank keys are encrypted with APP_SECRET before they are stored.
import crypto from 'node:crypto';
import { env } from './env.js';
import { HttpError } from './http.js';

function key() {
  if (!env.appSecret || env.appSecret.length < 32) throw new HttpError(500, 'not_configured', 'APP_SECRET must be at least 32 characters');
  return crypto.createHash('sha256').update(env.appSecret).digest();
}

export function seal(obj) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const data = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
  return ['v1', iv.toString('base64'), c.getAuthTag().toString('base64'), data.toString('base64')].join('.');
}

export function open(blob) {
  if (!blob) return null;
  const [v, iv, tag, data] = String(blob).split('.');
  if (v !== 'v1') throw new Error('Unknown secret format');
  const d = crypto.createDecipheriv('aes-256-gcm', key(), Buffer.from(iv, 'base64'));
  d.setAuthTag(Buffer.from(tag, 'base64'));
  return JSON.parse(Buffer.concat([d.update(Buffer.from(data, 'base64')), d.final()]).toString('utf8'));
}
