export class HttpError extends Error {
  constructor(status, code, message) { super(message || code); this.status = status; this.code = code; }
}

export function send(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

export async function readBody(req) {
  if (req.body !== undefined && req.body !== null) {
    if (typeof req.body === 'string') return parseText(req.body, req.headers['content-type']);
    if (Buffer.isBuffer(req.body)) return parseText(req.body.toString('utf8'), req.headers['content-type']);
    return req.body;
  }
  const chunks = [];
  for await (const c of req) chunks.push(c);
  return parseText(Buffer.concat(chunks).toString('utf8'), req.headers['content-type']);
}

function parseText(text, type = '') {
  if (!text) return {};
  if (String(type).includes('application/x-www-form-urlencoded')) return Object.fromEntries(new URLSearchParams(text));
  try { return JSON.parse(text); } catch { return { _raw: text }; }
}

export function bearer(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : '';
}

// Wrap a handler: method check, errors → JSON.
export function route(methods, fn) {
  return async (req, res) => {
    try {
      if (!methods.includes(req.method)) throw new HttpError(405, 'method_not_allowed');
      await fn(req, res);
    } catch (e) {
      const status = e.status || 500;
      if (status >= 500) console.error(e);
      send(res, status, { error: e.code || 'server_error', message: status >= 500 ? 'Something went wrong. Please try again.' : e.message });
    }
  };
}
