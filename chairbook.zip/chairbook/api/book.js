// POST /api/book — a customer books. Pays in shop, or is sent to the shop's bank to pay.
import { route, send, readBody, HttpError } from './_lib/http.js';
import { rpc } from './_lib/supa.js';
import { open } from './_lib/crypto.js';
import { providers } from './_lib/pay.js';
import { baseUrl } from './_lib/env.js';
import { confirmSms } from './_lib/settle.js';

const uuid = /^[0-9a-f-]{36}$/i;

export default route(['POST'], async (req, res) => {
  const b = await readBody(req);
  if (b.website) throw new HttpError(400, 'invalid'); // bot trap field, invisible to people
  if (!b.slug || !uuid.test(b.service_id || '') || !/^\d{4}-\d{2}-\d{2}$/.test(b.date || '') || !/^\d{2}:\d{2}$/.test(b.time || '')) {
    throw new HttpError(400, 'invalid', 'Missing booking details');
  }
  const args = {
    slug: String(b.slug).toLowerCase(), service_id: b.service_id,
    addon_ids: Array.isArray(b.addon_ids) ? b.addon_ids.filter(x => uuid.test(x)).slice(0, 10) : [],
    barber_id: uuid.test(b.barber_id || '') ? b.barber_id : null,
    date: b.date, time: b.time,
    name: String(b.name || '').slice(0, 80), phone: String(b.phone || '').slice(0, 30), email: String(b.email || '').slice(0, 120),
    note: String(b.note || '').slice(0, 300),
    lang: ['ka', 'en', 'ru'].includes(b.lang) ? b.lang : 'ka',
    pay_choice: ['shop', 'full', 'deposit'].includes(b.pay_choice) ? b.pay_choice : 'shop',
  };
  const k = await rpc('create_booking', { p: args });
  const base = baseUrl(req);
  const bookingUrl = `${base}/b/${k.id}`;

  if (Number(k.online_due) > 0) {
    try {
      const creds = open(await rpc('shop_secret', { p_shop: k.shop_id, p_provider: k.provider }));
      const order = await providers[k.provider].create(creds, {
        amount: Number(k.online_due), code: k.code, bookingId: k.id, lang: args.lang,
        description: `Booking ${k.code}`,
        returnUrl: bookingUrl,
        callbackUrl: `${base}/api/pay/callback?provider=${k.provider}`,
      });
      await rpc('attach_payment', { p_booking: k.id, p_provider: k.provider, p_order: String(order.orderId), p_amount: Number(k.online_due) });
      return send(res, 200, { id: k.id, code: k.code, redirect: order.redirect });
    } catch (e) {
      console.error('payment start failed', e);
      await rpc('abandon_booking', { p_booking: k.id }).catch(() => {});
      throw new HttpError(502, 'payment_start_failed', 'The bank payment page could not be opened. Try again or choose to pay in the shop.');
    }
  }

  await confirmSms(k.id);
  send(res, 200, { id: k.id, code: k.code, url: bookingUrl });
});
