// POST /api/admin/shops — platform admin adds a new barbershop and its owner's login.
import { route, send, readBody, bearer, HttpError } from '../_lib/http.js';
import { rpc, getUser, adminCreateUser } from '../_lib/supa.js';

export default route(['POST'], async (req, res) => {
  const user = await getUser(bearer(req));
  if (!(await rpc('is_admin_user', { p_user: user.id }))) throw new HttpError(403, 'not_allowed', 'Platform admins only');
  const b = await readBody(req);
  const slug = String(b.slug || '').trim().toLowerCase();
  const name = String(b.name || '').trim();
  const email = String(b.owner_email || '').trim().toLowerCase();
  const password = String(b.owner_password || '');
  if (!/^[a-z0-9][a-z0-9-]{1,39}$/.test(slug)) throw new HttpError(400, 'bad_slug', 'Web address: 2–40 lowercase letters, numbers or dashes');
  if (['api', 'admin', 'panel', 'b', 'assets', 'login', 'www'].includes(slug)) throw new HttpError(400, 'bad_slug', 'That web address is reserved');
  if (!name) throw new HttpError(400, 'bad_name', 'Enter the shop name');
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new HttpError(400, 'bad_email', 'Enter the owner’s email');
  if (password.length < 8) throw new HttpError(400, 'weak_password', 'Owner password needs at least 8 characters');

  const owner = await adminCreateUser(email, password); // existing login is reused (one owner, several shops)
  let shopId;
  try {
    shopId = await rpc('admin_create_shop', { p: { slug, name, address: b.address || '', phone: b.phone || '', paid_until: b.paid_until || '' } });
  } catch (e) {
    if (e.code === 'duplicate') throw new HttpError(409, 'slug_taken', 'That web address is already used by another shop');
    throw e;
  }
  await rpc('add_member', { p_shop: shopId, p_user: owner.id, p_role: 'owner', p_barber: null });
  send(res, 200, { ok: true, shop_id: shopId, owner_existed: !!owner.existed });
});
