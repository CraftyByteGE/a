// POST /api/shop/staff — owner adds a login for a barber or co-owner, or sets a new password.
import { route, send, readBody, bearer, HttpError } from '../_lib/http.js';
import { rpc, getUser, adminCreateUser, adminSetPassword } from '../_lib/supa.js';

const uuid = /^[0-9a-f-]{36}$/i;

export default route(['POST'], async (req, res) => {
  const user = await getUser(bearer(req));
  const b = await readBody(req);
  if (!uuid.test(b.shop_id || '')) throw new HttpError(400, 'invalid');
  const role = await rpc('role_of', { p_shop: b.shop_id, p_user: user.id });
  if (role !== 'owner') throw new HttpError(403, 'not_allowed', 'Only the shop owner can manage logins');
  const password = String(b.password || '');
  if (password.length < 8) throw new HttpError(400, 'weak_password', 'Use a password with at least 8 characters');

  if (b.action === 'password') {
    if (!uuid.test(b.user_id || '')) throw new HttpError(400, 'invalid');
    const theirs = await rpc('role_of', { p_shop: b.shop_id, p_user: b.user_id });
    if (!theirs) throw new HttpError(404, 'not_found', 'That login is not part of this shop');
    // Owners can only reset staff passwords; other owners and platform admins reset their own.
    if (theirs !== 'staff') throw new HttpError(403, 'not_allowed', 'You can only set passwords for staff logins');
    await adminSetPassword(b.user_id, password);
    return send(res, 200, { ok: true });
  }

  const email = String(b.email || '').trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new HttpError(400, 'bad_email', 'Enter a valid email address');
  const newRole = b.role === 'owner' ? 'owner' : 'staff';
  const created = await adminCreateUser(email, password);
  if (created.existed) throw new HttpError(409, 'email_taken', 'This email already has a login. Ask the platform admin to add it to your shop.');
  await rpc('add_member', { p_shop: b.shop_id, p_user: created.id, p_role: newRole, p_barber: uuid.test(b.barber_id || '') ? b.barber_id : null });
  send(res, 200, { ok: true, user_id: created.id });
});
