// POST /api/shop/secrets — a shop owner connects (or removes) their TBC / Bank of Georgia merchant account.
import { route, send, readBody, bearer, HttpError } from '../_lib/http.js';
import { rpc, getUser } from '../_lib/supa.js';
import { seal } from '../_lib/crypto.js';
import { testKeys } from '../_lib/pay.js';

export default route(['POST'], async (req, res) => {
  const user = await getUser(bearer(req));
  const b = await readBody(req);
  if (!['tbc', 'bog'].includes(b.provider) || !/^[0-9a-f-]{36}$/i.test(b.shop_id || '')) throw new HttpError(400, 'invalid');
  const role = await rpc('role_of', { p_shop: b.shop_id, p_user: user.id });
  if (role !== 'owner') throw new HttpError(403, 'not_allowed', 'Only the shop owner can change bank details');

  if (b.remove) {
    await rpc('set_secret', { p_shop: b.shop_id, p_provider: b.provider, p_value: null });
    return send(res, 200, { ok: true, removed: true });
  }
  const creds = {
    client_id: String(b.client_id || '').trim(),
    client_secret: String(b.client_secret || '').trim(),
  };
  if (b.provider === 'tbc' && b.apikey) creds.apikey = String(b.apikey).trim();
  if (!creds.client_id || !creds.client_secret) throw new HttpError(400, 'missing_keys', 'Enter both the Client ID and the Secret');
  try {
    await testKeys(b.provider, creds);
  } catch (e) {
    console.error('key test failed', e.message);
    if (e.code === 'not_configured') throw e;
    throw new HttpError(400, 'keys_rejected', 'The bank did not accept these keys. Check them in your bank merchant dashboard and try again.');
  }
  await rpc('set_secret', { p_shop: b.shop_id, p_provider: b.provider, p_value: seal(creds) });
  send(res, 200, { ok: true });
});
