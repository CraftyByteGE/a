// GET /api/cron/reminders — runs once a day (see vercel.json) and texts everyone booked for tomorrow.
import { route, send, HttpError } from '../_lib/http.js';
import { rpc } from '../_lib/supa.js';
import { env } from '../_lib/env.js';
import { sendSms, smsText } from '../_lib/sms.js';

export default route(['GET', 'POST'], async (req, res) => {
  if (!env.cronSecret || req.headers.authorization !== `Bearer ${env.cronSecret}`) throw new HttpError(401, 'unauthorized');
  const due = (await rpc('due_reminders')) || [];
  const sent = [];
  let failed = 0;
  for (const b of due) {
    const r = await sendSms(b.customer_phone, smsText('remind', b));
    if (r.sent) sent.push(b.id); else failed++;
  }
  if (sent.length) await rpc('mark_sms', { p_ids: sent, p_kind: 'remind' });
  send(res, 200, { due: due.length, sent: sent.length, failed });
});
