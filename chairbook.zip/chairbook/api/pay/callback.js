// POST /api/pay/callback?provider=tbc|bog — the bank tells us a payment finished.
// We never trust the message itself: we ask the bank for the real status with the shop's keys.
import { route, send, readBody } from '../_lib/http.js';
import { rpc } from '../_lib/supa.js';
import { providers } from '../_lib/pay.js';
import { settle } from '../_lib/settle.js';

export default route(['POST'], async (req, res) => {
  const provider = String((req.query && req.query.provider) || new URL(req.url, 'http://x').searchParams.get('provider') || '');
  if (!providers[provider]) return send(res, 400, { error: 'unknown_provider' });
  const body = await readBody(req);
  const orderId = providers[provider].orderIdFromCallback(body);
  if (!orderId) return send(res, 200, { ok: true, ignored: 'no_order_id' });
  const lookup = await rpc('payment_lookup', { p_provider: provider, p_order: String(orderId), p_booking: null });
  if (!lookup) return send(res, 200, { ok: true, ignored: 'unknown_order' });
  const r = await settle(lookup);
  send(res, 200, { ok: true, state: r.state });
});
