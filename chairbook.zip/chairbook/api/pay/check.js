// POST /api/pay/check {booking_id} — the confirmation page asks us to re-check with the bank.
import { route, send, readBody, HttpError } from '../_lib/http.js';
import { rpc } from '../_lib/supa.js';
import { settle } from '../_lib/settle.js';

export default route(['POST'], async (req, res) => {
  const { booking_id } = await readBody(req);
  if (!/^[0-9a-f-]{36}$/i.test(booking_id || '')) throw new HttpError(400, 'invalid');
  const lookup = await rpc('payment_lookup', { p_provider: null, p_order: null, p_booking: booking_id });
  let state = 'none';
  try { state = (await settle(lookup)).state; } catch (e) { console.error('payment check failed', e); state = 'pending'; }
  send(res, 200, { state });
});
