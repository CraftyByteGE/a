// GET /api/config — public settings the pages need (safe to expose).
import { route, send } from './_lib/http.js';
import { env } from './_lib/env.js';

export default route(['GET'], async (req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.statusCode = 200;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify({ supabaseUrl: env.supabaseUrl, supabaseKey: env.publicKey, platformName: env.platformName }));
});
