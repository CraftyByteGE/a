-- =====================================================================
-- Chairbook: multi-shop barbershop booking — database
-- Run once in Supabase: Dashboard → SQL Editor → paste → Run.
-- All data access goes through the functions at the bottom; tables are
-- closed to the browser (RLS on, no policies).
-- =====================================================================

create extension if not exists btree_gist with schema extensions;
create extension if not exists pgcrypto with schema extensions;

-- ---------- tables ----------------------------------------------------

create table if not exists public.shops (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,39}$'),
  name            text not null check (length(name) between 1 and 80),
  tagline         jsonb not null default '{}'::jsonb,           -- {"ka":..,"en":..,"ru":..}
  address         text not null default '',
  phone           text not null default '',
  accent          text not null default '#8f2a2a' check (accent ~ '^#[0-9a-fA-F]{6}$'),
  timezone        text not null default 'Asia/Tbilisi',
  currency        text not null default 'GEL',
  hours           jsonb not null default '{"0":["11:00","16:00"],"1":null,"2":["10:00","20:00"],"3":["10:00","20:00"],"4":["10:00","20:00"],"5":["10:00","20:00"],"6":["09:00","18:00"]}'::jsonb,
  slot_step       int  not null default 30 check (slot_step in (15,20,30,60)),
  lead_minutes    int  not null default 30 check (lead_minutes between 0 and 1440),
  booking_days    int  not null default 21 check (booking_days between 1 and 90),
  pay_in_shop     boolean not null default true,
  online_pay      text not null default 'off' check (online_pay in ('off','tbc','bog')),
  online_mode     text not null default 'choice' check (online_mode in ('full','deposit','choice')),
  deposit_percent int  not null default 20 check (deposit_percent between 5 and 100),
  sms_enabled     boolean not null default true,
  default_lang    text not null default 'ka' check (default_lang in ('ka','en','ru')),
  active          boolean not null default true,
  paid_until      date,
  admin_note      text not null default '',
  created_at      timestamptz not null default now()
);

create table if not exists public.barbers (
  id         uuid primary key default gen_random_uuid(),
  shop_id    uuid not null references public.shops(id) on delete cascade,
  name       text not null check (length(name) between 1 and 60),
  title      jsonb not null default '{}'::jsonb,
  sort       int not null default 0,
  active     boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists barbers_shop on public.barbers(shop_id);

create table if not exists public.services (
  id           uuid primary key default gen_random_uuid(),
  shop_id      uuid not null references public.shops(id) on delete cascade,
  name         jsonb not null,                                  -- {"ka":..,"en":..,"ru":..}
  description  jsonb not null default '{}'::jsonb,
  price        numeric(10,2) not null check (price >= 0),
  duration_min int not null check (duration_min between 5 and 480),
  is_addon     boolean not null default false,
  sort         int not null default 0,
  active       boolean not null default true,
  created_at   timestamptz not null default now()
);
create index if not exists services_shop on public.services(shop_id);

create table if not exists public.closures (
  id         uuid primary key default gen_random_uuid(),
  shop_id    uuid not null references public.shops(id) on delete cascade,
  barber_id  uuid references public.barbers(id) on delete cascade,  -- null = whole shop
  starts_on  date not null,
  ends_on    date not null,
  note       text not null default '',
  check (ends_on >= starts_on)
);
create index if not exists closures_shop on public.closures(shop_id, ends_on);

create table if not exists public.members (
  shop_id    uuid not null references public.shops(id) on delete cascade,
  user_id    uuid not null references auth.users(id) on delete cascade,
  role       text not null check (role in ('owner','staff')),
  barber_id  uuid references public.barbers(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key (shop_id, user_id)
);
create index if not exists members_user on public.members(user_id);

create table if not exists public.platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create table if not exists public.bookings (
  id             uuid primary key default gen_random_uuid(),
  shop_id        uuid not null references public.shops(id) on delete cascade,
  code           text not null unique,
  barber_id      uuid not null references public.barbers(id),
  service_id     uuid not null references public.services(id),
  addon_ids      uuid[] not null default '{}',
  items          jsonb not null,             -- snapshot of names/prices at booking time
  starts_at      timestamptz not null,
  ends_at        timestamptz not null,
  price          numeric(10,2) not null,
  pay_choice     text not null check (pay_choice in ('shop','full','deposit')),
  online_due     numeric(10,2) not null default 0,
  paid_online    numeric(10,2) not null default 0,
  status         text not null check (status in ('pending','booked','done','noshow','cancelled','expired')),
  hold_until     timestamptz,
  customer_name  text not null,
  customer_phone text not null,
  customer_email text not null default '',
  lang           text not null default 'ka',
  note           text not null default '',
  source         text not null default 'online' check (source in ('online','panel')),
  staff_note     text not null default '',
  reminded_at    timestamptz,
  confirmed_sms_at timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check (ends_at > starts_at),
  -- The guarantee: one barber can never hold two overlapping live bookings.
  constraint no_double_booking exclude using gist (
    barber_id with =, tstzrange(starts_at, ends_at) with &&
  ) where (status in ('pending','booked','done','noshow'))
);
create index if not exists bookings_shop_time on public.bookings(shop_id, starts_at);
create index if not exists bookings_status_time on public.bookings(status, starts_at);

create table if not exists public.payments (
  id          uuid primary key default gen_random_uuid(),
  booking_id  uuid not null references public.bookings(id) on delete cascade,
  shop_id     uuid not null references public.shops(id) on delete cascade,
  provider    text not null check (provider in ('tbc','bog')),
  order_id    text not null,
  amount      numeric(10,2) not null,
  status      text not null default 'created' check (status in ('created','paid','failed')),
  raw         jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (provider, order_id)
);
create index if not exists payments_booking on public.payments(booking_id);

-- Bank keys, encrypted by the server (AES-256-GCM) before they arrive here.
create table if not exists public.shop_secrets (
  shop_id    uuid primary key references public.shops(id) on delete cascade,
  tbc        text,
  bog        text,
  updated_at timestamptz not null default now()
);

-- Lock every table: the browser never reads tables directly.
do $$ declare t text; begin
  foreach t in array array['shops','barbers','services','closures','members','platform_admins','bookings','payments','shop_secrets'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
    execute format('grant all on public.%I to service_role', t);
  end loop;
end $$;

-- ---------- helpers ---------------------------------------------------

create or replace function public._tr(j jsonb, lang text) returns text
language sql immutable as $$
  select coalesce(nullif(j->>lang,''), nullif(j->>'en',''), nullif(j->>'ka',''), nullif(j->>'ru',''), '')
$$;

create or replace function public.is_platform_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from platform_admins where user_id = auth.uid())
$$;

create or replace function public._role_in(p_shop uuid) returns text
language sql stable security definer set search_path = public as $$
  select case when is_platform_admin() then 'owner'
              else (select role from members where shop_id = p_shop and user_id = auth.uid()) end
$$;

create or replace function public._require(p_shop uuid, p_owner boolean) returns void
language plpgsql stable security definer set search_path = public as $$
declare r text := _role_in(p_shop);
begin
  if r is null or (p_owner and r <> 'owner') then
    raise exception 'not_allowed' using errcode = '42501';
  end if;
end $$;

create or replace function public._today(p_tz text) returns date
language sql stable as $$ select (now() at time zone p_tz)::date $$;

create or replace function public._shop_open(s public.shops) returns boolean
language sql stable as $$
  select s.active and (s.paid_until is null or s.paid_until >= _today(s.timezone))
$$;

-- Is the shop (or barber) closed on a date, by weekly hours or a day off?
create or replace function public._hours_for(s public.shops, d date) returns jsonb
language sql stable as $$
  select case when jsonb_typeof(s.hours -> extract(dow from d)::int::text) = 'array'
              then s.hours -> extract(dow from d)::int::text end
$$;

create or replace function public._shop_closed(p_shop uuid, d date) returns boolean
language sql stable as $$
  select exists(select 1 from closures c where c.shop_id = p_shop and c.barber_id is null and d between c.starts_on and c.ends_on)
$$;

create or replace function public._barber_off(p_barber uuid, d date) returns boolean
language sql stable as $$
  select exists(select 1 from closures c where c.barber_id = p_barber and d between c.starts_on and c.ends_on)
$$;

create or replace function public._busy(p_barber uuid, a timestamptz, b timestamptz) returns boolean
language sql stable as $$
  select exists(
    select 1 from bookings k
    where k.barber_id = p_barber
      and tstzrange(k.starts_at, k.ends_at) && tstzrange(a, b)
      and (k.status in ('booked','done','noshow') or (k.status = 'pending' and k.hold_until > now()))
  )
$$;

create or replace function public._new_code() returns text
language plpgsql volatile as $$
declare alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; c text; i int;
begin
  loop
    c := '';
    for i in 1..6 loop
      c := c || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    exit when not exists(select 1 from bookings where code = c);
  end loop;
  return c;
end $$;

create or replace function public._payment_ready(p_shop uuid, p_provider text) returns boolean
language sql stable security definer set search_path = public as $$
  select case p_provider
    when 'tbc' then exists(select 1 from shop_secrets where shop_id = p_shop and tbc is not null)
    when 'bog' then exists(select 1 from shop_secrets where shop_id = p_shop and bog is not null)
    else false end
$$;

-- Booking as the panel sees it (local times in the shop's time zone).
create or replace function public._booking_json(k public.bookings, tz text) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'id', k.id, 'code', k.code, 'barber_id', k.barber_id, 'service_id', k.service_id,
    'items', k.items,
    'date', to_char(k.starts_at at time zone tz, 'YYYY-MM-DD'),
    'time', to_char(k.starts_at at time zone tz, 'HH24:MI'),
    'end',  to_char(k.ends_at at time zone tz, 'HH24:MI'),
    'minutes', (extract(epoch from (k.ends_at - k.starts_at)) / 60)::int,
    'price', k.price, 'pay_choice', k.pay_choice, 'online_due', k.online_due, 'paid_online', k.paid_online,
    'status', k.status, 'customer_name', k.customer_name, 'customer_phone', k.customer_phone,
    'customer_email', k.customer_email, 'note', k.note, 'staff_note', k.staff_note, 'source', k.source,
    'provider', (select p.provider from payments p where p.booking_id = k.id order by p.created_at desc limit 1),
    'created_at', k.created_at)
$$;

-- ---------- public (customers, no login) ------------------------------

create or replace function public.get_shop_public(p_slug text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s shops; today date; online jsonb := null; closed jsonb;
begin
  select * into s from shops where slug = lower(p_slug);
  if not found then return null; end if;
  today := _today(s.timezone);
  if s.online_pay <> 'off' and _payment_ready(s.id, s.online_pay) then
    online := jsonb_build_object('provider', s.online_pay, 'mode', s.online_mode, 'deposit_percent', s.deposit_percent);
  end if;
  select coalesce(jsonb_agg(to_char(d, 'YYYY-MM-DD')), '[]'::jsonb) into closed
    from generate_series(today::timestamp, (today + s.booking_days)::timestamp, interval '1 day') g(d)
   where _shop_closed(s.id, d::date);
  return jsonb_build_object(
    'id', s.id, 'slug', s.slug, 'name', s.name, 'tagline', s.tagline, 'address', s.address, 'phone', s.phone,
    'accent', s.accent, 'currency', s.currency, 'hours', s.hours, 'booking_days', s.booking_days,
    'default_lang', s.default_lang, 'pay_in_shop', s.pay_in_shop, 'online', online,
    'open', _shop_open(s), 'today', to_char(today, 'YYYY-MM-DD'), 'closed_dates', closed,
    'services', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'name', v.name, 'description', v.description,
                      'price', v.price, 'duration_min', v.duration_min, 'is_addon', v.is_addon) order by v.is_addon, v.sort, v.created_at)
                  from services v where v.shop_id = s.id and v.active), '[]'::jsonb),
    'barbers', coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'name', b.name, 'title', b.title) order by b.sort, b.created_at)
                  from barbers b where b.shop_id = s.id and b.active), '[]'::jsonb)
  );
end $$;

-- Free start times for a day. p_barber null = any barber.
create or replace function public.get_availability(p_slug text, p_date date, p_service uuid, p_addons uuid[] default '{}', p_barber uuid default null)
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s shops; h jsonb; dur int; open_t time; close_t time; t timestamp; st timestamptz;
        cutoff timestamptz; barber_ids uuid[]; slots jsonb := '[]'::jsonb; today date; free boolean;
begin
  select * into s from shops where slug = lower(p_slug);
  if not found or not _shop_open(s) then return jsonb_build_object('closed', true, 'slots', '[]'::jsonb); end if;
  today := _today(s.timezone);
  h := _hours_for(s, p_date);
  if h is null or p_date < today or p_date > today + s.booking_days or _shop_closed(s.id, p_date) then
    return jsonb_build_object('closed', true, 'slots', '[]'::jsonb);
  end if;
  select v.duration_min into dur from services v where v.id = p_service and v.shop_id = s.id and v.active and not v.is_addon;
  if dur is null then raise exception 'service_not_found'; end if;
  dur := dur + coalesce((select sum(v.duration_min) from services v
                          where v.id = any(coalesce(p_addons,'{}')) and v.shop_id = s.id and v.is_addon and v.active), 0);
  barber_ids := array(select b.id from barbers b where b.shop_id = s.id and b.active
                        and (p_barber is null or b.id = p_barber) and not _barber_off(b.id, p_date));
  open_t := (h->>0)::time; close_t := (h->>1)::time;
  cutoff := now() + make_interval(mins => s.lead_minutes);
  t := p_date + open_t;
  while t + make_interval(mins => dur) <= p_date + close_t loop
    st := t at time zone s.timezone;
    free := st >= cutoff and exists(select 1 from unnest(barber_ids) bid
                                    where not _busy(bid, st, st + make_interval(mins => dur)));
    slots := slots || jsonb_build_object('t', to_char(t, 'HH24:MI'), 'free', free);
    t := t + make_interval(mins => s.slot_step);
  end loop;
  return jsonb_build_object('closed', false, 'minutes', dur, 'slots', slots);
end $$;

-- Customer-safe view of one booking (for the confirmation page). The id is an unguessable uuid.
create or replace function public.get_booking_public(p_id uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'id', k.id, 'code', k.code, 'status', k.status, 'items', k.items,
    'date', to_char(k.starts_at at time zone s.timezone, 'YYYY-MM-DD'),
    'time', to_char(k.starts_at at time zone s.timezone, 'HH24:MI'),
    'price', k.price, 'pay_choice', k.pay_choice, 'online_due', k.online_due, 'paid_online', k.paid_online,
    'barber', b.name, 'first_name', split_part(k.customer_name, ' ', 1), 'lang', k.lang,
    'shop', jsonb_build_object('slug', s.slug, 'name', s.name, 'address', s.address, 'phone', s.phone,
                               'accent', s.accent, 'currency', s.currency))
  from bookings k join shops s on s.id = k.shop_id join barbers b on b.id = k.barber_id
  where k.id = p_id
$$;

-- ---------- booking engine (server + panel) ---------------------------

-- Shared insert used by online bookings and panel walk-ins.
create or replace function public._book(s public.shops, p jsonb, p_source text, p_enforce boolean) returns public.bookings
language plpgsql volatile security definer set search_path = public as $$
declare d date := (p->>'date')::date; tm time := (p->>'time')::time; h jsonb; svc services;
        addons uuid[] := coalesce(array(select jsonb_array_elements_text(coalesce(p->'addon_ids','[]'::jsonb))::uuid), '{}');
        lang text := coalesce(nullif(p->>'lang',''), s.default_lang);
        dur int; price numeric(10,2); items jsonb; st timestamptz; en timestamptz;
        pay text := coalesce(nullif(p->>'pay_choice',''), 'shop'); due numeric(10,2) := 0;
        cand uuid; k bookings; pref uuid := nullif(p->>'barber_id','')::uuid;
        nm text := btrim(coalesce(p->>'name','')); ph text := btrim(coalesce(p->>'phone',''));
begin
  if length(nm) < 2 or length(nm) > 80 then raise exception 'bad_name'; end if;
  if length(regexp_replace(ph, '\D', '', 'g')) < 7 or length(ph) > 30 then raise exception 'bad_phone'; end if;
  if lang not in ('ka','en','ru') then lang := s.default_lang; end if;

  select * into svc from services where id = (p->>'service_id')::uuid and shop_id = s.id and active and not is_addon;
  if not found then raise exception 'service_not_found'; end if;
  if exists(select 1 from unnest(addons) a where not exists(select 1 from services v where v.id = a and v.shop_id = s.id and v.is_addon and v.active)) then
    raise exception 'service_not_found';
  end if;

  select svc.duration_min + coalesce(sum(v.duration_min),0), svc.price + coalesce(sum(v.price),0),
         jsonb_build_array(jsonb_build_object('id', svc.id, 'name', svc.name, 'price', svc.price, 'min', svc.duration_min))
           || coalesce(jsonb_agg(jsonb_build_object('id', v.id, 'name', v.name, 'price', v.price, 'min', v.duration_min)) filter (where v.id is not null), '[]'::jsonb)
    into dur, price, items
    from (select 1) one left join services v on v.id = any(addons) and v.shop_id = s.id;

  st := (d + tm) at time zone s.timezone;
  en := st + make_interval(mins => dur);

  if p_enforce then
    if not _shop_open(s) then raise exception 'shop_closed'; end if;
    h := _hours_for(s, d);
    if h is null or _shop_closed(s.id, d) then raise exception 'shop_closed'; end if;
    if d > _today(s.timezone) + s.booking_days then raise exception 'too_far'; end if;
    if tm < (h->>0)::time or (d + tm + make_interval(mins => dur)) > d + (h->>1)::time then raise exception 'outside_hours'; end if;
    if (extract(epoch from (tm - (h->>0)::time)) / 60)::int % s.slot_step <> 0 then raise exception 'outside_hours'; end if;
    if st < now() + make_interval(mins => s.lead_minutes) then raise exception 'too_soon'; end if;
    -- payment rules
    if pay = 'shop' then
      if not s.pay_in_shop then raise exception 'pay_online_required'; end if;
    elsif pay in ('full','deposit') then
      if s.online_pay = 'off' or not _payment_ready(s.id, s.online_pay) then raise exception 'online_pay_unavailable'; end if;
      if (s.online_mode = 'full' and pay <> 'full') or (s.online_mode = 'deposit' and pay <> 'deposit') then raise exception 'online_pay_unavailable'; end if;
      due := case when pay = 'full' then price else greatest(1, round(price * s.deposit_percent / 100.0, 2)) end;
      due := least(due, price);
    else raise exception 'bad_payment'; end if;
  else
    pay := 'shop';
  end if;

  -- Release payment holds that ran out.
  update bookings set status = 'expired', updated_at = now()
   where shop_id = s.id and status = 'pending' and hold_until < now();

  -- Try the chosen barber, or every free barber (least busy that day first).
  for cand in
    select b.id from barbers b
     where b.shop_id = s.id and b.active and (pref is null or b.id = pref) and not _barber_off(b.id, d)
     order by (select count(*) from bookings x where x.barber_id = b.id and x.status in ('pending','booked','done','noshow')
                 and x.starts_at >= (d::timestamp at time zone s.timezone)
                 and x.starts_at < ((d + 1)::timestamp at time zone s.timezone)), b.sort, b.created_at
  loop
    begin
      insert into bookings (shop_id, code, barber_id, service_id, addon_ids, items, starts_at, ends_at, price,
                            pay_choice, online_due, status, hold_until, customer_name, customer_phone, customer_email,
                            lang, note, source)
      values (s.id, _new_code(), cand, svc.id, addons, items, st, en, price,
              pay, due, case when due > 0 then 'pending' else 'booked' end,
              case when due > 0 then now() + interval '20 minutes' end,
              nm, ph, left(btrim(coalesce(p->>'email','')), 120), lang, left(coalesce(p->>'note',''), 300), p_source)
      returning * into k;
      return k;
    exception when exclusion_violation then
      -- someone else got this barber at this time; try the next one
    end;
  end loop;
  raise exception 'slot_taken';
end $$;

-- Called by the server (/api/book) with the service key.
create or replace function public.create_booking(p jsonb) returns jsonb
language plpgsql volatile security definer set search_path = public as $$
declare s shops; k bookings;
begin
  select * into s from shops where slug = lower(p->>'slug');
  if not found then raise exception 'shop_not_found'; end if;
  k := _book(s, p, 'online', true);
  return _booking_json(k, s.timezone) || jsonb_build_object('shop_id', s.id, 'provider', case when k.online_due > 0 then s.online_pay end);
end $$;

create or replace function public.attach_payment(p_booking uuid, p_provider text, p_order text, p_amount numeric) returns void
language sql volatile security definer set search_path = public as $$
  insert into payments (booking_id, shop_id, provider, order_id, amount)
  select k.id, k.shop_id, p_provider, p_order, p_amount from bookings k where k.id = p_booking
$$;

create or replace function public.abandon_booking(p_booking uuid) returns void
language sql volatile security definer set search_path = public as $$
  update bookings set status = 'expired', updated_at = now() where id = p_booking and status = 'pending'
$$;

-- Payment info the server needs to check a payment with the bank.
create or replace function public.payment_lookup(p_provider text, p_order text, p_booking uuid default null) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('payment_id', p.id, 'provider', p.provider, 'order_id', p.order_id, 'amount', p.amount,
                            'status', p.status, 'booking_id', p.booking_id, 'shop_id', p.shop_id,
                            'secret', case p.provider when 'tbc' then x.tbc else x.bog end)
  from payments p left join shop_secrets x on x.shop_id = p.shop_id
  where (p_booking is not null and p.booking_id = p_booking) or (p_booking is null and p.provider = p_provider and p.order_id = p_order)
  order by p.created_at desc limit 1
$$;

-- Bank said "paid". Returns the booking and whether a confirmation SMS is due.
create or replace function public.confirm_payment(p_provider text, p_order text, p_amount numeric, p_raw jsonb default null) returns jsonb
language plpgsql volatile security definer set search_path = public as $$
declare pay payments; k bookings; s shops; ok boolean := true;
begin
  select * into pay from payments where provider = p_provider and order_id = p_order for update;
  if not found then raise exception 'payment_not_found'; end if;
  select * into k from bookings where id = pay.booking_id for update;
  select * into s from shops where id = k.shop_id;
  if pay.status = 'paid' then
    return jsonb_build_object('already', true, 'booking', _booking_json(k, s.timezone), 'ok', k.status <> 'cancelled');
  end if;
  update payments set status = 'paid', raw = p_raw, updated_at = now() where id = pay.id;
  begin
    update bookings set paid_online = p_amount, updated_at = now(),
                        status = case when status in ('pending','expired') then 'booked' else status end
     where id = k.id returning * into k;
  exception when exclusion_violation then
    -- Paid after the hold ran out and someone else took the time. Flag for a refund.
    ok := false;
    update bookings set paid_online = p_amount, status = 'cancelled', updated_at = now(),
                        staff_note = trim(staff_note || ' Paid online after the time was taken by someone else. Refund needed.')
     where id = k.id returning * into k;
  end;
  return jsonb_build_object('already', false, 'ok', ok, 'booking', _booking_json(k, s.timezone),
                            'sms', s.sms_enabled and ok, 'shop', jsonb_build_object('name', s.name, 'address', s.address));
end $$;

create or replace function public.fail_payment(p_provider text, p_order text, p_raw jsonb default null) returns void
language plpgsql volatile security definer set search_path = public as $$
declare pay payments;
begin
  select * into pay from payments where provider = p_provider and order_id = p_order;
  if not found or pay.status <> 'created' then return; end if;
  update payments set status = 'failed', raw = p_raw, updated_at = now() where id = pay.id;
  update bookings set status = 'expired', updated_at = now() where id = pay.booking_id and status = 'pending';
end $$;

-- SMS bookkeeping
create or replace function public.sms_info(p_booking uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select _booking_json(k, s.timezone) || jsonb_build_object('lang', k.lang, 'sms_enabled', s.sms_enabled,
         'confirmed_sms_at', k.confirmed_sms_at, 'shop', jsonb_build_object('name', s.name, 'address', s.address, 'phone', s.phone))
  from bookings k join shops s on s.id = k.shop_id where k.id = p_booking
$$;

create or replace function public.mark_sms(p_ids uuid[], p_kind text) returns void
language sql volatile security definer set search_path = public as $$
  update bookings set confirmed_sms_at = case when p_kind = 'confirm' then now() else confirmed_sms_at end,
                      reminded_at      = case when p_kind = 'remind'  then now() else reminded_at end
   where id = any(p_ids)
$$;

-- Bookings that start tomorrow (shop time) and have not been reminded.
create or replace function public.due_reminders() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(_booking_json(k, s.timezone) || jsonb_build_object('lang', k.lang,
            'shop', jsonb_build_object('name', s.name, 'address', s.address))), '[]'::jsonb)
  from bookings k join shops s on s.id = k.shop_id
  where k.status = 'booked' and k.reminded_at is null and s.sms_enabled and _shop_open(s)
    and (k.starts_at at time zone s.timezone)::date = _today(s.timezone) + 1
$$;

-- ---------- shop panel (logged-in owners and staff) -------------------

create or replace function public.my_shops() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'admin', is_platform_admin(),
    'shops', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'slug', s.slug, 'name', s.name, 'role', m.role,
                    'active', _shop_open(s), 'barber_id', m.barber_id) order by s.name)
              from members m join shops s on s.id = m.shop_id where m.user_id = auth.uid()), '[]'::jsonb))
$$;

create or replace function public.panel_day(p_shop uuid, p_date date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s shops; role text;
begin
  perform _require(p_shop, false);
  role := _role_in(p_shop);
  select * into s from shops where id = p_shop;
  return jsonb_build_object(
    'role', role, 'today', to_char(_today(s.timezone), 'YYYY-MM-DD'),
    'now', to_char(now() at time zone s.timezone, 'HH24:MI'),
    'shop', jsonb_build_object('id', s.id, 'slug', s.slug, 'name', s.name, 'accent', s.accent, 'currency', s.currency,
            'hours', s.hours, 'slot_step', s.slot_step, 'open', _shop_open(s), 'paid_until', s.paid_until, 'default_lang', s.default_lang),
    'closed', _hours_for(s, p_date) is null or _shop_closed(s.id, p_date),
    'hours', _hours_for(s, p_date),
    'barbers', coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'name', b.name, 'active', b.active,
                     'off', _barber_off(b.id, p_date)) order by b.sort, b.created_at)
                from barbers b where b.shop_id = s.id and (b.active or exists(
                  select 1 from bookings x where x.barber_id = b.id and (x.starts_at at time zone s.timezone)::date = p_date))), '[]'::jsonb),
    'services', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'name', v.name, 'price', v.price,
                     'duration_min', v.duration_min, 'is_addon', v.is_addon) order by v.is_addon, v.sort)
                from services v where v.shop_id = s.id and v.active), '[]'::jsonb),
    'bookings', coalesce((select jsonb_agg(_booking_json(k, s.timezone) order by k.starts_at)
                from bookings k where k.shop_id = s.id and k.status <> 'expired'
                  and k.starts_at >= (p_date::timestamp at time zone s.timezone)
                  and k.starts_at < ((p_date + 1)::timestamp at time zone s.timezone)), '[]'::jsonb)
  );
end $$;

-- Compact rows for income charts. Owners only.
create or replace function public.panel_range(p_shop uuid, p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s shops;
begin
  perform _require(p_shop, true);
  if p_to - p_from > 400 then raise exception 'range_too_long'; end if;
  select * into s from shops where id = p_shop;
  return coalesce((select jsonb_agg(jsonb_build_object(
      'date', to_char(k.starts_at at time zone s.timezone, 'YYYY-MM-DD'), 'barber_id', k.barber_id,
      'service_id', k.service_id, 'price', k.price, 'paid_online', k.paid_online, 'status', k.status,
      'pay_choice', k.pay_choice, 'minutes', (extract(epoch from (k.ends_at - k.starts_at)) / 60)::int))
    from bookings k where k.shop_id = s.id and k.status not in ('expired','pending')
      and k.starts_at >= (p_from::timestamp at time zone s.timezone)
      and k.starts_at < ((p_to + 1)::timestamp at time zone s.timezone)), '[]'::jsonb);
end $$;

create or replace function public.panel_upcoming(p_shop uuid, p_q text default '', p_limit int default 50) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s shops; q text := '%' || lower(btrim(coalesce(p_q,''))) || '%';
begin
  perform _require(p_shop, false);
  select * into s from shops where id = p_shop;
  return coalesce((select jsonb_agg(x.j order by x.st) from (
      select _booking_json(k, s.timezone) j, k.starts_at st from bookings k
       where k.shop_id = s.id and k.status in ('booked','pending') and k.ends_at >= now()
         and (lower(k.customer_name) like q or k.customer_phone like q or lower(k.code) like q)
       order by k.starts_at limit least(greatest(p_limit,1),200)) x), '[]'::jsonb);
end $$;

create or replace function public.set_booking_status(p_booking uuid, p_status text, p_staff_note text default null) returns jsonb
language plpgsql volatile security definer set search_path = public as $$
declare k bookings; s shops;
begin
  select * into k from bookings where id = p_booking;
  if not found then raise exception 'not_found'; end if;
  perform _require(k.shop_id, false);
  select * into s from shops where id = k.shop_id;
  if p_status not in ('booked','done','noshow','cancelled') then raise exception 'bad_status'; end if;
  if k.status in ('pending','expired') then raise exception 'bad_status'; end if;
  begin
    update bookings set status = p_status, updated_at = now(),
                        staff_note = coalesce(left(p_staff_note, 300), staff_note)
     where id = p_booking returning * into k;
  exception when exclusion_violation then
    raise exception 'slot_taken';
  end;
  return _booking_json(k, s.timezone);
end $$;

-- Phone or walk-in booking added by staff. Skips online-only rules (lead time, payment).
create or replace function public.panel_add_booking(p_shop uuid, p jsonb) returns jsonb
language plpgsql volatile security definer set search_path = public as $$
declare s shops; k bookings;
begin
  perform _require(p_shop, false);
  select * into s from shops where id = p_shop;
  if nullif(p->>'barber_id','') is null then raise exception 'pick_barber'; end if;
  k := _book(s, p, 'panel', false);
  return _booking_json(k, s.timezone);
end $$;

create or replace function public.get_settings(p_shop uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s shops;
begin
  perform _require(p_shop, true);
  select * into s from shops where id = p_shop;
  return jsonb_build_object(
    'shop', to_jsonb(s) - 'admin_note',
    'today', to_char(_today(s.timezone), 'YYYY-MM-DD'),
    'payments', jsonb_build_object('tbc', _payment_ready(s.id, 'tbc'), 'bog', _payment_ready(s.id, 'bog')),
    'services', coalesce((select jsonb_agg(to_jsonb(v) order by v.is_addon, v.sort, v.created_at) from services v where v.shop_id = s.id), '[]'::jsonb),
    'barbers', coalesce((select jsonb_agg(to_jsonb(b) order by b.sort, b.created_at) from barbers b where b.shop_id = s.id), '[]'::jsonb),
    'closures', coalesce((select jsonb_agg(to_jsonb(c) order by c.starts_on) from closures c
                           where c.shop_id = s.id and c.ends_on >= _today(s.timezone)), '[]'::jsonb),
    'staff', coalesce((select jsonb_agg(jsonb_build_object('user_id', m.user_id, 'email', u.email, 'role', m.role,
                         'barber_id', m.barber_id, 'me', m.user_id = auth.uid()) order by m.role, u.email)
                       from members m join auth.users u on u.id = m.user_id where m.shop_id = s.id), '[]'::jsonb)
  );
end $$;

create or replace function public.save_shop(p_shop uuid, p jsonb) returns void
language plpgsql volatile security definer set search_path = public as $$
declare k text; d int;
begin
  perform _require(p_shop, true);
  if p ? 'hours' then
    for d in 0..6 loop
      k := d::text;
      if jsonb_typeof(p->'hours'->k) = 'array' then
        if (p->'hours'->k->>0)::time >= (p->'hours'->k->>1)::time then raise exception 'bad_hours'; end if;
      elsif coalesce(jsonb_typeof(p->'hours'->k), 'null') <> 'null' then raise exception 'bad_hours';
      end if;
    end loop;
  end if;
  if coalesce(p->>'online_pay','off') <> 'off' and not _payment_ready(p_shop, p->>'online_pay') then
    raise exception 'online_pay_unavailable';
  end if;
  update shops set
    name            = coalesce(nullif(btrim(p->>'name'),''), name),
    tagline         = coalesce(p->'tagline', tagline),
    address         = coalesce(p->>'address', address),
    phone           = coalesce(p->>'phone', phone),
    accent          = coalesce(p->>'accent', accent),
    hours           = coalesce(p->'hours', hours),
    slot_step       = coalesce((p->>'slot_step')::int, slot_step),
    lead_minutes    = coalesce((p->>'lead_minutes')::int, lead_minutes),
    booking_days    = coalesce((p->>'booking_days')::int, booking_days),
    pay_in_shop     = coalesce((p->>'pay_in_shop')::boolean, pay_in_shop),
    online_pay      = coalesce(p->>'online_pay', online_pay),
    online_mode     = coalesce(p->>'online_mode', online_mode),
    deposit_percent = coalesce((p->>'deposit_percent')::int, deposit_percent),
    sms_enabled     = coalesce((p->>'sms_enabled')::boolean, sms_enabled),
    default_lang    = coalesce(p->>'default_lang', default_lang)
  where id = p_shop;
  if not exists(select 1 from shops where id = p_shop and (pay_in_shop or online_pay <> 'off')) then
    raise exception 'need_a_payment_option';
  end if;
end $$;

create or replace function public.save_service(p_shop uuid, p jsonb) returns uuid
language plpgsql volatile security definer set search_path = public as $$
declare v_id uuid := nullif(p->>'id','')::uuid;
begin
  perform _require(p_shop, true);
  if v_id is null then
    insert into services (shop_id, name, description, price, duration_min, is_addon, sort, active)
    values (p_shop, p->'name', coalesce(p->'description','{}'::jsonb), (p->>'price')::numeric, (p->>'duration_min')::int,
            coalesce((p->>'is_addon')::boolean,false), coalesce((p->>'sort')::int,0), coalesce((p->>'active')::boolean,true))
    returning id into v_id;
  else
    update services set name = coalesce(p->'name', name), description = coalesce(p->'description', description),
           price = coalesce((p->>'price')::numeric, price), duration_min = coalesce((p->>'duration_min')::int, duration_min),
           is_addon = coalesce((p->>'is_addon')::boolean, is_addon), sort = coalesce((p->>'sort')::int, sort),
           active = coalesce((p->>'active')::boolean, active)
     where id = v_id and shop_id = p_shop;
    if not found then raise exception 'not_found'; end if;
  end if;
  return v_id;
end $$;

create or replace function public.save_barber(p_shop uuid, p jsonb) returns uuid
language plpgsql volatile security definer set search_path = public as $$
declare v_id uuid := nullif(p->>'id','')::uuid;
begin
  perform _require(p_shop, true);
  if v_id is null then
    insert into barbers (shop_id, name, title, sort, active)
    values (p_shop, btrim(p->>'name'), coalesce(p->'title','{}'::jsonb), coalesce((p->>'sort')::int,0), coalesce((p->>'active')::boolean,true))
    returning id into v_id;
  else
    update barbers set name = coalesce(nullif(btrim(p->>'name'),''), name), title = coalesce(p->'title', title),
           sort = coalesce((p->>'sort')::int, sort), active = coalesce((p->>'active')::boolean, active)
     where id = v_id and shop_id = p_shop;
    if not found then raise exception 'not_found'; end if;
  end if;
  return v_id;
end $$;

create or replace function public.add_closure(p_shop uuid, p jsonb) returns uuid
language plpgsql volatile security definer set search_path = public as $$
declare v_id uuid;
begin
  perform _require(p_shop, true);
  if nullif(p->>'barber_id','') is not null and not exists(select 1 from barbers where id = (p->>'barber_id')::uuid and shop_id = p_shop) then
    raise exception 'not_found';
  end if;
  insert into closures (shop_id, barber_id, starts_on, ends_on, note)
  values (p_shop, nullif(p->>'barber_id','')::uuid, (p->>'starts_on')::date, coalesce(nullif(p->>'ends_on','')::date, (p->>'starts_on')::date),
          left(coalesce(p->>'note',''), 120))
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.delete_closure(p_shop uuid, p_id uuid) returns void
language plpgsql volatile security definer set search_path = public as $$
begin
  perform _require(p_shop, true);
  delete from closures where id = p_id and shop_id = p_shop;
end $$;

create or replace function public.remove_member(p_shop uuid, p_user uuid) returns void
language plpgsql volatile security definer set search_path = public as $$
begin
  perform _require(p_shop, true);
  if p_user = auth.uid() then raise exception 'cannot_remove_self'; end if;
  delete from members where shop_id = p_shop and user_id = p_user;
end $$;

-- Server-only: add a login to a shop after the auth user exists.
create or replace function public.add_member(p_shop uuid, p_user uuid, p_role text, p_barber uuid) returns void
language sql volatile security definer set search_path = public as $$
  insert into members (shop_id, user_id, role, barber_id) values (p_shop, p_user, p_role, p_barber)
  on conflict (shop_id, user_id) do update set role = excluded.role, barber_id = excluded.barber_id
$$;

-- Server-only: check the caller's role from their user id (used by API routes).
create or replace function public.role_of(p_shop uuid, p_user uuid) returns text
language sql stable security definer set search_path = public as $$
  select case when exists(select 1 from platform_admins where user_id = p_user) then 'owner'
              else (select role from members where shop_id = p_shop and user_id = p_user) end
$$;

create or replace function public.is_admin_user(p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from platform_admins where user_id = p_user)
$$;

create or replace function public.set_secret(p_shop uuid, p_provider text, p_value text) returns void
language plpgsql volatile security definer set search_path = public as $$
begin
  insert into shop_secrets (shop_id) values (p_shop) on conflict (shop_id) do nothing;
  if p_provider = 'tbc' then update shop_secrets set tbc = p_value, updated_at = now() where shop_id = p_shop;
  elsif p_provider = 'bog' then update shop_secrets set bog = p_value, updated_at = now() where shop_id = p_shop;
  else raise exception 'bad_provider'; end if;
  if p_value is null then
    update shops set online_pay = 'off', pay_in_shop = true where id = p_shop and online_pay = p_provider;
  end if;
end $$;

create or replace function public.shop_secret(p_shop uuid, p_provider text) returns text
language sql stable security definer set search_path = public as $$
  select case p_provider when 'tbc' then tbc when 'bog' then bog end from shop_secrets where shop_id = p_shop
$$;

-- ---------- platform admin (you) --------------------------------------

create or replace function public.admin_shops() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_platform_admin() then raise exception 'not_allowed' using errcode = '42501'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object(
      'id', s.id, 'slug', s.slug, 'name', s.name, 'active', s.active, 'paid_until', s.paid_until,
      'open', _shop_open(s), 'admin_note', s.admin_note, 'created_at', s.created_at, 'online_pay', s.online_pay,
      'owners', (select coalesce(jsonb_agg(u.email), '[]'::jsonb) from members m join auth.users u on u.id = m.user_id
                  where m.shop_id = s.id and m.role = 'owner'),
      'bookings_30d', (select count(*) from bookings k where k.shop_id = s.id and k.created_at > now() - interval '30 days'
                        and k.status not in ('expired','pending')),
      'last_booking', (select max(k.created_at) from bookings k where k.shop_id = s.id)
    ) order by s.created_at desc) from shops s), '[]'::jsonb);
end $$;

create or replace function public.admin_update_shop(p_shop uuid, p jsonb) returns void
language plpgsql volatile security definer set search_path = public as $$
begin
  if not is_platform_admin() then raise exception 'not_allowed' using errcode = '42501'; end if;
  update shops set
    active     = coalesce((p->>'active')::boolean, active),
    paid_until = case when p ? 'paid_until' then nullif(p->>'paid_until','')::date else paid_until end,
    admin_note = coalesce(p->>'admin_note', admin_note),
    name       = coalesce(nullif(btrim(p->>'name'),''), name)
  where id = p_shop;
end $$;

-- Server-only: new shop with starter services and barbers.
create or replace function public.admin_create_shop(p jsonb) returns uuid
language plpgsql volatile security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into shops (slug, name, address, phone, paid_until)
  values (lower(btrim(p->>'slug')), btrim(p->>'name'), coalesce(p->>'address',''), coalesce(p->>'phone',''),
          nullif(p->>'paid_until','')::date)
  returning id into v_id;
  insert into services (shop_id, name, description, price, duration_min, is_addon, sort) values
   (v_id, '{"ka":"კლასიკური შეჭრა","en":"Classic cut","ru":"Классическая стрижка"}', '{}', 35, 45, false, 1),
   (v_id, '{"ka":"ფეიდი","en":"Skin fade","ru":"Фейд"}', '{}', 40, 45, false, 2),
   (v_id, '{"ka":"წვერის გასწორება","en":"Beard trim","ru":"Оформление бороды"}', '{}', 25, 30, false, 3),
   (v_id, '{"ka":"შეჭრა + წვერი","en":"Cut + beard","ru":"Стрижка + борода"}', '{}', 55, 60, false, 4),
   (v_id, '{"ka":"თავის დაბანა","en":"Hair wash","ru":"Мытьё головы"}', '{}', 10, 10, true, 5);
  insert into barbers (shop_id, name, sort) values (v_id, 'Barber 1', 1), (v_id, 'Barber 2', 2);
  return v_id;
end $$;

-- ---------- permissions on functions ----------------------------------
-- Supabase grants EXECUTE to anon/authenticated by default; lock it down explicitly.

do $$ declare f record; begin
  for f in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    execute format('grant execute on function %s to service_role', f.sig);
  end loop;
end $$;

-- Customers (no login)
grant execute on function public.get_shop_public(text) to anon, authenticated;
grant execute on function public.get_availability(text, date, uuid, uuid[], uuid) to anon, authenticated;
grant execute on function public.get_booking_public(uuid) to anon, authenticated;
-- Logged-in shop owners/staff and you (each function checks the role itself)
grant execute on function public.my_shops() to authenticated;
grant execute on function public.panel_day(uuid, date) to authenticated;
grant execute on function public.panel_range(uuid, date, date) to authenticated;
grant execute on function public.panel_upcoming(uuid, text, int) to authenticated;
grant execute on function public.set_booking_status(uuid, text, text) to authenticated;
grant execute on function public.panel_add_booking(uuid, jsonb) to authenticated;
grant execute on function public.get_settings(uuid) to authenticated;
grant execute on function public.save_shop(uuid, jsonb) to authenticated;
grant execute on function public.save_service(uuid, jsonb) to authenticated;
grant execute on function public.save_barber(uuid, jsonb) to authenticated;
grant execute on function public.add_closure(uuid, jsonb) to authenticated;
grant execute on function public.delete_closure(uuid, uuid) to authenticated;
grant execute on function public.remove_member(uuid, uuid) to authenticated;
grant execute on function public.admin_shops() to authenticated;
grant execute on function public.admin_update_shop(uuid, jsonb) to authenticated;
