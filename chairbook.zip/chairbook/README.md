# Chairbook: online booking for barbershops

One system that you rent to many barbershops. Each shop gets:

- **Its own booking page** at `yourdomain.ge/shop-name`, in Georgian, English and Russian.
- **A shop panel** at `yourdomain.ge/panel` with:
  - a day sheet for every chair
  - phone and walk-in bookings
  - income charts and upcoming bookings
  - settings for services, barbers, hours, days off, payments and logins
- **Online payments into the shop's own bank account** through TBC or Bank of Georgia. Customers pay in full or leave a deposit, or the shop can let them pay in person.
- **SMS** confirmation when the booking is made, and a reminder the evening before.

You manage everything at `yourdomain.ge/admin`:

- add shops and their owner logins
- set "paid until" for each shop's monthly fee
- switch online booking off for a shop that hasn't paid

There are no third-party packages to install. The project is made of three parts:

- plain HTML/JS pages (`public/`)
- small server functions (`api/`)
- a Postgres database (`supabase/migrations/001_chairbook.sql`), which holds all the booking rules

---

## What you need (accounts)

| Service | What it does | Cost to start |
|---|---|---|
| [GitHub](https://github.com) | Stores the code so Vercel can publish it | Free |
| [Supabase](https://supabase.com) | Database and logins | Free tier. Pro is $25/month and adds daily backups. |
| [Vercel](https://vercel.com) | Hosts the website and server functions | Hobby is free but **non-commercial only**. Use **Pro ($20/month)** once shops pay you. |
| [SMSOffice.ge](https://smsoffice.ge) | Sends SMS in Georgia | Pay per message |
| TBC developer app ([developers.tbcbank.ge](https://developers.tbcbank.ge)) | Gives you the TBC **API key** the platform needs | Free |
| A domain, e.g. `chairbook.ge` | Your address | ~30–60 GEL/year |

Each shop brings its own bank merchant account (TBC or Bank of Georgia). Their money never passes through you.

---

## Setup, step by step (about 30 minutes)

### 1. Put the code on GitHub
1. Create a GitHub account and a new **private** repository, e.g. `chairbook`.
2. Click **"uploading an existing file"**, drag in everything from this folder (not the folder itself), and click **Commit**.

### 2. Create the database (Supabase)
1. Create a new project. For the region, pick **Frankfurt (eu-central-1)**, the closest to Georgia. Save the database password somewhere safe.
2. Open **SQL Editor → New query**, paste all of `supabase/migrations/001_chairbook.sql`, and click **Run**. It should say "Success".
3. Go to **Authentication → Sign In / Providers** and turn **off** "Allow new users to sign up". Only you and shop owners create logins.
4. Go to **Project Settings → API Keys** and copy three values:
   - the **Project URL** (also shown under Settings → Data API)
   - the **Publishable key** (`sb_publishable_…`)
   - the **Secret key** (`sb_secret_…`)

   If your project only shows the older keys, the `anon` key works as the publishable key and the `service_role` key works as the secret key.

### 3. Publish the site (Vercel)
1. Sign in to Vercel with GitHub. Click **Add New → Project**, pick your repository, and click **Deploy**. No build settings are needed.
2. Open **Settings → Environment Variables** and add the variables below, then click **Redeploy**.

| Name | Value |
|---|---|
| `SUPABASE_URL` | Project URL from step 2 |
| `SUPABASE_PUBLISHABLE_KEY` | Publishable key |
| `SUPABASE_SECRET_KEY` | Secret key (**keep private**) |
| `APP_SECRET` | A random string of 40+ characters. It encrypts the shops' bank keys. **Never change it later**: shops would have to reconnect their banks. |
| `APP_URL` | Your final address, e.g. `https://chairbook.ge` |
| `PLATFORM_NAME` | Your brand name, e.g. `Chairbook` |
| `TBC_API_KEY` | The API key of your TBC developer app (step 6) |
| `SMSOFFICE_API_KEY` | From your SMSOffice.ge profile page |
| `SMS_SENDER` | Your **registered** sender name in SMSOffice (max 11 letters) |
| `CRON_SECRET` | Another random string. It protects the daily reminder job. |

To make a random string, open any browser console and run `crypto.randomUUID()+crypto.randomUUID()`.

3. Add your domain under **Settings → Domains**.

### 4. Make yourself the platform admin
1. In Supabase, go to **Authentication → Users → Add user → Create new user**. Enter your email and a strong password, and tick "Auto Confirm User".
2. In the **SQL Editor**, run this, using your own email:
   ```sql
   insert into platform_admins select id from auth.users where email = 'you@example.com';
   ```
3. Open `https://yourdomain/admin` and log in.

### 5. Add the first barbershop
In **/admin → Add a shop**:
1. Enter the shop name, its web address (for example `kudi-barbers`, which becomes `yourdomain/kudi-barbers`), the owner's email and a first password.
2. Send the owner that password and the link `yourdomain/panel`.

The shop starts with 4 example services, 1 add-on and 2 barbers. The owner renames them in **Settings**.

### 6. Online payments
**TBC:**
- **You** do this once: register at developers.tbcbank.ge, create an app for "TBC E-Commerce" (Checkout), and put its API key in `TBC_API_KEY`.
- **Each shop** finds its **Client ID** and **Client Secret** at `ecom.tbcpayments.ge` → Website Management → Details, then pastes them in **Panel → Settings → Payments → TBC → Connect**. The panel checks the keys with TBC straight away.
- In the same TBC dashboard, the shop pastes the callback address that the panel shows them: `https://yourdomain/api/pay/callback?provider=tbc`. TBC activates it the same day.

**Bank of Georgia:**
- The shop gets a **Client ID** and **Secret** from BOG when it signs up for online payments.
- It pastes them in **Panel → Settings → Payments → Bank of Georgia → Connect**. No callback setup is needed.

Then the shop picks TBC or BOG under **Online payment**, and chooses how customers pay: full price, a deposit (%), or the customer's choice.

> **Test with real money before going live.** The bank code follows TBC's and BOG's published API docs and has been tested against simulated banks, but not yet against the live banks. Add a hidden 1 ₾ service, book it, pay with your own card, and check that the booking turns green in the panel. Then refund it from the bank's dashboard.

### 7. SMS
1. Register a sender name with SMSOffice.ge. Sender names need approval.
2. Top up your balance.

Confirmations go out as soon as a booking is confirmed. Reminders go out every day at **19:00 Tbilisi time** for the next day's bookings. Shops can switch SMS off in **Settings → Shop**.

---

## Everyday use

- **Bill a shop:** in /admin, set **Paid until** to the end of the period they paid for. After that date their booking page shows "please call us", but their panel and data stay.
- **Pause a shop:** untick **Online booking** in /admin.
- **Owner forgot their password:** Supabase → Authentication → Users → the user → "Send password recovery". Or delete the user and add a new login from the shop's panel.
- **Barber forgot their password:** the shop owner sets a new one in **Panel → Settings → Logins**.
- **Refunds** are done in the bank's own merchant dashboard. If someone paid after their 20-minute hold ran out and the time was taken by someone else, the booking shows as cancelled with the note "Refund needed".

## How double-booking is prevented
The database refuses two overlapping bookings for the same barber, even if two customers click at the same second. While a customer is on the bank's page, their time is held for 20 minutes. If the payment fails or the customer leaves, the time is released.

## Not included yet
- Customers can't cancel or move their own booking. They call the shop, and staff change it in the panel.
- No email notifications (SMS only).
- Every barber offers every service.
- Online booking forms are protected only by a hidden spam trap. Add Vercel's firewall rate limiting if bots become a problem.
- The Georgian and Russian texts were written by Claude and should be proofread by native speakers. Customer texts are in `public/assets/i18n.js`, panel texts are in `public/assets/panel.js`, and SMS texts are in `api/_lib/sms.js`.

## For developers: running the tests
Requires Postgres 16 (`psql`), Node 20+ and Playwright with Chromium.
```bash
# start a throwaway Postgres on port 54329 with its socket in /tmp/pgdata, then:
bash test/run_all.sh /tmp/shots
```
- `test/db_test.sql` checks the booking engine, the payment states, permissions for each role, reminders and the double-booking guard.
- `test/devserver.mjs` imitates Supabase, TBC, BOG and SMSOffice locally.
- `test/e2e_*.mjs` click through the real pages in a browser.

## Project map
```
public/            pages: book.html (customer), b.html (confirmation), panel.html, admin.html, index.html
public/assets/     shared CSS/JS, translations
api/book.js        create a booking, start bank payment
api/pay/*.js       bank callbacks and payment re-checks
api/shop/*.js      bank keys and staff logins (owner only)
api/admin/shops.js add a shop (platform admin only)
api/cron/reminders.js  daily SMS reminders (scheduled in vercel.json)
supabase/migrations/001_chairbook.sql   the whole database
```
